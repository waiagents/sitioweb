// animations.js - Componente de animaciones globales para WAI Agents

import { 
  Frame, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Función para detectar cuando un elemento es visible en el viewport
export function useInView(id, threshold = 0.1) {
  const [isInView, setIsInView] = useState(false)
  const controls = useAnimation()
  
  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById(id)
      if (element) {
        const rect = element.getBoundingClientRect()
        const windowHeight = window.innerHeight || document.documentElement.clientHeight
        
        // Calcular qué porcentaje del elemento es visible
        const visibleHeight = Math.min(rect.bottom, windowHeight) - Math.max(rect.top, 0)
        const visiblePercentage = visibleHeight / rect.height
        
        if (visiblePercentage > threshold) {
          setIsInView(true)
          controls.start({
            opacity: 1,
            y: 0,
            transition: { duration: 0.8, staggerChildren: 0.2 }
          })
        } else {
          setIsInView(false)
        }
      }
    }
    
    window.addEventListener('scroll', handleScroll)
    // Trigger once on mount
    handleScroll()
    
    return () => window.removeEventListener('scroll', handleScroll)
  }, [id, threshold])
  
  return { isInView, controls }
}

// Componente de animación de entrada
export function FadeInUp({ children, delay = 0, duration = 0.8, ...props }) {
  return (
    <Frame
      background="transparent"
      width="auto"
      height="auto"
      style={{
        opacity: 0,
        y: 30,
        ...props.style
      }}
      animate={{
        opacity: 1,
        y: 0
      }}
      transition={{
        duration: duration,
        delay: delay,
        ease: "easeOut"
      }}
      {...props}
    >
      {children}
    </Frame>
  )
}

// Componente de animación de entrada desde la izquierda
export function FadeInLeft({ children, delay = 0, duration = 0.8, ...props }) {
  return (
    <Frame
      background="transparent"
      width="auto"
      height="auto"
      style={{
        opacity: 0,
        x: -50,
        ...props.style
      }}
      animate={{
        opacity: 1,
        x: 0
      }}
      transition={{
        duration: duration,
        delay: delay,
        ease: "easeOut"
      }}
      {...props}
    >
      {children}
    </Frame>
  )
}

// Componente de animación de entrada desde la derecha
export function FadeInRight({ children, delay = 0, duration = 0.8, ...props }) {
  return (
    <Frame
      background="transparent"
      width="auto"
      height="auto"
      style={{
        opacity: 0,
        x: 50,
        ...props.style
      }}
      animate={{
        opacity: 1,
        x: 0
      }}
      transition={{
        duration: duration,
        delay: delay,
        ease: "easeOut"
      }}
      {...props}
    >
      {children}
    </Frame>
  )
}

// Componente de animación de escala
export function ScaleIn({ children, delay = 0, duration = 0.8, ...props }) {
  return (
    <Frame
      background="transparent"
      width="auto"
      height="auto"
      style={{
        opacity: 0,
        scale: 0.8,
        ...props.style
      }}
      animate={{
        opacity: 1,
        scale: 1
      }}
      transition={{
        duration: duration,
        delay: delay,
        ease: "easeOut"
      }}
      {...props}
    >
      {children}
    </Frame>
  )
}

// Componente de animación de desplazamiento paralaje
export function ParallaxScroll({ children, speed = 0.1, ...props }) {
  const [scrollY, setScrollY] = useState(0)
  
  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }
    
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  return (
    <Frame
      background="transparent"
      width="auto"
      height="auto"
      style={{
        y: scrollY * speed,
        ...props.style
      }}
      {...props}
    >
      {children}
    </Frame>
  )
}

// Componente de animación de contador
export function CounterAnimation({ end, duration = 2, prefix = "", suffix = "", ...props }) {
  const [count, setCount] = useState(0)
  
  useEffect(() => {
    let startTime
    let animationFrame
    
    const step = (timestamp) => {
      if (!startTime) startTime = timestamp
      const progress = Math.min((timestamp - startTime) / (duration * 1000), 1)
      setCount(Math.floor(progress * end))
      
      if (progress < 1) {
        animationFrame = requestAnimationFrame(step)
      }
    }
    
    animationFrame = requestAnimationFrame(step)
    
    return () => cancelAnimationFrame(animationFrame)
  }, [end, duration])
  
  return (
    <Frame
      background="transparent"
      width="auto"
      height="auto"
      {...props}
    >
      {prefix}{count}{suffix}
    </Frame>
  )
}

// Componente de animación de escritura de texto
export function TypewriterAnimation({ text, speed = 50, ...props }) {
  const [displayText, setDisplayText] = useState("")
  const [currentIndex, setCurrentIndex] = useState(0)
  
  useEffect(() => {
    if (currentIndex < text.length) {
      const timeout = setTimeout(() => {
        setDisplayText(prev => prev + text[currentIndex])
        setCurrentIndex(prev => prev + 1)
      }, speed)
      
      return () => clearTimeout(timeout)
    }
  }, [currentIndex, text, speed])
  
  return (
    <Frame
      background="transparent"
      width="auto"
      height="auto"
      {...props}
    >
      {displayText}<span style={{ opacity: currentIndex < text.length ? 1 : 0 }}>|</span>
    </Frame>
  )
}

// Componente de animación de desplazamiento infinito
export function InfiniteScroll({ children, direction = "left", speed = 20, ...props }) {
  const x = useMotionValue(0)
  const [width, setWidth] = useState(0)
  
  useEffect(() => {
    const element = document.getElementById(props.id)
    if (element) {
      setWidth(element.offsetWidth)
    }
  }, [props.id])
  
  useEffect(() => {
    if (width === 0) return
    
    const directionMultiplier = direction === "left" ? -1 : 1
    const controls = animate(x, directionMultiplier * width, {
      duration: width / speed,
      repeat: Infinity,
      repeatType: "loop",
      ease: "linear"
    })
    
    return controls.stop
  }, [width, direction, speed, x])
  
  return (
    <Frame
      background="transparent"
      width="auto"
      height="auto"
      style={{
        x,
        ...props.style
      }}
      {...props}
    >
      {children}
    </Frame>
  )
}

// Componente de animación de partículas
export function ParticlesAnimation({ count = 20, ...props }) {
  return (
    <Frame
      background="transparent"
      width="100%"
      height="100%"
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        overflow: "hidden",
        ...props.style
      }}
      {...props}
    >
      {Array.from({ length: count }).map((_, index) => (
        <Frame
          key={index}
          background="rgba(255, 255, 255, 0.2)"
          width={Math.random() * 10 + 2}
          height={Math.random() * 10 + 2}
          radius="50%"
          style={{
            position: "absolute",
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`
          }}
          animate={{
            y: [0, Math.random() * 100 - 50],
            x: [0, Math.random() * 100 - 50],
            opacity: [0.2, 0.8, 0.2]
          }}
          transition={{
            duration: Math.random() * 10 + 10,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />
      ))}
    </Frame>
  )
}

// Componente de animación de gradiente
export function AnimatedGradient({ colors, angle = 135, duration = 10, ...props }) {
  const [gradientPosition, setGradientPosition] = useState(0)
  
  useEffect(() => {
    const interval = setInterval(() => {
      setGradientPosition(prev => (prev + 1) % 100)
    }, duration * 10)
    
    return () => clearInterval(interval)
  }, [duration])
  
  return (
    <Frame
      background={{
        type: "gradient",
        gradient: {
          angle: angle,
          stops: colors.map((color, index) => ({
            position: (index * 100 / (colors.length - 1) + gradientPosition) % 100,
            color: color
          }))
        }
      }}
      width="100%"
      height="100%"
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        ...props.style
      }}
      {...props}
    />
  )
}

// Componente de animación de hover
export function HoverAnimation({ children, scale = 1.05, ...props }) {
  return (
    <Frame
      background="transparent"
      width="auto"
      height="auto"
      style={{
        transition: "all 0.3s ease",
        ...props.style
      }}
      whileHover={{
        scale: scale,
        ...props.hoverStyle
      }}
      {...props}
    >
      {children}
    </Frame>
  )
}

export default {
  useInView,
  FadeInUp,
  FadeInLeft,
  FadeInRight,
  ScaleIn,
  ParallaxScroll,
  CounterAnimation,
  TypewriterAnimation,
  InfiniteScroll,
  ParticlesAnimation,
  AnimatedGradient,
  HoverAnimation
}
