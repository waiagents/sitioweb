// blog-section.js - Componente de sección de Blog/Recursos para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal de la sección de Blog/Recursos
export function BlogSection() {
  // Animaciones para los elementos
  const controls = useAnimation()
  
  // Datos de los artículos del blog
  const blogPosts = [
    {
      title: "Cómo la IA está transformando la atención al cliente",
      excerpt: "Descubre las últimas innovaciones en automatización de atención al cliente y cómo están revolucionando la experiencia del usuario.",
      category: "Inteligencia Artificial",
      date: "15 Abril, 2025"
    },
    {
      title: "10 procesos que puedes automatizar hoy mismo",
      excerpt: "Una guía práctica sobre los procesos empresariales más comunes que pueden ser automatizados para mejorar la eficiencia operativa.",
      category: "Automatización",
      date: "8 Abril, 2025"
    },
    {
      title: "El futuro del trabajo: colaboración humano-IA",
      excerpt: "Análisis sobre cómo la colaboración entre humanos e inteligencia artificial está redefiniendo el panorama laboral en diversos sectores.",
      category: "Tendencias",
      date: "1 Abril, 2025"
    }
  ]
  
  // Efecto para detectar cuando la sección es visible
  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('blog')
      if (element) {
        const rect = element.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom >= 0
        
        if (isVisible) {
          controls.start({
            opacity: 1,
            y: 0,
            transition: { duration: 0.8, staggerChildren: 0.2 }
          })
        }
      }
    }
    
    window.addEventListener('scroll', handleScroll)
    // Trigger once on mount
    handleScroll()
    
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  return (
    <Frame
      name="BlogSection"
      id="blog"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: `${colors.background}` },
            { position: 100, color: "#E8EEF5" }
          ]
        }
      }}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Recursos y Blog
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Descubre las últimas tendencias en automatización e inteligencia artificial
      </Frame>

      {/* Artículos del blog */}
      <Frame
        name="BlogPostsContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
          gap: "30px",
          maxWidth: "1200px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        {blogPosts.map((post, index) => (
          <BlogPostCard 
            key={index}
            title={post.title} 
            excerpt={post.excerpt}
            category={post.category}
            date={post.date}
            delay={index * 0.1}
          />
        ))}
      </Frame>

      {/* Botón para ver más */}
      <Frame
        name="ViewMoreButton"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          padding: "15px 40px",
          borderRadius: "30px",
          fontSize: "16px",
          fontWeight: 600,
          color: colors.primaryButton,
          marginTop: "40px",
          cursor: "pointer",
          border: `2px solid ${colors.primaryButton}`,
          transition: "all 0.3s ease",
          opacity: 0,
          y: 20
        }}
        animate={controls}
        whileHover={{ 
          scale: 1.05,
          background: "rgba(124, 82, 237, 0.1)"
        }}
      >
        Ver Más Artículos
      </Frame>
      
      {/* Suscripción al newsletter */}
      <Frame
        name="NewsletterContainer"
        background="white"
        width="100%"
        height="auto"
        radius={20}
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "40px",
          marginTop: "80px",
          maxWidth: "800px",
          boxShadow: "0 20px 40px rgba(0, 0, 0, 0.05)",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        <Frame
          name="NewsletterTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "24px",
            fontWeight: 600,
            color: colors.primaryText,
            marginBottom: "15px",
            textAlign: "center"
          }}
        >
          Mantente actualizado
        </Frame>
        
        <Frame
          name="NewsletterDescription"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            color: colors.secondaryText,
            marginBottom: "30px",
            textAlign: "center",
            maxWidth: "600px"
          }}
        >
          Suscríbete a nuestro newsletter para recibir las últimas novedades sobre automatización, inteligencia artificial y consejos para mejorar la eficiencia de tu negocio.
        </Frame>
        
        <Frame
          name="NewsletterForm"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "flex",
            maxWidth: "500px",
            "@media (max-width: 576px)": {
              flexDirection: "column",
              gap: "15px"
            }
          }}
        >
          <Frame
            name="EmailInput"
            background="#F5F7FA"
            width="70%"
            height="auto"
            radius={10}
            style={{
              padding: "15px 20px",
              border: "1px solid #E0E5EC",
              "@media (max-width: 576px)": {
                width: "100%"
              }
            }}
          >
            <input
              type="email"
              placeholder="Tu correo electrónico"
              style={{
                width: "100%",
                border: "none",
                background: "transparent",
                fontSize: "16px",
                fontFamily: "Inter, sans-serif",
                color: colors.primaryText
              }}
            />
          </Frame>
          
          <Frame
            name="SubscribeButton"
            background={colors.primaryButton}
            width="30%"
            height="auto"
            radius={10}
            style={{
              padding: "15px 20px",
              marginLeft: "10px",
              fontSize: "16px",
              fontWeight: 600,
              color: "white",
              textAlign: "center",
              cursor: "pointer",
              boxShadow: "0 10px 20px rgba(124, 82, 237, 0.2)",
              "@media (max-width: 576px)": {
                width: "100%",
                marginLeft: 0
              }
            }}
            whileHover={{
              scale: 1.02,
              boxShadow: "0 15px 30px rgba(124, 82, 237, 0.3)"
            }}
          >
            Suscribirse
          </Frame>
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Tarjeta de Artículo de Blog
function BlogPostCard({ title, excerpt, category, date, delay = 0 }) {
  const controls = useAnimation()
  
  useEffect(() => {
    const timeout = setTimeout(() => {
      controls.start({
        opacity: 1,
        y: 0,
        transition: { duration: 0.5, type: "spring" }
      })
    }, delay * 1000)
    
    return () => clearTimeout(timeout)
  }, [])
  
  return (
    <Frame
      name={`BlogPost-${title}`}
      background="white"
      width="100%"
      height="auto"
      radius={15}
      style={{
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.05)",
        transition: "transform 0.3s ease, box-shadow 0.3s ease",
        opacity: 0,
        y: 30
      }}
      animate={controls}
      whileHover={{
        scale: 1.03,
        boxShadow: "0 15px 40px rgba(0, 0, 0, 0.1)"
      }}
    >
      <Frame
        name="PostImage"
        background={{
          type: "gradient",
          gradient: {
            angle: 135,
            stops: [
              { position: 0, color: colors.gradientStart },
              { position: 100, color: colors.gradientEnd }
            ]
          }
        }}
        width="100%"
        height={200}
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
        <Frame
          name="CategoryTag"
          background="rgba(255, 255, 255, 0.2)"
          width="auto"
          height="auto"
          style={{
            padding: "5px 15px",
            borderRadius: "20px",
            fontSize: "12px",
            fontWeight: 500,
            color: "white"
          }}
        >
          {category}
        </Frame>
      </Frame>
      <Frame
        name="PostContent"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          padding: "25px",
          display: "flex",
          flexDirection: "column",
          gap: "15px"
        }}
      >
        <Frame
          name="PostDate"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "14px",
            color: colors.secondaryText
          }}
        >
          {date}
        </Frame>
        <Frame
          name="PostTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "20px",
            fontWeight: 600,
            color: colors.primaryText,
            lineHeight: 1.3
          }}
        >
          {title}
        </Frame>
        <Frame
          name="PostExcerpt"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            lineHeight: 1.6,
            color: colors.secondaryText
          }}
        >
          {excerpt}
        </Frame>
        <Frame
          name="ReadMoreLink"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            fontWeight: 600,
            color: colors.primaryButton,
            marginTop: "10px",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: "5px"
          }}
          whileHover={{
            x: 5
          }}
        >
          Leer más
          <span style={{ fontSize: "20px" }}>→</span>
        </Frame>
      </Frame>
    </Frame>
  )
}

export default BlogSection
