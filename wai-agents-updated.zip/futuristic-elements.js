// futuristic-elements.js - Componentes futuristas para WAI Agents

import { 
  Frame, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente de partículas flotantes (simulando datos o conexiones)
export function FloatingParticles({ count = 50, ...props }) {
  return (
    <Frame
      name="FloatingParticles"
      background="transparent"
      width="100%"
      height="100%"
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        overflow: "hidden",
        pointerEvents: "none",
        zIndex: 1,
        ...props.style
      }}
      {...props}
    >
      {Array.from({ length: count }).map((_, index) => (
        <Frame
          key={index}
          name={`Particle-${index}`}
          background={index % 3 === 0 ? colors.primaryButton : index % 3 === 1 ? colors.secondaryButton : "rgba(255, 255, 255, 0.7)"}
          width={Math.random() * 6 + 2}
          height={Math.random() * 6 + 2}
          radius="50%"
          style={{
            position: "absolute",
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            opacity: Math.random() * 0.5 + 0.2
          }}
          animate={{
            y: [0, Math.random() * 100 - 50],
            x: [0, Math.random() * 100 - 50],
            opacity: [0.2, 0.7, 0.2]
          }}
          transition={{
            duration: Math.random() * 15 + 10,
            repeat: Infinity,
            repeatType: "reverse",
            ease: "easeInOut"
          }}
        />
      ))}
    </Frame>
  )
}

// Componente de líneas de conexión (simulando cables y conexiones)
export function ConnectionLines({ count = 10, ...props }) {
  return (
    <Frame
      name="ConnectionLines"
      background="transparent"
      width="100%"
      height="100%"
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        overflow: "hidden",
        pointerEvents: "none",
        zIndex: 1,
        ...props.style
      }}
      {...props}
    >
      <svg width="100%" height="100%" style={{ position: "absolute", top: 0, left: 0 }}>
        {Array.from({ length: count }).map((_, index) => {
          const startX = Math.random() * 100;
          const startY = Math.random() * 100;
          const endX = Math.random() * 100;
          const endY = Math.random() * 100;
          const controlX1 = (startX + endX) / 2 + (Math.random() * 20 - 10);
          const controlY1 = (startY + endY) / 2 + (Math.random() * 20 - 10);
          
          return (
            <path
              key={index}
              d={`M ${startX}% ${startY}% Q ${controlX1}% ${controlY1}% ${endX}% ${endY}%`}
              stroke={index % 2 === 0 ? colors.primaryButton : colors.secondaryButton}
              strokeWidth={Math.random() * 1.5 + 0.5}
              fill="none"
              strokeDasharray="5,5"
              opacity={Math.random() * 0.3 + 0.1}
              style={{
                animation: `dash ${Math.random() * 10 + 20}s linear infinite`
              }}
            />
          );
        })}
      </svg>
      
      <style>
        {`
          @keyframes dash {
            to {
              stroke-dashoffset: 1000;
            }
          }
        `}
      </style>
    </Frame>
  )
}

// Componente de robot animado
export function AnimatedRobot({ ...props }) {
  const [isHovered, setIsHovered] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  
  useEffect(() => {
    // Iniciar animación aleatoria cada cierto tiempo
    const interval = setInterval(() => {
      if (!isHovered) {
        setIsAnimating(true);
        setTimeout(() => setIsAnimating(false), 2000);
      }
    }, 5000);
    
    return () => clearInterval(interval);
  }, [isHovered]);
  
  return (
    <Frame
      name="AnimatedRobot"
      background="transparent"
      width={120}
      height={150}
      style={{
        position: "relative",
        ...props.style
      }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      {...props}
    >
      {/* Cabeza del robot */}
      <Frame
        name="RobotHead"
        background={`linear-gradient(135deg, ${colors.gradientStart}, ${colors.gradientEnd})`}
        width={60}
        height={60}
        radius={15}
        style={{
          position: "absolute",
          top: 0,
          left: "50%",
          transform: "translateX(-50%)",
          boxShadow: "0 5px 15px rgba(0, 0, 0, 0.2)"
        }}
        animate={isHovered || isAnimating ? {
          rotate: [0, -10, 10, -5, 5, 0],
          transition: { duration: 1 }
        } : {}}
      >
        {/* Ojos del robot */}
        <Frame
          name="RobotEyes"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            position: "absolute",
            top: "30%",
            left: 0,
            display: "flex",
            justifyContent: "space-around",
            padding: "0 10px"
          }}
        >
          <Frame
            name="LeftEye"
            background="#48C2F0"
            width={12}
            height={isHovered || isAnimating ? 6 : 12}
            radius={isHovered || isAnimating ? 3 : 6}
            style={{
              boxShadow: "0 0 10px rgba(72, 194, 240, 0.7)",
              transition: "all 0.3s ease"
            }}
          />
          <Frame
            name="RightEye"
            background="#48C2F0"
            width={12}
            height={isHovered || isAnimating ? 6 : 12}
            radius={isHovered || isAnimating ? 3 : 6}
            style={{
              boxShadow: "0 0 10px rgba(72, 194, 240, 0.7)",
              transition: "all 0.3s ease"
            }}
          />
        </Frame>
        
        {/* Boca del robot */}
        <Frame
          name="RobotMouth"
          background="#F2F5F9"
          width={30}
          height={5}
          radius={2}
          style={{
            position: "absolute",
            bottom: "20%",
            left: "50%",
            transform: "translateX(-50%)"
          }}
          animate={isHovered || isAnimating ? {
            width: [30, 20, 40, 30],
            transition: { duration: 1 }
          } : {}}
        />
        
        {/* Antena */}
        <Frame
          name="RobotAntenna"
          background="transparent"
          width={2}
          height={15}
          style={{
            position: "absolute",
            top: -15,
            left: "50%",
            transform: "translateX(-50%)",
            backgroundColor: "#F2F5F9"
          }}
        >
          <Frame
            name="AntennaTip"
            background="#48C2F0"
            width={8}
            height={8}
            radius="50%"
            style={{
              position: "absolute",
              top: -4,
              left: "50%",
              transform: "translateX(-50%)",
              boxShadow: "0 0 10px rgba(72, 194, 240, 0.7)"
            }}
            animate={{
              opacity: [0.5, 1, 0.5],
              scale: [1, 1.2, 1]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatType: "reverse"
            }}
          />
        </Frame>
      </Frame>
      
      {/* Cuerpo del robot */}
      <Frame
        name="RobotBody"
        background={`linear-gradient(135deg, ${colors.gradientStart}, ${colors.gradientEnd})`}
        width={80}
        height={70}
        radius={10}
        style={{
          position: "absolute",
          top: 70,
          left: "50%",
          transform: "translateX(-50%)",
          boxShadow: "0 5px 15px rgba(0, 0, 0, 0.2)"
        }}
      >
        {/* Luces del cuerpo */}
        <Frame
          name="BodyLights"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            position: "absolute",
            top: "30%",
            left: 0,
            display: "flex",
            justifyContent: "space-around",
            padding: "0 15px"
          }}
        >
          {[0, 1, 2].map(index => (
            <Frame
              key={index}
              name={`Light-${index}`}
              background="#48C2F0"
              width={10}
              height={10}
              radius="50%"
              style={{
                boxShadow: "0 0 10px rgba(72, 194, 240, 0.7)"
              }}
              animate={{
                opacity: [0.5, 1, 0.5],
                scale: [1, 1.2, 1]
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                repeatType: "reverse",
                delay: index * 0.5
              }}
            />
          ))}
        </Frame>
      </Frame>
      
      {/* Brazos del robot */}
      <Frame
        name="LeftArm"
        background={colors.secondaryButton}
        width={10}
        height={50}
        radius={5}
        style={{
          position: "absolute",
          top: 80,
          left: 10,
          transformOrigin: "top center"
        }}
        animate={isHovered || isAnimating ? {
          rotate: [0, -30, 0],
          transition: { duration: 1 }
        } : {}}
      />
      
      <Frame
        name="RightArm"
        background={colors.secondaryButton}
        width={10}
        height={50}
        radius={5}
        style={{
          position: "absolute",
          top: 80,
          right: 10,
          transformOrigin: "top center"
        }}
        animate={isHovered || isAnimating ? {
          rotate: [0, 30, 0],
          transition: { duration: 1 }
        } : {}}
      />
      
      {/* Piernas del robot */}
      <Frame
        name="LeftLeg"
        background={colors.secondaryButton}
        width={15}
        height={40}
        radius={5}
        style={{
          position: "absolute",
          top: 140,
          left: "30%",
          transform: "translateX(-50%)"
        }}
      />
      
      <Frame
        name="RightLeg"
        background={colors.secondaryButton}
        width={15}
        height={40}
        radius={5}
        style={{
          position: "absolute",
          top: 140,
          right: "30%",
          transform: "translateX(50%)"
        }}
      />
    </Frame>
  )
}

// Componente de código animado
export function AnimatedCode({ ...props }) {
  const [lines, setLines] = useState([]);
  
  useEffect(() => {
    // Generar líneas de código aleatorias
    const codeLines = [
      "function automateProcess() {",
      "  const ai = new WAIAgent();",
      "  ai.connect(client.data);",
      "  const response = ai.analyze();",
      "  if (response.needsAction) {",
      "    ai.executeWorkflow();",
      "  }",
      "  return ai.generateReport();",
      "}",
      "",
      "class WAIAgent extends AI {",
      "  constructor() {",
      "    super();",
      "    this.capabilities = [",
      "      'customer-service',",
      "      'data-analysis',",
      "      'process-automation'",
      "    ];",
      "  }",
      "}"
    ];
    
    setLines(codeLines);
  }, []);
  
  return (
    <Frame
      name="AnimatedCode"
      background="rgba(0, 0, 0, 0.8)"
      width={300}
      height={200}
      radius={10}
      style={{
        padding: "15px",
        fontFamily: "monospace",
        fontSize: "12px",
        color: "#F2F5F9",
        overflow: "hidden",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.3)",
        ...props.style
      }}
      {...props}
    >
      {lines.map((line, index) => (
        <Frame
          key={index}
          name={`CodeLine-${index}`}
          background="transparent"
          width="100%"
          height="auto"
          style={{
            marginBottom: "5px",
            opacity: 0,
            color: line.includes("WAIAgent") ? "#48C2F0" : 
                  line.includes("function") || line.includes("class") ? "#7C52ED" : 
                  line.includes("if") || line.includes("return") ? "#FFC107" : 
                  "#F2F5F9"
          }}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          {line}
        </Frame>
      ))}
    </Frame>
  )
}

// Componente de círculos de datos
export function DataCircles({ ...props }) {
  return (
    <Frame
      name="DataCircles"
      background="transparent"
      width={300}
      height={300}
      style={{
        position: "relative",
        ...props.style
      }}
      {...props}
    >
      {[0, 1, 2].map(index => (
        <Frame
          key={index}
          name={`DataCircle-${index}`}
          background="transparent"
          width={300 - index * 60}
          height={300 - index * 60}
          radius="50%"
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            border: `2px dashed ${index === 0 ? colors.primaryButton : index === 1 ? colors.secondaryButton : "#F2F5F9"}`,
            opacity: 0.6
          }}
          animate={{
            rotate: 360
          }}
          transition={{
            duration: 30 + index * 10,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      ))}
      
      {[0, 1, 2, 3, 4, 5].map(index => {
        const angle = (index * 60) % 360;
        const radius = 130;
        const x = radius * Math.cos(angle * Math.PI / 180);
        const y = radius * Math.sin(angle * Math.PI / 180);
        
        return (
          <Frame
            key={`DataNode-${index}`}
            name={`DataNode-${index}`}
            background={index % 2 === 0 ? colors.primaryButton : colors.secondaryButton}
            width={20}
            height={20}
            radius="50%"
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
              boxShadow: `0 0 15px ${index % 2 === 0 ? "rgba(124, 82, 237, 0.7)" : "rgba(72, 194, 240, 0.7)"}`
            }}
            animate={{
              scale: [1, 1.2, 1]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatType: "reverse",
              delay: index * 0.3
            }}
          />
        );
      })}
    </Frame>
  )
}

// Componente de asistente virtual con video explicativo
export function VirtualAssistant({ ...props }) {
  const [isOpen, setIsOpen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [hasBeenShown, setHasBeenShown] = useState(false);
  
  // Mostrar automáticamente después de 5 segundos si no se ha mostrado antes
  useEffect(() => {
    if (!hasBeenShown) {
      const timeout = setTimeout(() => {
        setIsOpen(true);
        setHasBeenShown(true);
      }, 5000);
      
      return () => clearTimeout(timeout);
    }
  }, [hasBeenShown]);
  
  return (
    <>
      {/* Botón flotante para abrir el asistente */}
      <Frame
        name="AssistantButton"
        background={`linear-gradient(135deg, ${colors.gradientStart}, ${colors.gradientEnd})`}
        width={60}
        height={60}
        radius="50%"
        style={{
          position: "fixed",
          bottom: "30px",
          right: "30px",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          cursor: "pointer",
          zIndex: 1000,
          boxShadow: "0 5px 15px rgba(0, 0, 0, 0.3)"
        }}
        whileHover={{
          scale: 1.1,
          boxShadow: "0 8px 25px rgba(0, 0, 0, 0.4)"
        }}
        onClick={() => setIsOpen(true)}
        {...props}
      >
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM13 17H11V15H13V17ZM13 13H11V7H13V13Z" fill="white"/>
        </svg>
        
        {/* Indicador de notificación */}
        <Frame
          name="NotificationIndicator"
          background="#FF5252"
          width={20}
          height={20}
          radius="50%"
          style={{
            position: "absolute",
            top: 0,
            right: 0,
            border: "2px solid white",
            display: !hasBeenShown ? "block" : "none"
          }}
          animate={{
            scale: [1, 1.2, 1]
          }}
          transition={{
            duration: 1,
            repeat: Infinity
          }}
        />
      </Frame>
      
      {/* Modal del asistente virtual */}
      {isOpen && (
        <Frame
          name="AssistantModal"
          background="rgba(0, 0, 0, 0.5)"
          width="100%"
          height="100%"
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            zIndex: 1001,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            padding: "20px"
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Frame
            name="AssistantContainer"
            background="white"
            width="100%"
            height="auto"
            style={{
              maxWidth: "800px",
              borderRadius: "20px",
              overflow: "hidden",
              boxShadow: "0 20px 40px rgba(0, 0, 0, 0.3)",
              maxHeight: "90vh",
              display: "flex",
              flexDirection: "column"
            }}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {/* Encabezado del asistente */}
            <Frame
              name="AssistantHeader"
              background={`linear-gradient(135deg, ${colors.gradientStart}, ${colors.gradientEnd})`}
              width="100%"
              height="auto"
              style={{
                padding: "20px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center"
              }}
            >
              <Frame
                name="AssistantTitle"
                background="transparent"
                width="auto"
                height="auto"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "15px"
                }}
              >
                <AnimatedRobot style={{ width: 40, height: 50 }} />
                <span style={{ color: "white", fontSize: "20px", fontWeight: 600 }}>Asistente WAI</span>
              </Frame>
              
              <Frame
                name="CloseButton"
                background="rgba(255, 255, 255, 0.2)"
                width={40}
                height={40}
                radius="50%"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  cursor: "pointer"
                }}
                whileHover={{
                  background: "rgba(255, 255, 255, 0.3)"
                }}
                onClick={() => setIsOpen(false)}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 6L6 18" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M6 6L18 18" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </Frame>
            </Frame>
            
            {/* Contenido del asistente */}
            <Frame
              name="AssistantContent"
              background="white"
              width="100%"
              height="auto"
              style={{
                padding: "30px",
                maxHeight: "60vh",
                overflow: "auto"
              }}
            >
              <Frame
                name="WelcomeMessage"
                background="transparent"
                width="100%"
                height="auto"
                style={{
                  marginBottom: "30px"
                }}
              >
                <Frame
                  name="WelcomeTitle"
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    fontSize: "24px",
                    fontWeight: 600,
                    color: colors.primaryText,
                    marginBottom: "15px"
                  }}
                >
                  Asistente WAI
                </Frame>
                
                <Frame
                  name="WelcomeSubtitle"
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    fontSize: "16px",
                    fontWeight: 500,
                    color: colors.secondaryText,
                    marginBottom: "15px"
                  }}
                >
                  Disponible 24/7
                </Frame>
                
                <Frame
                  name="WelcomeDescription"
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    fontSize: "16px",
                    lineHeight: 1.6,
                    color: colors.secondaryText
                  }}
                >
                  <p>¡Hola! Soy el asistente virtual de WAI Agents. ¿En qué puedo ayudarte hoy?</p>
                  <p>Puedo proporcionarte información sobre nuestros servicios de automatización o ayudarte a agendar una demostración personalizada.</p>
                </Frame>
              </Frame>
              
              {/* Video explicativo */}
              <Frame
                name="ExplainerVideo"
                background="#000"
                width="100%"
                height="auto"
                style={{
                  borderRadius: "15px",
                  overflow: "hidden",
                  aspectRatio: "16/9",
                  marginBottom: "30px",
                  position: "relative"
                }}
              >
                <Frame
                  name="VideoTitle"
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    fontSize: "18px",
                    fontWeight: 600,
                    color: colors.primaryText,
                    marginBottom: "15px"
                  }}
                >
                  Video Explicativo
                </Frame>
                
                {!isPlaying ? (
                  <Frame
                    name="VideoThumbnail"
                    background="#000"
                    width="100%"
                    height="100%"
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      cursor: "pointer"
                    }}
                    onClick={() => setIsPlaying(true)}
                  >
                    <img 
                      src="https://via.placeholder.com/800x450/3D157E/FFFFFF?text=Video+Explicativo+WAI+Agents" 
                      alt="Video Explicativo"
                      style={{
                        width: "100%",
                        height: "100%",
                        objectFit: "cover",
                        opacity: 0.7
                      }}
                    />
                    
                    <Frame
                      name="PlayButton"
                      background="rgba(124, 82, 237, 0.9)"
                      width={80}
                      height={80}
                      radius="50%"
                      style={{
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%, -50%)",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        boxShadow: "0 10px 30px rgba(124, 82, 237, 0.5)"
                      }}
                      whileHover={{
                        scale: 1.1,
                        background: "rgba(124, 82, 237, 1)"
                      }}
                    >
                      <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8 5V19L19 12L8 5Z" fill="white"/>
                      </svg>
                    </Frame>
                  </Frame>
                ) : (
                  <iframe
                    width="100%"
                    height="100%"
                    src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&rel=0"
                    title="Video Explicativo WAI Agents"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%"
                    }}
                  />
                )}
              </Frame>
              
              {/* Botones de acción */}
              <Frame
                name="ActionButtons"
                background="transparent"
                width="100%"
                height="auto"
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "15px",
                  marginTop: "20px"
                }}
              >
                <Frame
                  name="PrimaryButton"
                  background={`linear-gradient(135deg, ${colors.gradientStart}, ${colors.gradientEnd})`}
                  width="100%"
                  height="auto"
                  style={{
                    padding: "15px",
                    borderRadius: "30px",
                    color: "white",
                    fontSize: "16px",
                    fontWeight: 600,
                    cursor: "pointer",
                    textAlign: "center",
                    boxShadow: "0 5px 15px rgba(61, 21, 126, 0.3)"
                  }}
                  whileHover={{
                    scale: 1.02,
                    boxShadow: "0 8px 20px rgba(61, 21, 126, 0.4)"
                  }}
                  onClick={() => {
                    document.getElementById('availability')?.scrollIntoView({ behavior: 'smooth' });
                    setIsOpen(false);
                  }}
                >
                  Agendar Demostración
                </Frame>
                
                <Frame
                  name="SecondaryButton"
                  background="transparent"
                  width="100%"
                  height="auto"
                  style={{
                    padding: "15px",
                    borderRadius: "30px",
                    color: colors.primaryButton,
                    fontSize: "16px",
                    fontWeight: 600,
                    cursor: "pointer",
                    textAlign: "center",
                    border: `2px solid ${colors.primaryButton}`
                  }}
                  whileHover={{
                    backgroundColor: "rgba(124, 82, 237, 0.05)"
                  }}
                  onClick={() => {
                    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                    setIsOpen(false);
                  }}
                >
                  Contactar con Soporte
                </Frame>
              </Frame>
            </Frame>
          </Frame>
        </Frame>
      </>
    )
  }
}
                      key={index}
                      name={`Feature-${index}`}
                      background="transparent"
                      width="100%"
                      height="auto"
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "15px"
                      }}
                    >
                      <Frame
                        name={`FeatureIcon-${index}`}
                        background={colors.primaryButton}
                        width={30}
                        height={30}
                        radius="50%"
                        style={{
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          flexShrink: 0
                        }}
                      >
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M20 6L9 17L4 12" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </Frame>
                      
                      <span style={{ fontSize: "16px", color: colors.secondaryText }}>{feature}</span>
                    </Frame>
                  ))}
                </Frame>
              </Frame>
            </Frame>
            
            {/* Pie del asistente */}
            <Frame
              name="AssistantFooter"
              background="#f5f5f5"
              width="100%"
              height="auto"
              style={{
                padding: "20px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center"
              }}
            >
              <Frame
                name="ContactInfo"
                background="transparent"
                width="auto"
                height="auto"
                style={{
                  fontSize: "14px",
                  color: colors.secondaryText
                }}
              >
                ¿Preguntas? Contáctanos en info@waiagents.com
              </Frame>
              
              <Frame
                name="ActionButton"
                background={colors.primaryButton}
                width="auto"
                height="auto"
                style={{
                  padding: "10px 20px",
                  borderRadius: "30px",
                  color: "white",
                  fontWeight: 500,
                  cursor: "pointer"
                }}
                whileHover={{
                  scale: 1.05,
                  boxShadow: "0 5px 15px rgba(124, 82, 237, 0.3)"
                }}
                onClick={() => {
                  setIsOpen(false);
                  // Scroll to calendar section
                  document.getElementById('availability')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Agendar Demostración
              </Frame>
            </Frame>
          </Frame>
        </Frame>
      )}
    </>
  )
}

// Componente de proceso de automatización
export function AutomationProcess({ ...props }) {
  const [step, setStep] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setStep(prevStep => (prevStep + 1) % 5);
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);
  
  const steps = [
    { name: "Entrada de datos", color: "#48C2F0" },
    { name: "Análisis con IA", color: "#7C52ED" },
    { name: "Procesamiento", color: "#3D157E" },
    { name: "Automatización", color: "#06185F" },
    { name: "Resultado", color: "#4CAF50" }
  ];
  
  return (
    <Frame
      name="AutomationProcess"
      background="transparent"
      width="100%"
      height={150}
      style={{
        position: "relative",
        ...props.style
      }}
      {...props}
    >
      {/* Línea de proceso */}
      <Frame
        name="ProcessLine"
        background="#e0e0e0"
        width="80%"
        height={4}
        style={{
          position: "absolute",
          top: "50%",
          left: "10%",
          transform: "translateY(-50%)"
        }}
      />
      
      {/* Pasos del proceso */}
      {steps.map((s, index) => (
        <Frame
          key={index}
          name={`ProcessStep-${index}`}
          background={step === index ? s.color : "white"}
          width={50}
          height={50}
          radius="50%"
          style={{
            position: "absolute",
            top: "50%",
            left: `${10 + (index * 20)}%`,
            transform: "translate(-50%, -50%)",
            border: `2px solid ${s.color}`,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            color: step === index ? "white" : s.color,
            fontWeight: 600,
            zIndex: 2,
            boxShadow: step === index ? `0 0 20px ${s.color}80` : "none",
            transition: "all 0.3s ease"
          }}
        >
          {index + 1}
        </Frame>
      ))}
      
      {/* Etiquetas de los pasos */}
      {steps.map((s, index) => (
        <Frame
          key={index}
          name={`ProcessLabel-${index}`}
          background="transparent"
          width="auto"
          height="auto"
          style={{
            position: "absolute",
            top: "calc(50% + 40px)",
            left: `${10 + (index * 20)}%`,
            transform: "translateX(-50%)",
            color: step === index ? s.color : colors.secondaryText,
            fontWeight: step === index ? 600 : 400,
            fontSize: "14px",
            textAlign: "center",
            transition: "all 0.3s ease"
          }}
        >
          {s.name}
        </Frame>
      ))}
      
      {/* Indicador de progreso */}
      <Frame
        name="ProgressIndicator"
        background={steps[step].color}
        width={`${step * 20}%`}
        height={4}
        style={{
          position: "absolute",
          top: "50%",
          left: "10%",
          transform: "translateY(-50%)",
          zIndex: 1,
          transition: "width 0.5s ease"
        }}
      />
      
      {/* Datos fluyendo */}
      {[0, 1, 2, 3].map(index => (
        <Frame
          key={index}
          name={`DataFlow-${index}`}
          background={steps[Math.min(step, 4)].color}
          width={10}
          height={10}
          radius="50%"
          style={{
            position: "absolute",
            top: "50%",
            left: "10%",
            transform: "translateY(-50%)",
            opacity: 0
          }}
          animate={{
            left: ["10%", "90%"],
            opacity: [0, 1, 1, 0]
          }}
          transition={{
            duration: 4,
            delay: index * 1,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
    </Frame>
  )
}

export default {
  FloatingParticles,
  ConnectionLines,
  AnimatedRobot,
  AnimatedCode,
  DataCircles,
  VirtualAssistant,
  AutomationProcess
}
