// hero-futuristic.js - Componente de hero futurista para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"
import { 
  FloatingParticles, 
  ConnectionLines, 
  AnimatedRobot, 
  DataCircles 
} from "./futuristic-elements"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal del Hero
export function HeroFuturistic() {
  // Animaciones
  const controls = useAnimation()
  const titleControls = useAnimation()
  
  // Estado para el texto de escritura
  const [titleIndex, setTitleIndex] = useState(0)
  const titles = [
    "Automatizamos TODO con IA",
    "Transformamos la atención al cliente",
    "Optimizamos procesos empresariales",
    "Potenciamos tu negocio con tecnología"
  ]
  
  // Efecto para animar el título
  useEffect(() => {
    const interval = setInterval(() => {
      titleControls.start({
        opacity: 0,
        y: 20,
        transition: { duration: 0.5 }
      }).then(() => {
        setTitleIndex((prev) => (prev + 1) % titles.length)
        titleControls.start({
          opacity: 1,
          y: 0,
          transition: { duration: 0.5 }
        })
      })
    }, 5000)
    
    return () => clearInterval(interval)
  }, [])
  
  // Efecto para detectar cuando el hero es visible
  useEffect(() => {
    controls.start({
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, staggerChildren: 0.2 }
    })
  }, [])
  
  return (
    <Frame
      name="Hero"
      background={colors.background}
      width="100%"
      height="100vh"
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        position: "relative",
        overflow: "hidden",
        minHeight: "700px"
      }}
    >
      {/* Elementos decorativos futuristas */}
      <FloatingParticles count={70} />
      <ConnectionLines count={15} />
      
      {/* Fondo con gradiente */}
      <Frame
        name="HeroBackground"
        background={{
          type: "gradient",
          gradient: {
            angle: 135,
            stops: [
              { position: 0, color: "rgba(61, 21, 126, 0.05)" },
              { position: 100, color: "rgba(6, 24, 95, 0.1)" }
            ]
          }
        }}
        width="100%"
        height="100%"
        style={{
          position: "absolute",
          top: 0,
          left: 0
        }}
      />
      
      {/* Círculos decorativos */}
      <Frame
        name="DecorativeCircles"
        background="transparent"
        width="100%"
        height="100%"
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          overflow: "hidden",
          pointerEvents: "none"
        }}
      >
        <Frame
          name="Circle1"
          background="radial-gradient(circle, rgba(124, 82, 237, 0.1) 0%, rgba(124, 82, 237, 0) 70%)"
          width={800}
          height={800}
          radius="50%"
          style={{
            position: "absolute",
            top: "-300px",
            right: "-200px"
          }}
        />
        
        <Frame
          name="Circle2"
          background="radial-gradient(circle, rgba(72, 194, 240, 0.1) 0%, rgba(72, 194, 240, 0) 70%)"
          width={600}
          height={600}
          radius="50%"
          style={{
            position: "absolute",
            bottom: "-200px",
            left: "-100px"
          }}
        />
      </Frame>
      
      {/* Contenido principal */}
      <Frame
        name="HeroContent"
        background="transparent"
        width="90%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          textAlign: "center",
          maxWidth: "1200px",
          padding: "0 20px",
          zIndex: 2
        }}
        initial={{ opacity: 0, y: 50 }}
        animate={controls}
      >
        {/* Título principal */}
        <Frame
          name="HeroTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "clamp(2.5rem, 5vw, 4rem)",
            fontWeight: 700,
            color: colors.primaryText,
            marginBottom: "20px",
            lineHeight: 1.2,
            minHeight: "120px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}
          animate={titleControls}
        >
          Auto
        </Frame>
        
        {/* Subtítulo */}
        <Frame
          name="HeroSubtitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "clamp(1.1rem, 2vw, 1.5rem)",
            fontWeight: 400,
            color: colors.secondaryText,
            marginBottom: "40px",
            maxWidth: "800px",
            lineHeight: 1.6
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
        >
          Soluciones de IA personalizadas para optimizar procesos y aumentar la productividad
        </Frame>
        
        {/* Botones de acción */}
        <Frame
          name="HeroButtons"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            display: "flex",
            gap: "20px",
            marginBottom: "60px",
            flexWrap: "wrap",
            justifyContent: "center"
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          <Frame
            name="PrimaryButton"
            background={{
              type: "gradient",
              gradient: {
                angle: 135,
                stops: [
                  { position: 0, color: colors.gradientStart },
                  { position: 100, color: colors.gradientEnd }
                ]
              }
            }}
            width="auto"
            height="auto"
            style={{
              padding: "15px 30px",
              borderRadius: "30px",
              color: "white",
              fontSize: "18px",
              fontWeight: 600,
              cursor: "pointer",
              boxShadow: "0 10px 20px rgba(61, 21, 126, 0.3)",
              position: "relative",
              overflow: "hidden"
            }}
            whileHover={{
              scale: 1.05,
              boxShadow: "0 15px 30px rgba(61, 21, 126, 0.4)"
            }}
            onClick={() => {
              document.getElementById('availability')?.scrollIntoView({ behavior: 'smooth' })
            }}
          >
            <span style={{ position: "relative", zIndex: 2 }}>Agendar Demostración</span>
            
            {/* Efecto de brillo */}
            <Frame
              name="ButtonGlow"
              background="linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 50%, rgba(255,255,255,0) 100%)"
              width="30%"
              height="100%"
              style={{
                position: "absolute",
                top: 0,
                left: "-30%",
                zIndex: 1
              }}
              animate={{
                left: ["0%", "130%"]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 3
              }}
            />
          </Frame>
          
          <Frame
            name="SecondaryButton"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              padding: "15px 30px",
              borderRadius: "30px",
              color: colors.primaryButton,
              fontSize: "18px",
              fontWeight: 600,
              cursor: "pointer",
              border: `2px solid ${colors.primaryButton}`,
              display: "flex",
              alignItems: "center",
              gap: "10px"
            }}
            whileHover={{
              scale: 1.05,
              backgroundColor: "rgba(124, 82, 237, 0.05)"
            }}
            onClick={() => {
              document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })
            }}
          >
            <span>Nuestros Servicios</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M5 12H19" stroke={colors.primaryButton} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M12 5L19 12L12 19" stroke={colors.primaryButton} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </Frame>
        </Frame>
        
        {/* Elementos visuales futuristas */}
        <Frame
          name="HeroVisuals"
          background="transparent"
          width="100%"
          height="300px"
          style={{
            display: "flex",
            justifyContent: "space-around",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "20px"
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7, duration: 1 }}
        >
          <Frame
            name="RobotVisual"
            background="transparent"
            width="30%"
            height="100%"
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              minWidth: "250px"
            }}
          >
            <AnimatedRobot style={{ width: 150, height: 200 }} />
          </Frame>
          
          <Frame
            name="DataVisual"
            background="transparent"
            width="30%"
            height="100%"
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              minWidth: "250px"
            }}
          >
            <DataCircles />
          </Frame>
          
          <Frame
            name="StatsVisual"
            background="rgba(255, 255, 255, 0.7)"
            width="30%"
            height="80%"
            style={{
              borderRadius: "20px",
              padding: "20px",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-around",
              boxShadow: "0 10px 30px rgba(0, 0, 0, 0.05)",
              backdropFilter: "blur(10px)",
              minWidth: "250px"
            }}
          >
            <Frame
              name="StatTitle"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "18px",
                fontWeight: 600,
                color: colors.primaryText,
                marginBottom: "20px",
                textAlign: "center"
              }}
            >
              Automatización
            </Frame>
            
            <Frame
              name="StatValue"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "24px",
                fontWeight: 700,
                color: colors.primaryButton,
                textAlign: "center",
                marginBottom: "10px"
              }}
            >
              Ahorra hasta 40 horas semanales
            </Frame>
          </Frame>
          </Frame>
        </Frame>
      </Frame>
      
      {/* Scroll indicator */}
      <Frame
        name="ScrollIndicator"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          position: "absolute",
          bottom: "30px",
          left: "50%",
          transform: "translateX(-50%)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "10px",
          cursor: "pointer"
        }}
        whileHover={{
          y: 5
        }}
        onClick={() => {
          document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })
        }}
      >
        <span style={{ fontSize: "14px", color: colors.secondaryText }}>Descubre más</span>
        <Frame
          name="ScrollArrow"
          background="transparent"
          width={30}
          height={30}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
          }}
          animate={{
            y: [0, 10, 0]
          }}
          transition={{
            duration: 2,
            repeat: Infinity
          }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 5V19" stroke={colors.secondaryText} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M19 12L12 19L5 12" stroke={colors.secondaryText} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </Frame>
      </Frame>
    </Frame>
  )
}

export default HeroFuturistic
