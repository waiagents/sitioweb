// WAI Agents - Optimización de rendimiento
// Funciones para optimizar el rendimiento del sitio web

// Variables globales
let imagesLazyLoaded = false;
let scriptsDeferred = false;
let fontsOptimized = false;

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  // Inicializar lazy loading de imágenes
  initLazyLoading();
  
  // Inicializar carga diferida de scripts
  initDeferredScripts();
  
  // Inicializar optimización de fuentes
  initFontOptimization();
  
  // Registrar service worker
  registerServiceWorker();
  
  // Inicializar precarga de recursos críticos
  initResourcePreloading();
});

// Inicializar lazy loading de imágenes
function initLazyLoading() {
  if (imagesLazyLoaded) return;
  
  // Verificar soporte nativo de lazy loading
  if ('loading' in HTMLImageElement.prototype) {
    // Lazy loading nativo
    const images = document.querySelectorAll('img[data-src]');
    images.forEach(img => {
      img.src = img.dataset.src;
      img.loading = 'lazy';
      img.removeAttribute('data-src');
    });
  } else {
    // Lazy loading con Intersection Observer
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    if ('IntersectionObserver' in window) {
      const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const lazyImage = entry.target;
            lazyImage.src = lazyImage.dataset.src;
            lazyImage.removeAttribute('data-src');
            imageObserver.unobserve(lazyImage);
          }
        });
      });
      
      lazyImages.forEach(lazyImage => {
        imageObserver.observe(lazyImage);
      });
    } else {
      // Fallback para navegadores sin soporte
      let active = false;
      
      const lazyLoad = () => {
        if (active === false) {
          active = true;
          
          setTimeout(() => {
            lazyImages.forEach(lazyImage => {
              if ((lazyImage.getBoundingClientRect().top <= window.innerHeight && lazyImage.getBoundingClientRect().bottom >= 0) && getComputedStyle(lazyImage).display !== 'none') {
                lazyImage.src = lazyImage.dataset.src;
                lazyImage.removeAttribute('data-src');
                
                lazyImages = lazyImages.filter(image => image !== lazyImage);
                
                if (lazyImages.length === 0) {
                  document.removeEventListener('scroll', lazyLoad);
                  window.removeEventListener('resize', lazyLoad);
                  window.removeEventListener('orientationchange', lazyLoad);
                }
              }
            });
            
            active = false;
          }, 200);
        }
      };
      
      document.addEventListener('scroll', lazyLoad);
      window.addEventListener('resize', lazyLoad);
      window.addEventListener('orientationchange', lazyLoad);
      lazyLoad();
    }
  }
  
  imagesLazyLoaded = true;
  console.log('Lazy loading de imágenes inicializado');
}

// Inicializar carga diferida de scripts
function initDeferredScripts() {
  if (scriptsDeferred) return;
  
  // Cargar scripts no críticos después de que la página esté completamente cargada
  window.addEventListener('load', () => {
    // Lista de scripts no críticos
    const nonCriticalScripts = [
      '/js/google-calendar.js',
      '/js/futuristic-effects.js'
    ];
    
    // Cargar cada script
    nonCriticalScripts.forEach(scriptSrc => {
      const script = document.createElement('script');
      script.src = scriptSrc;
      script.defer = true;
      document.body.appendChild(script);
    });
    
    console.log('Scripts no críticos cargados');
  });
  
  scriptsDeferred = true;
  console.log('Carga diferida de scripts inicializada');
}

// Inicializar optimización de fuentes
function initFontOptimization() {
  if (fontsOptimized) return;
  
  // Verificar soporte de Font Loading API
  if ('fonts' in document) {
    // Cargar fuentes críticas primero
    Promise.all([
      document.fonts.load('1em Roboto'),
      document.fonts.load('700 1em Roboto')
    ]).then(() => {
      document.documentElement.classList.add('fonts-loaded');
      console.log('Fuentes críticas cargadas');
    });
  }
  
  fontsOptimized = true;
  console.log('Optimización de fuentes inicializada');
}

// Registrar service worker
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/js/service-worker.js')
        .then(registration => {
          console.log('Service Worker registrado con éxito:', registration.scope);
        })
        .catch(error => {
          console.log('Error al registrar el Service Worker:', error);
        });
    });
  }
}

// Inicializar precarga de recursos críticos
function initResourcePreloading() {
  // Verificar soporte de Fetch API
  if ('fetch' in window) {
    // Lista de recursos críticos a precargar
    const criticalResources = [
      '/images/wai-logo.png',
      '/images/favicon.png'
    ];
    
    // Precargar cada recurso
    criticalResources.forEach(resource => {
      const preloadLink = document.createElement('link');
      preloadLink.rel = 'preload';
      preloadLink.href = resource;
      preloadLink.as = resource.endsWith('.png') || resource.endsWith('.jpg') ? 'image' : 'script';
      document.head.appendChild(preloadLink);
    });
    
    console.log('Recursos críticos precargados');
  }
}

// Optimizar animaciones
function optimizeAnimations() {
  // Verificar si el navegador está en segundo plano o la pestaña no está visible
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      // Pausar animaciones cuando la página no está visible
      document.body.classList.add('animations-paused');
    } else {
      // Reanudar animaciones cuando la página es visible
      document.body.classList.remove('animations-paused');
    }
  });
  
  // Reducir animaciones en dispositivos de bajo rendimiento o con preferencia de movimiento reducido
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.body.classList.add('reduced-motion');
  }
}

// Optimizar imágenes
function optimizeImages() {
  // Verificar soporte de WebP
  const canUseWebP = () => {
    const elem = document.createElement('canvas');
    if (elem.getContext && elem.getContext('2d')) {
      return elem.toDataURL('image/webp').indexOf('data:image/webp') === 0;
    }
    return false;
  };
  
  // Si el navegador soporta WebP, usar imágenes WebP
  if (canUseWebP()) {
    document.body.classList.add('webp-support');
    
    // Reemplazar imágenes JPG/PNG por WebP
    const images = document.querySelectorAll('img[data-webp]');
    images.forEach(img => {
      img.src = img.dataset.webp;
    });
    
    console.log('Imágenes WebP habilitadas');
  }
}

// Optimizar CSS
function optimizeCSS() {
  // Cargar CSS crítico inline y el resto de forma asíncrona
  const loadCSS = href => {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = href;
    link.media = 'print';
    document.head.appendChild(link);
    
    setTimeout(() => {
      link.media = 'all';
    }, 0);
  };
  
  // CSS no crítico
  const nonCriticalCSS = [
    '/css/animations.css',
    '/css/sections.css'
  ];
  
  // Cargar CSS no crítico de forma asíncrona
  window.addEventListener('load', () => {
    nonCriticalCSS.forEach(loadCSS);
    console.log('CSS no crítico cargado');
  });
}

// Exportar funciones para uso global
window.Performance = {
  lazyLoad: initLazyLoading,
  deferScripts: initDeferredScripts,
  optimizeFonts: initFontOptimization,
  optimizeAnimations: optimizeAnimations,
  optimizeImages: optimizeImages,
  optimizeCSS: optimizeCSS
};
