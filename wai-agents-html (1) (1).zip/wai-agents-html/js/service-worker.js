// WAI Agents - Service Worker
// Implementación de service worker para soporte offline y mejora de rendimiento

// Nombre de la caché
const CACHE_NAME = 'wai-agents-cache-v1';

// Archivos a cachear
const urlsToCache = [
  '/',
  '/index.html',
  '/css/normalize.css',
  '/css/styles.css',
  '/css/animations.css',
  '/css/responsive.css',
  '/css/sections.css',
  '/js/main.js',
  '/js/animations.js',
  '/js/assistant.js',
  '/js/calendar.js',
  '/js/videos.js',
  '/js/futuristic-effects.js',
  '/js/google-calendar.js',
  '/images/wai-logo.png',
  '/images/wai-logo-white.png',
  '/images/favicon.png'
];

// Instalación del service worker
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache abierta');
        return cache.addAll(urlsToCache);
      })
  );
});

// Activación del service worker
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Interceptar peticiones
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Devolver la respuesta cacheada si existe
        if (response) {
          return response;
        }
        
        // Clonar la petición
        const fetchRequest = event.request.clone();
        
        // Hacer la petición a la red
        return fetch(fetchRequest).then(
          response => {
            // Verificar si la respuesta es válida
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Clonar la respuesta
            const responseToCache = response.clone();
            
            // Cachear la respuesta
            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });
            
            return response;
          }
        );
      })
  );
});
