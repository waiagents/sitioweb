// WAI Agents - Efectos futuristas
// Implementación de efectos visuales futuristas para el sitio web

// Variables globales
let particlesInitialized = false;
let robotsInitialized = false;
let dataFlowInitialized = false;

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  // Inicializar partículas
  initParticles();
  
  // Inicializar robots
  initRobots();
  
  // Inicializar flujo de datos
  initDataFlow();
  
  // Inicializar efectos de hover
  initHoverEffects();
  
  // Inicializar efectos de scroll
  initScrollEffects();
});

// Inicializar partículas
function initParticles() {
  if (particlesInitialized) return;
  
  // Crear contenedores de partículas
  const sections = document.querySelectorAll('.hero, .services, .process, .testimonials, .blog, .contact, .availability');
  
  sections.forEach(section => {
    // Crear contenedor de partículas
    const particlesContainer = document.createElement('div');
    particlesContainer.className = 'tech-particles';
    
    // Crear partículas
    for (let i = 0; i < 20; i++) {
      const particle = document.createElement('div');
      particle.className = 'tech-particle';
      
      // Posición aleatoria
      const x = Math.random() * 100;
      const y = Math.random() * 100;
      
      // Tamaño aleatorio
      const size = 2 + Math.random() * 5;
      
      // Estilo
      particle.style.left = `${x}%`;
      particle.style.top = `${y}%`;
      particle.style.width = `${size}px`;
      particle.style.height = `${size}px`;
      
      // Animación
      const duration = 20 + Math.random() * 40;
      const delay = Math.random() * 10;
      
      particle.style.animation = `float ${duration}s ease-in-out ${delay}s infinite`;
      
      // Añadir al contenedor
      particlesContainer.appendChild(particle);
    }
    
    // Añadir al principio de la sección
    section.insertBefore(particlesContainer, section.firstChild);
    
    // Añadir líneas de conexión
    const connectionLines = document.createElement('div');
    connectionLines.className = 'connection-lines';
    section.insertBefore(connectionLines, section.firstChild);
  });
  
  particlesInitialized = true;
  console.log('Partículas inicializadas');
}

// Inicializar robots
function initRobots() {
  if (robotsInitialized) return;
  
  // Crear robots en secciones específicas
  const heroSection = document.querySelector('.hero');
  const servicesSection = document.querySelector('.services');
  const processSection = document.querySelector('.process');
  
  if (heroSection) {
    createRobot(heroSection, 'hero-robot', 'right', '10%', '70%');
  }
  
  if (servicesSection) {
    createRobot(servicesSection, 'services-robot', 'left', '5%', '30%');
  }
  
  if (processSection) {
    createRobot(processSection, 'process-robot', 'right', '5%', '60%');
  }
  
  robotsInitialized = true;
  console.log('Robots inicializados');
}

// Crear un robot
function createRobot(container, id, position, top, bottom) {
  // Crear contenedor del robot
  const robotContainer = document.createElement('div');
  robotContainer.className = 'robot';
  robotContainer.id = id;
  
  // Posición
  robotContainer.style.position = 'absolute';
  robotContainer.style[position] = '50px';
  robotContainer.style.top = top;
  robotContainer.style.zIndex = '1';
  
  // Estructura del robot
  robotContainer.innerHTML = `
    <div class="robot-head">
      <div class="robot-antenna">
        <div class="antenna-tip"></div>
      </div>
      <div class="robot-face">
        <div class="robot-eyes">
          <div class="robot-eye"></div>
          <div class="robot-eye"></div>
        </div>
        <div class="robot-mouth"></div>
      </div>
    </div>
    <div class="robot-body">
      <div class="robot-lights">
        <div class="robot-light"></div>
        <div class="robot-light"></div>
        <div class="robot-light"></div>
      </div>
    </div>
    <div class="robot-arms">
      <div class="robot-arm left"></div>
      <div class="robot-arm right"></div>
    </div>
    <div class="robot-legs">
      <div class="robot-leg"></div>
      <div class="robot-leg"></div>
    </div>
  `;
  
  // Añadir al contenedor
  container.appendChild(robotContainer);
  
  // Animar el robot
  animateRobot(robotContainer);
}

// Animar un robot
function animateRobot(robot) {
  // Animación de flotación
  const floatAnimation = [
    { transform: 'translateY(0)' },
    { transform: 'translateY(-10px)' },
    { transform: 'translateY(0)' }
  ];
  
  const floatTiming = {
    duration: 3000,
    iterations: Infinity,
    easing: 'ease-in-out'
  };
  
  robot.animate(floatAnimation, floatTiming);
  
  // Animación de los ojos
  const eyes = robot.querySelectorAll('.robot-eye');
  
  eyes.forEach(eye => {
    // Parpadeo
    setInterval(() => {
      eye.style.transform = 'scaleY(0.1)';
      setTimeout(() => {
        eye.style.transform = 'scaleY(1)';
      }, 200);
    }, 4000);
  });
  
  // Animación de las luces
  const lights = robot.querySelectorAll('.robot-light');
  
  lights.forEach((light, index) => {
    const glowAnimation = [
      { boxShadow: '0 0 5px rgba(72, 194, 240, 0.7)' },
      { boxShadow: '0 0 15px rgba(72, 194, 240, 1)' },
      { boxShadow: '0 0 5px rgba(72, 194, 240, 0.7)' }
    ];
    
    const glowTiming = {
      duration: 1500,
      iterations: Infinity,
      easing: 'ease-in-out',
      delay: index * 500
    };
    
    light.animate(glowAnimation, glowTiming);
  });
  
  // Animación de los brazos
  const leftArm = robot.querySelector('.robot-arm.left');
  const rightArm = robot.querySelector('.robot-arm.right');
  
  if (leftArm) {
    const leftArmAnimation = [
      { transform: 'rotate(0deg)' },
      { transform: 'rotate(15deg)' },
      { transform: 'rotate(-5deg)' },
      { transform: 'rotate(0deg)' }
    ];
    
    const leftArmTiming = {
      duration: 3000,
      iterations: Infinity,
      easing: 'ease-in-out'
    };
    
    leftArm.animate(leftArmAnimation, leftArmTiming);
  }
  
  if (rightArm) {
    const rightArmAnimation = [
      { transform: 'rotate(0deg)' },
      { transform: 'rotate(-15deg)' },
      { transform: 'rotate(5deg)' },
      { transform: 'rotate(0deg)' }
    ];
    
    const rightArmTiming = {
      duration: 3000,
      iterations: Infinity,
      easing: 'ease-in-out',
      delay: 1500
    };
    
    rightArm.animate(rightArmAnimation, rightArmTiming);
  }
}

// Inicializar flujo de datos
function initDataFlow() {
  if (dataFlowInitialized) return;
  
  // Crear flujo de datos en la sección de proceso
  const processLine = document.querySelector('.process-line');
  const dataFlow = document.querySelector('.data-flow');
  
  if (processLine && dataFlow) {
    // Crear partículas de datos
    for (let i = 0; i < 3; i++) {
      createDataParticle(dataFlow, i * 1000);
    }
  }
  
  dataFlowInitialized = true;
  console.log('Flujo de datos inicializado');
}

// Crear una partícula de datos
function createDataParticle(container, delay) {
  // Crear partícula
  const particle = document.createElement('div');
  particle.className = 'data-particle';
  
  // Estilo
  particle.style.position = 'absolute';
  particle.style.width = '10px';
  particle.style.height = '10px';
  particle.style.backgroundColor = '#7C52ED';
  particle.style.borderRadius = '50%';
  particle.style.boxShadow = '0 0 10px rgba(124, 82, 237, 0.7)';
  particle.style.top = '0';
  particle.style.left = '0';
  particle.style.transform = 'translateY(-3px)';
  
  // Añadir al contenedor
  container.appendChild(particle);
  
  // Animación
  setTimeout(() => {
    animateDataParticle(particle);
  }, delay);
}

// Animar una partícula de datos
function animateDataParticle(particle) {
  const animation = [
    { left: '0', opacity: 0 },
    { left: '10%', opacity: 1 },
    { left: '90%', opacity: 1 },
    { left: '100%', opacity: 0 }
  ];
  
  const timing = {
    duration: 3000,
    easing: 'linear',
    fill: 'forwards'
  };
  
  const anim = particle.animate(animation, timing);
  
  anim.onfinish = () => {
    // Reiniciar animación
    particle.style.left = '0';
    particle.style.opacity = '0';
    
    // Pequeña pausa antes de reiniciar
    setTimeout(() => {
      animateDataParticle(particle);
    }, 1000);
  };
}

// Inicializar efectos de hover
function initHoverEffects() {
  // Efecto de hover en botones
  const buttons = document.querySelectorAll('.btn-primary');
  
  buttons.forEach(button => {
    button.addEventListener('mouseenter', () => {
      const shine = document.createElement('div');
      shine.className = 'btn-shine';
      
      shine.style.position = 'absolute';
      shine.style.top = '0';
      shine.style.left = '-100%';
      shine.style.width = '100%';
      shine.style.height = '100%';
      shine.style.background = 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent)';
      shine.style.transition = '0.5s';
      
      button.style.position = 'relative';
      button.style.overflow = 'hidden';
      
      button.appendChild(shine);
      
      setTimeout(() => {
        shine.style.left = '100%';
      }, 10);
      
      setTimeout(() => {
        shine.remove();
      }, 500);
    });
  });
  
  // Efecto de hover en tarjetas de servicio
  const serviceCards = document.querySelectorAll('.service-card');
  
  serviceCards.forEach(card => {
    card.addEventListener('mouseenter', () => {
      const icon = card.querySelector('.service-icon');
      if (icon) {
        icon.style.transform = 'rotateY(180deg)';
        icon.style.transition = 'transform 0.6s';
      }
    });
    
    card.addEventListener('mouseleave', () => {
      const icon = card.querySelector('.service-icon');
      if (icon) {
        icon.style.transform = 'rotateY(0)';
      }
    });
  });
  
  // Efecto de hover en iconos de características
  const featureIcons = document.querySelectorAll('.feature-icon');
  
  featureIcons.forEach(icon => {
    icon.addEventListener('mouseenter', () => {
      icon.style.transform = 'rotate(360deg)';
      icon.style.transition = 'transform 0.6s';
    });
    
    icon.addEventListener('mouseleave', () => {
      icon.style.transform = 'rotate(0)';
    });
  });
}

// Inicializar efectos de scroll
function initScrollEffects() {
  // Elementos con animaciones
  const animatedElements = document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right, .scale-in');
  
  // Añadir clases de animación a elementos
  const sections = document.querySelectorAll('section');
  sections.forEach(section => {
    const sectionHeader = section.querySelector('.section-header');
    if (sectionHeader) {
      sectionHeader.classList.add('fade-in');
    }
    
    const contentElements = section.querySelectorAll('.about-image, .about-text, .service-card, .video-item, .timeline-step, .testimonial-item, .blog-card, .contact-info, .contact-form');
    contentElements.forEach((element, index) => {
      if (index % 2 === 0) {
        element.classList.add('slide-in-left');
      } else {
        element.classList.add('slide-in-right');
      }
    });
  });
  
  // Función para verificar si un elemento está en el viewport
  function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
      rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8
    );
  }
  
  // Función para mostrar elementos cuando están en el viewport
  function handleScroll() {
    animatedElements.forEach(element => {
      if (isElementInViewport(element)) {
        element.classList.add('visible');
      }
    });
  }
  
  // Event listener para el scroll
  window.addEventListener('scroll', handleScroll);
  
  // Verificar elementos visibles al cargar la página
  handleScroll();
}

// Exportar funciones para uso global
window.FuturisticEffects = {
  initParticles,
  initRobots,
  initDataFlow,
  initHoverEffects,
  initScrollEffects
};
