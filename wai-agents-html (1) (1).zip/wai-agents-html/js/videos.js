// WAI Agents - Funcionalidad de videos
// Manejo de videos de YouTube y reproductor de video

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  // Inicializar videos demostrativos
  initDemoVideos();
  
  // Inicializar video explicativo del asistente
  initExplainerVideo();
});

// Inicializar videos demostrativos
function initDemoVideos() {
  const videoWrappers = document.querySelectorAll('.video-wrapper');
  
  videoWrappers.forEach(wrapper => {
    const videoId = wrapper.getAttribute('data-video-id');
    const placeholder = wrapper.querySelector('.video-placeholder');
    const iframeContainer = wrapper.querySelector('.video-iframe');
    
    if (placeholder && iframeContainer && videoId) {
      placeholder.addEventListener('click', () => {
        loadYouTubeVideo(videoId, iframeContainer);
        placeholder.style.display = 'none';
        iframeContainer.style.display = 'block';
      });
    }
  });
}

// Inicializar video explicativo del asistente
function initExplainerVideo() {
  const videoPlaceholder = document.getElementById('video-placeholder');
  const videoIframe = document.getElementById('video-iframe');
  
  if (videoPlaceholder && videoIframe) {
    videoPlaceholder.addEventListener('click', () => {
      // ID de video explicativo - reemplazar con el ID real cuando esté disponible
      const explainerVideoId = 'VIDEO_ID_EXPLAINER';
      
      loadYouTubeVideo(explainerVideoId, videoIframe);
      videoPlaceholder.style.display = 'none';
      videoIframe.style.display = 'block';
    });
  }
}

// Cargar video de YouTube
function loadYouTubeVideo(videoId, container) {
  // Verificar si el ID es un placeholder
  if (videoId === 'VIDEO_ID_1' || videoId === 'VIDEO_ID_2' || videoId === 'VIDEO_ID_3' || videoId === 'VIDEO_ID_EXPLAINER') {
    // Mostrar mensaje para reemplazar el ID
    container.innerHTML = `
      <div class="video-placeholder-message">
        <h3>Video Demostrativo</h3>
        <p>Para ver este video, reemplaza el ID de placeholder en el código con un ID real de YouTube.</p>
        <code>Edita el archivo videos.js y reemplaza "${videoId}" con el ID de tu video de YouTube.</code>
      </div>
    `;
    return;
  }
  
  // Crear iframe para el video de YouTube
  const iframe = document.createElement('iframe');
  iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;
  iframe.width = '100%';
  iframe.height = '100%';
  iframe.frameBorder = '0';
  iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
  iframe.allowFullscreen = true;
  
  // Limpiar el contenedor y añadir el iframe
  container.innerHTML = '';
  container.appendChild(iframe);
}

// Función para actualizar los IDs de videos
function updateVideoIds(demoVideo1Id, demoVideo2Id, demoVideo3Id, explainerVideoId) {
  // Actualizar los IDs de los videos demostrativos
  const videoWrappers = document.querySelectorAll('.video-wrapper');
  
  if (videoWrappers.length >= 3) {
    videoWrappers[0].setAttribute('data-video-id', demoVideo1Id);
    videoWrappers[1].setAttribute('data-video-id', demoVideo2Id);
    videoWrappers[2].setAttribute('data-video-id', demoVideo3Id);
  }
  
  // Actualizar el ID del video explicativo
  const explainerVideo = document.getElementById('explainer-video');
  if (explainerVideo) {
    explainerVideo.setAttribute('data-video-id', explainerVideoId);
  }
  
  console.log('IDs de videos actualizados correctamente');
}

// Ejemplo de uso:
// updateVideoIds('abc123', 'def456', 'ghi789', 'jkl012');
