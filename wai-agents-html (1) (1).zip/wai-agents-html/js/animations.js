// WAI Agents - Animaciones JavaScript
// Animaciones avanzadas para elementos futuristas

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  // Inicializar animaciones del robot
  initRobotAnimations();
  
  // Inicializar animaciones de datos
  initDataAnimations();
  
  // Inicializar animaciones de conexiones
  initConnectionAnimations();
  
  // Inicializar animaciones de proceso
  initProcessAnimations();
  
  // Inicializar animaciones al hacer scroll
  initScrollAnimations();
});

// Inicializar animaciones del robot
function initRobotAnimations() {
  const robot = document.querySelector('.robot');
  
  if (robot) {
    // Animación de flotación
    animateFloat(robot, 10, 3000);
    
    // Animación de los ojos
    const robotEyes = document.querySelectorAll('.robot-eye');
    robotEyes.forEach(eye => {
      // Parpadeo
      setInterval(() => {
        eye.style.transform = 'scaleY(0.1)';
        setTimeout(() => {
          eye.style.transform = 'scaleY(1)';
        }, 200);
      }, 4000);
      
      // Movimiento de escaneo
      animateScan(eye);
    });
    
    // Animación de las luces
    const robotLights = document.querySelectorAll('.robot-light');
    robotLights.forEach((light, index) => {
      animatePulse(light, 0.7, 1, 1500, index * 500);
    });
    
    // Animación de los brazos
    const leftArm = document.querySelector('.robot-arm.left');
    const rightArm = document.querySelector('.robot-arm.right');
    
    if (leftArm && rightArm) {
      // Movimiento de los brazos
      animateWave(leftArm, -15, 5, 3000);
      animateWave(rightArm, 15, -5, 3000, 1500);
    }
  }
}

// Inicializar animaciones de datos
function initDataAnimations() {
  // Animación de círculos de datos
  const dataCircles = document.querySelectorAll('.data-circle');
  dataCircles.forEach((circle, index) => {
    animatePulse(circle, 1, 1.1, 3000, index * 500);
  });
  
  // Animación de nodos de datos
  const dataNodes = document.querySelectorAll('.data-node');
  dataNodes.forEach((node, index) => {
    animateFloat(node, 10, 3000, index * 300);
  });
}

// Inicializar animaciones de conexiones
function initConnectionAnimations() {
  const connectionLines = document.querySelector('.connection-lines');
  
  if (connectionLines) {
    // Crear partículas que se mueven a lo largo de las líneas
    for (let i = 0; i < 10; i++) {
      createMovingParticle(connectionLines);
    }
  }
}

// Inicializar animaciones de proceso
function initProcessAnimations() {
  const processLine = document.querySelector('.process-line');
  const dataFlow = document.querySelector('.data-flow');
  
  if (processLine && dataFlow) {
    // Crear partículas que se mueven a lo largo de la línea de proceso
    for (let i = 0; i < 3; i++) {
      createFlowingParticle(dataFlow, i * 1000);
    }
  }
}

// Inicializar animaciones al hacer scroll
function initScrollAnimations() {
  // Elementos con animaciones
  const animatedElements = document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right, .scale-in');
  
  // Función para verificar si un elemento está en el viewport
  function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
      rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8
    );
  }
  
  // Función para mostrar elementos cuando están en el viewport
  function handleScroll() {
    animatedElements.forEach(element => {
      if (isElementInViewport(element)) {
        element.classList.add('visible');
      }
    });
  }
  
  // Event listener para el scroll
  window.addEventListener('scroll', handleScroll);
  
  // Verificar elementos visibles al cargar la página
  handleScroll();
}

// Función para animar flotación
function animateFloat(element, distance, duration, delay = 0) {
  if (!element) return;
  
  // Posición inicial
  let startY = 0;
  
  // Animación
  setTimeout(() => {
    setInterval(() => {
      // Movimiento sinusoidal
      const y = startY + Math.sin(Date.now() / duration * Math.PI) * distance;
      element.style.transform = `translateY(${y}px)`;
    }, 16); // 60fps aproximadamente
  }, delay);
}

// Función para animar pulso
function animatePulse(element, minScale, maxScale, duration, delay = 0) {
  if (!element) return;
  
  // Animación
  setTimeout(() => {
    setInterval(() => {
      // Escala sinusoidal
      const scale = minScale + Math.sin(Date.now() / duration * Math.PI) * (maxScale - minScale);
      element.style.transform = `scale(${scale})`;
    }, 16); // 60fps aproximadamente
  }, delay);
}

// Función para animar escaneo
function animateScan(element) {
  if (!element) return;
  
  // Animación
  setInterval(() => {
    // Movimiento horizontal aleatorio
    const x = Math.random() * 6 - 3; // -3px a 3px
    element.style.transform = `translateX(${x}px)`;
  }, 500);
}

// Función para animar ondulación
function animateWave(element, maxAngle1, maxAngle2, duration, delay = 0) {
  if (!element) return;
  
  // Animación
  setTimeout(() => {
    setInterval(() => {
      // Rotación sinusoidal
      const angle = Math.sin(Date.now() / duration * Math.PI * 2) * maxAngle1 + 
                   Math.sin(Date.now() / (duration * 0.7) * Math.PI * 2) * maxAngle2;
      element.style.transform = `rotate(${angle}deg)`;
    }, 16); // 60fps aproximadamente
  }, delay);
}

// Función para crear partículas en movimiento
function createMovingParticle(container) {
  if (!container) return;
  
  // Crear partícula
  const particle = document.createElement('div');
  particle.className = 'moving-particle';
  particle.style.position = 'absolute';
  particle.style.width = '3px';
  particle.style.height = '3px';
  particle.style.backgroundColor = '#48C2F0';
  particle.style.borderRadius = '50%';
  particle.style.boxShadow = '0 0 5px rgba(72, 194, 240, 0.7)';
  
  // Posición inicial aleatoria
  const startX = Math.random() * 100;
  const startY = Math.random() * 100;
  particle.style.left = `${startX}%`;
  particle.style.top = `${startY}%`;
  
  // Añadir al contenedor
  container.appendChild(particle);
  
  // Animación
  animateParticle(particle);
}

// Función para animar partículas
function animateParticle(particle) {
  if (!particle) return;
  
  // Duración aleatoria
  const duration = 5000 + Math.random() * 5000;
  
  // Destino aleatorio
  const endX = Math.random() * 100;
  const endY = Math.random() * 100;
  
  // Animación
  particle.animate([
    { left: particle.style.left, top: particle.style.top },
    { left: `${endX}%`, top: `${endY}%` }
  ], {
    duration: duration,
    easing: 'ease-in-out',
    fill: 'forwards'
  }).onfinish = () => {
    // Actualizar posición
    particle.style.left = `${endX}%`;
    particle.style.top = `${endY}%`;
    
    // Continuar animación
    animateParticle(particle);
  };
}

// Función para crear partículas fluyentes
function createFlowingParticle(container, delay = 0) {
  if (!container) return;
  
  // Crear partícula
  const particle = document.createElement('div');
  particle.className = 'data-particle';
  particle.style.position = 'absolute';
  particle.style.width = '10px';
  particle.style.height = '10px';
  particle.style.backgroundColor = '#7C52ED';
  particle.style.borderRadius = '50%';
  particle.style.boxShadow = '0 0 10px rgba(124, 82, 237, 0.7)';
  particle.style.top = '0';
  particle.style.left = '0';
  particle.style.transform = 'translateY(-3px)';
  
  // Añadir al contenedor
  container.appendChild(particle);
  
  // Animación
  setTimeout(() => {
    animateFlowingParticle(particle);
  }, delay);
}

// Función para animar partículas fluyentes
function animateFlowingParticle(particle) {
  if (!particle) return;
  
  // Animación
  particle.animate([
    { left: '0', opacity: 0 },
    { left: '10%', opacity: 1 },
    { left: '90%', opacity: 1 },
    { left: '100%', opacity: 0 }
  ], {
    duration: 3000,
    easing: 'linear',
    fill: 'forwards'
  }).onfinish = () => {
    // Reiniciar animación
    particle.style.left = '0';
    particle.style.opacity = '0';
    
    // Pequeña pausa antes de reiniciar
    setTimeout(() => {
      animateFlowingParticle(particle);
    }, 1000);
  };
}

// Función para animar texto con efecto de escritura
function animateTyping(element, text, speed = 100) {
  if (!element) return;
  
  // Limpiar el elemento
  element.textContent = '';
  
  // Añadir clase de animación
  element.classList.add('typing-animation');
  
  // Animación de escritura
  let i = 0;
  const typeWriter = () => {
    if (i < text.length) {
      element.textContent += text.charAt(i);
      i++;
      setTimeout(typeWriter, speed);
    } else {
      // Quitar la animación después de completar
      setTimeout(() => {
        element.classList.remove('typing-animation');
      }, 1000);
    }
  };
  
  // Iniciar animación
  typeWriter();
}

// Exportar funciones para uso global
window.WAIAnimations = {
  float: animateFloat,
  pulse: animatePulse,
  wave: animateWave,
  typing: animateTyping
};
