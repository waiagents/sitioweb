// WAI Agents - Funcionalidad del asistente virtual
// Manejo del asistente virtual y sus interacciones

// Variables globales
let assistantShown = false;
let assistantDismissed = false;

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  // Inicializar el asistente virtual
  initAssistant();
});

// Inicializar el asistente virtual
function initAssistant() {
  const assistantButton = document.getElementById('assistant-button');
  const assistantModal = document.getElementById('assistant-modal');
  const assistantClose = document.getElementById('assistant-close');
  const scheduleDemoBtn = document.getElementById('schedule-demo-btn');
  
  if (assistantButton && assistantModal && assistantClose) {
    // Mostrar el asistente automáticamente después de 5 segundos
    setTimeout(() => {
      if (!assistantShown && !assistantDismissed) {
        showAssistant();
      }
    }, 5000);
    
    // Event listeners
    assistantButton.addEventListener('click', toggleAssistant);
    assistantClose.addEventListener('click', () => {
      hideAssistant();
      assistantDismissed = true;
    });
    
    // Botón para agendar demostración
    if (scheduleDemoBtn) {
      scheduleDemoBtn.addEventListener('click', () => {
        hideAssistant();
        document.getElementById('availability').scrollIntoView({ behavior: 'smooth' });
      });
    }
    
    // Animación del robot
    animateRobot();
  }
}

// Mostrar el asistente
function showAssistant() {
  const assistantModal = document.getElementById('assistant-modal');
  const notificationBadge = document.getElementById('notification-badge');
  
  if (assistantModal) {
    assistantModal.classList.add('active');
    assistantShown = true;
    
    // Ocultar la notificación
    if (notificationBadge) {
      notificationBadge.style.display = 'none';
    }
  }
}

// Ocultar el asistente
function hideAssistant() {
  const assistantModal = document.getElementById('assistant-modal');
  
  if (assistantModal) {
    assistantModal.classList.remove('active');
    assistantShown = false;
  }
}

// Alternar el asistente
function toggleAssistant() {
  if (assistantShown) {
    hideAssistant();
  } else {
    showAssistant();
  }
}

// Animación del robot
function animateRobot() {
  const robotHead = document.querySelector('.assistant-avatar .robot-head');
  const robotEyes = document.querySelectorAll('.assistant-avatar .robot-eye');
  const robotMouth = document.querySelector('.assistant-avatar .robot-mouth');
  
  if (robotHead && robotEyes.length === 2 && robotMouth) {
    // Animación de los ojos
    setInterval(() => {
      // Parpadeo
      robotEyes.forEach(eye => {
        eye.style.height = '1px';
        setTimeout(() => {
          eye.style.height = '6px';
        }, 200);
      });
    }, 4000);
    
    // Animación de la boca
    let talking = false;
    setInterval(() => {
      if (assistantShown) {
        talking = !talking;
        if (talking) {
          robotMouth.style.width = '8px';
          robotMouth.style.height = '4px';
          robotMouth.style.borderRadius = '2px';
        } else {
          robotMouth.style.width = '12px';
          robotMouth.style.height = '3px';
          robotMouth.style.borderRadius = '2px';
        }
      } else {
        robotMouth.style.width = '12px';
        robotMouth.style.height = '3px';
      }
    }, 300);
  }
}

// Mostrar mensajes del asistente
function showAssistantMessage(message) {
  const assistantContent = document.querySelector('.assistant-content');
  
  if (assistantContent) {
    const messageElement = document.createElement('p');
    messageElement.textContent = message;
    messageElement.className = 'assistant-message';
    messageElement.style.opacity = '0';
    
    assistantContent.appendChild(messageElement);
    
    // Animar la aparición del mensaje
    setTimeout(() => {
      messageElement.style.transition = 'opacity 0.5s ease';
      messageElement.style.opacity = '1';
    }, 100);
    
    // Scroll al final del contenido
    assistantContent.scrollTop = assistantContent.scrollHeight;
  }
}

// Responder a interacciones del usuario
function respondToUserAction(action) {
  // Diferentes respuestas según la acción del usuario
  const responses = {
    'scroll': '¿Puedo ayudarte a encontrar algo específico?',
    'click_service': '¿Te gustaría más información sobre este servicio?',
    'form_focus': '¡Completa el formulario y nos pondremos en contacto contigo!',
    'video_play': '¡Excelente elección! Este video muestra cómo funciona nuestra solución.'
  };
  
  if (responses[action] && Math.random() > 0.7) { // 30% de probabilidad de mostrar un mensaje
    showAssistantMessage(responses[action]);
  }
}

// Exportar funciones para uso global
window.WAIAssistant = {
  show: showAssistant,
  hide: hideAssistant,
  toggle: toggleAssistant,
  respond: respondToUserAction
};
