// WAI Agents - Integración con Google Calendar
// Este archivo contiene la funcionalidad para integrar el calendario con Google Calendar API

// Configuración de la API de Google Calendar
const GOOGLE_API_KEY = 'YOUR_API_KEY'; // Reemplazar con tu API key real
const GOOGLE_CLIENT_ID = 'YOUR_CLIENT_ID'; // Reemplazar con tu Client ID real
const GOOGLE_CALENDAR_ID = 'primary'; // ID del calendario a utilizar

// Variables globales
let googleApiLoaded = false;
let googleApiInitialized = false;
let googleApiAuthorized = false;

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  // Cargar la API de Google
  loadGoogleApi();
  
  // Botón de autorización
  const authButton = document.getElementById('google-auth-button');
  if (authButton) {
    authButton.addEventListener('click', handleAuthClick);
  }
});

// Cargar la API de Google
function loadGoogleApi() {
  // Verificar si ya está cargada
  if (googleApiLoaded) return;
  
  // Cargar el script de la API
  const script = document.createElement('script');
  script.src = 'https://apis.google.com/js/api.js';
  script.onload = initGoogleApi;
  document.body.appendChild(script);
  
  googleApiLoaded = true;
  
  console.log('Google API script cargado');
}

// Inicializar la API de Google
function initGoogleApi() {
  // Cargar la biblioteca de cliente
  gapi.load('client:auth2', () => {
    // Inicializar la biblioteca de cliente
    gapi.client.init({
      apiKey: GOOGLE_API_KEY,
      clientId: GOOGLE_CLIENT_ID,
      discoveryDocs: ['https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest'],
      scope: 'https://www.googleapis.com/auth/calendar'
    }).then(() => {
      // API inicializada
      googleApiInitialized = true;
      
      // Verificar si el usuario ya está autenticado
      if (gapi.auth2.getAuthInstance().isSignedIn.get()) {
        googleApiAuthorized = true;
        updateAuthStatus(true);
        loadCalendarData();
      } else {
        updateAuthStatus(false);
      }
      
      // Escuchar cambios en el estado de autenticación
      gapi.auth2.getAuthInstance().isSignedIn.listen(updateAuthStatus);
      
      console.log('Google API inicializada');
    }).catch(error => {
      console.error('Error al inicializar Google API:', error);
    });
  });
}

// Actualizar el estado de autenticación
function updateAuthStatus(isSignedIn) {
  const authButton = document.getElementById('google-auth-button');
  const authStatus = document.getElementById('google-auth-status');
  
  if (isSignedIn) {
    // Usuario autenticado
    googleApiAuthorized = true;
    
    if (authButton) {
      authButton.textContent = 'Cerrar sesión';
    }
    
    if (authStatus) {
      authStatus.textContent = 'Conectado a Google Calendar';
      authStatus.className = 'auth-status connected';
    }
    
    // Cargar datos del calendario
    loadCalendarData();
  } else {
    // Usuario no autenticado
    googleApiAuthorized = false;
    
    if (authButton) {
      authButton.textContent = 'Conectar con Google Calendar';
    }
    
    if (authStatus) {
      authStatus.textContent = 'No conectado a Google Calendar';
      authStatus.className = 'auth-status disconnected';
    }
  }
}

// Manejar clic en el botón de autenticación
function handleAuthClick() {
  if (!googleApiInitialized) {
    console.error('Google API no inicializada');
    return;
  }
  
  if (googleApiAuthorized) {
    // Cerrar sesión
    gapi.auth2.getAuthInstance().signOut();
  } else {
    // Iniciar sesión
    gapi.auth2.getAuthInstance().signIn();
  }
}

// Cargar datos del calendario
function loadCalendarData() {
  if (!googleApiInitialized || !googleApiAuthorized) {
    console.error('Google API no inicializada o no autorizada');
    return;
  }
  
  // Obtener el mes actual
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();
  
  // Fechas de inicio y fin del mes
  const timeMin = new Date(currentYear, currentMonth, 1).toISOString();
  const timeMax = new Date(currentYear, currentMonth + 1, 0).toISOString();
  
  // Obtener eventos del calendario
  gapi.client.calendar.events.list({
    'calendarId': GOOGLE_CALENDAR_ID,
    'timeMin': timeMin,
    'timeMax': timeMax,
    'showDeleted': false,
    'singleEvents': true,
    'orderBy': 'startTime'
  }).then(response => {
    const events = response.result.items;
    
    // Procesar los eventos
    processCalendarEvents(events);
    
    console.log('Eventos cargados:', events.length);
  }).catch(error => {
    console.error('Error al cargar eventos:', error);
  });
}

// Procesar eventos del calendario
function processCalendarEvents(events) {
  // Inicializar disponibilidad con 15 cupos por día
  const availabilityData = {};
  
  // Obtener el mes actual
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();
  
  // Obtener el número de días en el mes
  const totalDays = new Date(currentYear, currentMonth + 1, 0).getDate();
  
  // Inicializar disponibilidad
  for (let day = 1; day <= totalDays; day++) {
    // Verificar si el día es anterior a la fecha actual
    const dayDate = new Date(currentYear, currentMonth, day);
    
    if (dayDate < new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate())) {
      // Día pasado, no disponible
      availabilityData[day] = {
        available: false,
        slots: 0
      };
    } else {
      // Día futuro, 15 cupos disponibles
      availabilityData[day] = {
        available: true,
        slots: 15
      };
    }
  }
  
  // Reducir slots según eventos existentes
  events.forEach(event => {
    // Obtener la fecha del evento
    const eventDate = new Date(event.start.dateTime || event.start.date);
    const day = eventDate.getDate();
    
    // Verificar si el día está en el mes actual
    if (eventDate.getMonth() === currentMonth && eventDate.getFullYear() === currentYear) {
      // Reducir un cupo
      if (availabilityData[day]) {
        availabilityData[day].slots--;
        
        // Si no hay más cupos, marcar como no disponible
        if (availabilityData[day].slots <= 0) {
          availabilityData[day].available = false;
          availabilityData[day].slots = 0;
        }
      }
    }
  });
  
  // Actualizar la visualización del calendario
  updateCalendarDisplay(availabilityData);
}

// Actualizar la visualización del calendario
function updateCalendarDisplay(availabilityData) {
  // Actualizar cada día en el calendario
  for (let day = 1; day <= Object.keys(availabilityData).length; day++) {
    const availabilityElement = document.getElementById(`availability-${day}`);
    if (!availabilityElement) continue;
    
    const dayData = availabilityData[day];
    
    if (!dayData.available) {
      availabilityElement.textContent = 'No disponible';
      availabilityElement.className = 'day-availability unavailable';
    } else if (dayData.slots <= 4) {
      availabilityElement.textContent = `${dayData.slots} cupos`;
      availabilityElement.className = 'day-availability limited';
    } else {
      availabilityElement.textContent = `${dayData.slots} cupos`;
      availabilityElement.className = 'day-availability available';
    }
  }
}

// Crear un evento en Google Calendar
function createCalendarEvent(eventData) {
  if (!googleApiInitialized || !googleApiAuthorized) {
    console.error('Google API no inicializada o no autorizada');
    return Promise.reject('No autorizado');
  }
  
  return gapi.client.calendar.events.insert({
    'calendarId': GOOGLE_CALENDAR_ID,
    'resource': eventData
  }).then(response => {
    console.log('Evento creado:', response.result);
    return response.result;
  }).catch(error => {
    console.error('Error al crear evento:', error);
    return Promise.reject(error);
  });
}

// Función para reservar una demostración
function bookDemonstration(name, email, phone, company, message, date, time, country) {
  // Crear datos del evento
  const eventData = {
    summary: `Demostración WAI Agents - ${name}`,
    description: `
      Nombre: ${name}
      Email: ${email}
      Teléfono: ${phone}
      Empresa: ${company}
      Mensaje: ${message}
      País: ${country}
    `,
    start: {
      dateTime: date.toISOString(),
      timeZone: getCountryTimezone(country)
    },
    end: {
      dateTime: new Date(date.getTime() + 30 * 60000).toISOString(),
      timeZone: getCountryTimezone(country)
    }
  };
  
  // Crear el evento en Google Calendar
  return createCalendarEvent(eventData);
}

// Obtener la zona horaria de un país
function getCountryTimezone(countryCode) {
  const timezones = {
    'CO': 'America/Bogota',
    'PE': 'America/Lima',
    'DO': 'America/Santo_Domingo',
    'CL': 'America/Santiago',
    'AR': 'America/Argentina/Buenos_Aires',
    'ES': 'Europe/Madrid',
    'EC': 'America/Guayaquil',
    'US': 'America/New_York',
    'SV': 'America/El_Salvador'
  };
  
  return timezones[countryCode] || 'UTC';
}

// Exportar funciones para uso global
window.GoogleCalendar = {
  init: loadGoogleApi,
  authorize: handleAuthClick,
  loadEvents: loadCalendarData,
  createEvent: createCalendarEvent,
  bookDemo: bookDemonstration
};
