// WAI Agents - Funcionalidad principal
// Archivo principal de JavaScript para el sitio web

// Variables globales
let isMenuOpen = false;
let isAssistantOpen = false;

// Elementos del DOM
const header = document.getElementById('header');
const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
const assistantButton = document.getElementById('assistant-button');
const assistantModal = document.getElementById('assistant-modal');
const assistantClose = document.getElementById('assistant-close');
const backToTop = document.getElementById('back-to-top');
const notificationBadge = document.getElementById('notification-badge');

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  // Inicializar el preloader
  initPreloader();
  
  // Inicializar partículas
  initParticles();
  
  // Inicializar el menú móvil
  initMobileMenu();
  
  // Inicializar el asistente virtual
  initVirtualAssistant();
  
  // Inicializar el botón de volver arriba
  initBackToTop();
  
  // Inicializar animaciones de scroll
  initScrollAnimations();
  
  // Inicializar el efecto de escritura en el título
  initTypingEffect();
  
  // Inicializar el formulario de contacto
  initContactForm();
  
  // Inicializar el slider de testimonios
  initTestimonialsSlider();
  
  // Inicializar la visualización del proceso
  initProcessVisualization();
});

// Inicializar el preloader
function initPreloader() {
  const preloader = document.querySelector('.preloader');
  const loadingProgress = document.querySelector('.loading-progress');
  
  // Simular progreso de carga
  let progress = 0;
  const interval = setInterval(() => {
    progress += 5;
    loadingProgress.style.width = `${progress}%`;
    
    if (progress >= 100) {
      clearInterval(interval);
      
      // Ocultar el preloader
      setTimeout(() => {
        preloader.style.opacity = '0';
        setTimeout(() => {
          preloader.style.display = 'none';
        }, 500);
      }, 500);
    }
  }, 100);
}

// Inicializar partículas
function initParticles() {
  if (typeof particlesJS !== 'undefined') {
    particlesJS('particles-js', {
      particles: {
        number: {
          value: 80,
          density: {
            enable: true,
            value_area: 800
          }
        },
        color: {
          value: '#48C2F0'
        },
        shape: {
          type: 'circle',
          stroke: {
            width: 0,
            color: '#000000'
          },
          polygon: {
            nb_sides: 5
          }
        },
        opacity: {
          value: 0.5,
          random: false,
          anim: {
            enable: false,
            speed: 1,
            opacity_min: 0.1,
            sync: false
          }
        },
        size: {
          value: 3,
          random: true,
          anim: {
            enable: false,
            speed: 40,
            size_min: 0.1,
            sync: false
          }
        },
        line_linked: {
          enable: true,
          distance: 150,
          color: '#7C52ED',
          opacity: 0.4,
          width: 1
        },
        move: {
          enable: true,
          speed: 2,
          direction: 'none',
          random: false,
          straight: false,
          out_mode: 'out',
          bounce: false,
          attract: {
            enable: false,
            rotateX: 600,
            rotateY: 1200
          }
        }
      },
      interactivity: {
        detect_on: 'canvas',
        events: {
          onhover: {
            enable: true,
            mode: 'grab'
          },
          onclick: {
            enable: true,
            mode: 'push'
          },
          resize: true
        },
        modes: {
          grab: {
            distance: 140,
            line_linked: {
              opacity: 1
            }
          },
          bubble: {
            distance: 400,
            size: 40,
            duration: 2,
            opacity: 8,
            speed: 3
          },
          repulse: {
            distance: 200,
            duration: 0.4
          },
          push: {
            particles_nb: 4
          },
          remove: {
            particles_nb: 2
          }
        }
      },
      retina_detect: true
    });
  }
}

// Inicializar el menú móvil
function initMobileMenu() {
  // Crear el menú móvil si no existe
  if (!document.querySelector('.mobile-menu')) {
    const mobileMenu = document.createElement('div');
    mobileMenu.className = 'mobile-menu';
    
    const closeMenu = document.createElement('div');
    closeMenu.className = 'close-menu';
    closeMenu.innerHTML = '<i class="fas fa-times"></i>';
    
    const mobileNavList = document.createElement('ul');
    mobileNavList.className = 'mobile-nav-list';
    
    // Clonar los elementos del menú principal
    const navItems = document.querySelectorAll('.nav-list a');
    navItems.forEach(item => {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = item.href;
      a.textContent = item.textContent;
      li.appendChild(a);
      mobileNavList.appendChild(li);
    });
    
    mobileMenu.appendChild(closeMenu);
    mobileMenu.appendChild(mobileNavList);
    document.body.appendChild(mobileMenu);
    
    // Event listeners para el menú móvil
    closeMenu.addEventListener('click', toggleMobileMenu);
    
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-list a');
    mobileNavLinks.forEach(link => {
      link.addEventListener('click', toggleMobileMenu);
    });
  }
  
  // Event listener para el botón de menú
  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener('click', toggleMobileMenu);
  }
  
  // Event listener para el scroll
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
}

// Alternar el menú móvil
function toggleMobileMenu() {
  const mobileMenu = document.querySelector('.mobile-menu');
  
  if (isMenuOpen) {
    mobileMenu.classList.remove('active');
  } else {
    mobileMenu.classList.add('active');
  }
  
  isMenuOpen = !isMenuOpen;
}

// Inicializar el asistente virtual
function initVirtualAssistant() {
  if (assistantButton && assistantModal && assistantClose) {
    // Mostrar el asistente automáticamente después de 5 segundos
    setTimeout(() => {
      if (!isAssistantOpen) {
        toggleAssistant();
      }
    }, 5000);
    
    // Event listeners para el asistente
    assistantButton.addEventListener('click', toggleAssistant);
    assistantClose.addEventListener('click', toggleAssistant);
  }
}

// Alternar el asistente virtual
function toggleAssistant() {
  if (isAssistantOpen) {
    assistantModal.classList.remove('active');
  } else {
    assistantModal.classList.add('active');
    
    // Ocultar la notificación
    if (notificationBadge) {
      notificationBadge.style.display = 'none';
    }
  }
  
  isAssistantOpen = !isAssistantOpen;
}

// Inicializar el botón de volver arriba
function initBackToTop() {
  if (backToTop) {
    // Mostrar/ocultar el botón según el scroll
    window.addEventListener('scroll', () => {
      if (window.scrollY > 500) {
        backToTop.classList.add('active');
      } else {
        backToTop.classList.remove('active');
      }
    });
    
    // Event listener para el botón
    backToTop.addEventListener('click', () => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }
}

// Inicializar animaciones de scroll
function initScrollAnimations() {
  // Elementos con animaciones
  const animatedElements = document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right, .scale-in');
  
  // Añadir clases de animación a elementos
  const sections = document.querySelectorAll('section');
  sections.forEach(section => {
    const sectionHeader = section.querySelector('.section-header');
    if (sectionHeader) {
      sectionHeader.classList.add('fade-in');
    }
    
    const contentElements = section.querySelectorAll('.about-image, .about-text, .service-card, .video-item, .timeline-step, .testimonial-item, .blog-card, .contact-info, .contact-form');
    contentElements.forEach((element, index) => {
      if (index % 2 === 0) {
        element.classList.add('slide-in-left');
      } else {
        element.classList.add('slide-in-right');
      }
    });
  });
  
  // Función para verificar si un elemento está en el viewport
  function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
      rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8
    );
  }
  
  // Función para mostrar elementos cuando están en el viewport
  function handleScroll() {
    animatedElements.forEach(element => {
      if (isElementInViewport(element)) {
        element.classList.add('visible');
      }
    });
  }
  
  // Event listener para el scroll
  window.addEventListener('scroll', handleScroll);
  
  // Verificar elementos visibles al cargar la página
  handleScroll();
}

// Inicializar el efecto de escritura en el título
function initTypingEffect() {
  const heroTitle = document.getElementById('hero-title');
  
  if (heroTitle) {
    const text = heroTitle.textContent;
    heroTitle.textContent = '';
    heroTitle.classList.add('typing-animation');
    
    let i = 0;
    const typeWriter = () => {
      if (i < text.length) {
        heroTitle.textContent += text.charAt(i);
        i++;
        setTimeout(typeWriter, 100);
      } else {
        // Quitar la animación después de completar
        setTimeout(() => {
          heroTitle.classList.remove('typing-animation');
        }, 1000);
      }
    };
    
    setTimeout(typeWriter, 1000);
  }
}

// Inicializar el formulario de contacto
function initContactForm() {
  const contactForm = document.getElementById('contact-form');
  
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      // Aquí se implementaría la lógica para enviar el formulario
      // Por ahora, solo mostramos una alerta
      alert('¡Gracias por contactarnos! Te responderemos a la brevedad.');
      contactForm.reset();
    });
  }
}

// Inicializar el slider de testimonios
function initTestimonialsSlider() {
  const testimonialItems = document.querySelectorAll('.testimonial-item');
  const dots = document.querySelectorAll('.testimonial-dots .dot');
  const prevButton = document.getElementById('testimonial-prev');
  const nextButton = document.getElementById('testimonial-next');
  
  if (testimonialItems.length > 0) {
    let currentSlide = 0;
    
    // Mostrar el primer testimonio
    testimonialItems[0].classList.add('active');
    
    // Función para cambiar de testimonio
    function showSlide(index) {
      // Ocultar todos los testimonios
      testimonialItems.forEach(item => {
        item.classList.remove('active');
      });
      
      // Desactivar todos los dots
      dots.forEach(dot => {
        dot.classList.remove('active');
      });
      
      // Mostrar el testimonio seleccionado
      testimonialItems[index].classList.add('active');
      dots[index].classList.add('active');
      
      currentSlide = index;
    }
    
    // Event listeners para los botones
    if (prevButton) {
      prevButton.addEventListener('click', () => {
        let index = currentSlide - 1;
        if (index < 0) {
          index = testimonialItems.length - 1;
        }
        showSlide(index);
      });
    }
    
    if (nextButton) {
      nextButton.addEventListener('click', () => {
        let index = currentSlide + 1;
        if (index >= testimonialItems.length) {
          index = 0;
        }
        showSlide(index);
      });
    }
    
    // Event listeners para los dots
    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        showSlide(index);
      });
    });
    
    // Cambiar automáticamente cada 5 segundos
    setInterval(() => {
      let index = currentSlide + 1;
      if (index >= testimonialItems.length) {
        index = 0;
      }
      showSlide(index);
    }, 5000);
  }
}

// Inicializar la visualización del proceso
function initProcessVisualization() {
  const processSteps = document.querySelectorAll('.process-step');
  const progressIndicator = document.querySelector('.process-progress');
  
  if (processSteps.length > 0 && progressIndicator) {
    let currentStep = 0;
    
    // Activar el primer paso
    processSteps[0].classList.add('active');
    
    // Función para avanzar al siguiente paso
    function nextStep() {
      // Desactivar el paso actual
      processSteps[currentStep].classList.remove('active');
      
      // Avanzar al siguiente paso
      currentStep = (currentStep + 1) % processSteps.length;
      
      // Activar el nuevo paso
      processSteps[currentStep].classList.add('active');
      
      // Actualizar la barra de progreso
      progressIndicator.style.width = `${(currentStep / (processSteps.length - 1)) * 100}%`;
    }
    
    // Cambiar automáticamente cada 3 segundos
    setInterval(nextStep, 3000);
  }
  
  // Animación de la línea de tiempo
  const timelineSteps = document.querySelectorAll('.timeline-step');
  const progressIndicatorTimeline = document.querySelector('.progress-indicator');
  
  if (timelineSteps.length > 0 && progressIndicatorTimeline) {
    // Función para verificar si un elemento está en el viewport
    function isElementInViewport(el) {
      const rect = el.getBoundingClientRect();
      return (
        rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8
      );
    }
    
    // Función para actualizar la línea de tiempo
    function updateTimeline() {
      let activeSteps = 0;
      
      timelineSteps.forEach((step, index) => {
        if (isElementInViewport(step)) {
          step.classList.add('active');
          activeSteps = index + 1;
        }
      });
      
      // Actualizar la barra de progreso
      const progress = (activeSteps / timelineSteps.length) * 100;
      progressIndicatorTimeline.style.height = `${progress}%`;
    }
    
    // Event listener para el scroll
    window.addEventListener('scroll', updateTimeline);
    
    // Verificar al cargar la página
    updateTimeline();
  }
}
