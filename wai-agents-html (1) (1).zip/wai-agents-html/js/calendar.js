// Calendario de Disponibilidad con integración a Google Calendar
// WAI Agents - Funcionalidad del calendario

// Configuración de países y zonas horarias
const countries = {
  CO: {
    name: "Colombia",
    timezone: "America/Bogota",
    flag: "🇨🇴"
  },
  PE: {
    name: "Perú",
    timezone: "America/Lima",
    flag: "🇵🇪"
  },
  DO: {
    name: "República Dominicana",
    timezone: "America/Santo_Domingo",
    flag: "🇩🇴"
  },
  CL: {
    name: "Chile",
    timezone: "America/Santiago",
    flag: "🇨🇱"
  },
  AR: {
    name: "Argentina",
    timezone: "America/Argentina/Buenos_Aires",
    flag: "🇦🇷"
  },
  ES: {
    name: "España",
    timezone: "Europe/Madrid",
    flag: "🇪🇸"
  },
  EC: {
    name: "Ecuador",
    timezone: "America/Guayaquil",
    flag: "🇪🇨"
  },
  US: {
    name: "Estados Unidos",
    timezone: "America/New_York",
    flag: "🇺🇸"
  },
  SV: {
    name: "El Salvador",
    timezone: "America/El_Salvador",
    flag: "🇸🇻"
  }
};

// Variables globales
let currentDate = new Date();
let currentMonth = currentDate.getMonth();
let currentYear = currentDate.getFullYear();
let selectedDate = null;
let selectedTime = null;
let selectedCountry = "DO"; // País por defecto: República Dominicana
let availabilityData = {}; // Datos de disponibilidad

// Elementos del DOM
const countrySelect = document.getElementById('country-select');
const countryFlag = document.getElementById('country-flag');
const countryName = document.getElementById('country-name');
const countryTimezone = document.getElementById('country-timezone');
const currentMonthElement = document.getElementById('current-month');
const calendarDays = document.getElementById('calendar-days');
const prevMonthBtn = document.getElementById('prev-month');
const nextMonthBtn = document.getElementById('next-month');
const timeSlots = document.getElementById('time-slots');
const slotsContainer = document.getElementById('slots-container');
const selectedDateDisplay = document.getElementById('selected-date-display');
const bookingForm = document.getElementById('booking-form-container');
const bookingDate = document.getElementById('booking-date');
const bookingTime = document.getElementById('booking-time');
const bookingCountry = document.getElementById('booking-country');
const demoBookingForm = document.getElementById('demo-booking-form');
const closeBookingForm = document.getElementById('close-booking-form');
const bookingConfirmation = document.getElementById('booking-confirmation');
const closeConfirmation = document.getElementById('close-confirmation');

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  // Inicializar el selector de países
  initCountrySelector();
  
  // Inicializar el calendario
  updateCalendar();
  
  // Cargar datos de disponibilidad desde Google Calendar
  loadAvailabilityData();
  
  // Event listeners
  prevMonthBtn.addEventListener('click', () => {
    navigateMonth(-1);
  });
  
  nextMonthBtn.addEventListener('click', () => {
    navigateMonth(1);
  });
  
  countrySelect.addEventListener('change', () => {
    selectedCountry = countrySelect.value;
    updateCountryInfo();
    loadAvailabilityData();
  });
  
  demoBookingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    submitBooking();
  });
  
  closeBookingForm.addEventListener('click', () => {
    bookingForm.classList.remove('active');
  });
  
  closeConfirmation.addEventListener('click', () => {
    bookingConfirmation.classList.remove('active');
  });
  
  // Botón para agendar demostración desde el asistente virtual
  const scheduleDemoBtn = document.getElementById('schedule-demo-btn');
  if (scheduleDemoBtn) {
    scheduleDemoBtn.addEventListener('click', () => {
      document.querySelector('.assistant-modal').classList.remove('active');
      document.getElementById('availability').scrollIntoView({ behavior: 'smooth' });
    });
  }
});

// Inicializar el selector de países
function initCountrySelector() {
  // Llenar el selector de países
  countrySelect.innerHTML = '';
  
  Object.keys(countries).forEach(countryCode => {
    const country = countries[countryCode];
    const option = document.createElement('option');
    option.value = countryCode;
    option.textContent = `${country.flag} ${country.name}`;
    countrySelect.appendChild(option);
  });
  
  // Establecer el país por defecto
  countrySelect.value = selectedCountry;
  
  // Actualizar la información del país
  updateCountryInfo();
}

// Actualizar la información del país seleccionado
function updateCountryInfo() {
  const country = countries[selectedCountry];
  countryFlag.textContent = country.flag;
  countryName.textContent = country.name;
  countryTimezone.textContent = country.timezone;
}

// Navegar entre meses
function navigateMonth(direction) {
  currentMonth += direction;
  
  if (currentMonth < 0) {
    currentMonth = 11;
    currentYear--;
  } else if (currentMonth > 11) {
    currentMonth = 0;
    currentYear++;
  }
  
  updateCalendar();
  loadAvailabilityData();
}

// Actualizar el calendario
function updateCalendar() {
  // Actualizar el título del mes
  const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  currentMonthElement.textContent = `${monthNames[currentMonth]} ${currentYear}`;
  
  // Limpiar el calendario
  calendarDays.innerHTML = '';
  
  // Obtener el primer día del mes
  const firstDay = new Date(currentYear, currentMonth, 1);
  const startingDay = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1; // Ajustar para que la semana comience el lunes
  
  // Obtener el número de días en el mes
  const lastDay = new Date(currentYear, currentMonth + 1, 0);
  const totalDays = lastDay.getDate();
  
  // Crear celdas vacías para los días anteriores al primer día del mes
  for (let i = 0; i < startingDay; i++) {
    const emptyDay = document.createElement('div');
    emptyDay.className = 'day empty';
    calendarDays.appendChild(emptyDay);
  }
  
  // Crear celdas para cada día del mes
  for (let day = 1; day <= totalDays; day++) {
    const dayElement = document.createElement('div');
    dayElement.className = 'day';
    
    // Verificar si el día es anterior a la fecha actual
    const currentDateObj = new Date();
    const dayDate = new Date(currentYear, currentMonth, day);
    
    if (dayDate < new Date(currentDateObj.getFullYear(), currentDateObj.getMonth(), currentDateObj.getDate())) {
      dayElement.classList.add('unavailable');
    } else {
      dayElement.addEventListener('click', () => selectDate(day));
    }
    
    const dayNumber = document.createElement('div');
    dayNumber.className = 'day-number';
    dayNumber.textContent = day;
    
    const dayAvailability = document.createElement('div');
    dayAvailability.className = 'day-availability';
    dayAvailability.id = `availability-${day}`;
    dayAvailability.textContent = '...';
    
    dayElement.appendChild(dayNumber);
    dayElement.appendChild(dayAvailability);
    calendarDays.appendChild(dayElement);
  }
}

// Cargar datos de disponibilidad desde Google Calendar
function loadAvailabilityData() {
  // Simulamos la carga de datos mientras se implementa la integración real con Google Calendar
  showLoadingState();
  
  // En una implementación real, aquí se haría una llamada a la API de Google Calendar
  setTimeout(() => {
    // Generar datos de disponibilidad simulados
    generateMockAvailabilityData();
    
    // Actualizar la visualización de disponibilidad
    updateAvailabilityDisplay();
  }, 1000);
}

// Mostrar estado de carga
function showLoadingState() {
  const availabilityElements = document.querySelectorAll('.day-availability');
  availabilityElements.forEach(element => {
    element.textContent = '...';
    element.className = 'day-availability';
  });
}

// Generar datos de disponibilidad simulados
function generateMockAvailabilityData() {
  availabilityData = {};
  
  // Obtener el número de días en el mes
  const totalDays = new Date(currentYear, currentMonth + 1, 0).getDate();
  
  // Generar disponibilidad para cada día
  for (let day = 1; day <= totalDays; day++) {
    // Verificar si el día es anterior a la fecha actual
    const currentDateObj = new Date();
    const dayDate = new Date(currentYear, currentMonth, day);
    
    if (dayDate < new Date(currentDateObj.getFullYear(), currentDateObj.getMonth(), currentDateObj.getDate())) {
      // Día pasado, no disponible
      availabilityData[day] = {
        available: false,
        slots: 0
      };
    } else {
      // Día futuro, generar disponibilidad aleatoria
      // Para fines de demostración, hacemos que los fines de semana tengan menos disponibilidad
      const dayOfWeek = dayDate.getDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      
      let slots;
      if (isWeekend) {
        // Fines de semana: 0-5 slots disponibles
        slots = Math.floor(Math.random() * 6);
      } else {
        // Días de semana: 5-15 slots disponibles
        slots = Math.floor(Math.random() * 11) + 5;
      }
      
      availabilityData[day] = {
        available: slots > 0,
        slots: slots
      };
    }
  }
}

// Actualizar la visualización de disponibilidad
function updateAvailabilityDisplay() {
  for (let day = 1; day <= Object.keys(availabilityData).length; day++) {
    const availabilityElement = document.getElementById(`availability-${day}`);
    if (!availabilityElement) continue;
    
    const dayData = availabilityData[day];
    
    if (!dayData.available) {
      availabilityElement.textContent = 'No disponible';
      availabilityElement.className = 'day-availability unavailable';
    } else if (dayData.slots <= 4) {
      availabilityElement.textContent = `${dayData.slots} cupos`;
      availabilityElement.className = 'day-availability limited';
    } else {
      availabilityElement.textContent = `${dayData.slots} cupos`;
      availabilityElement.className = 'day-availability available';
    }
  }
}

// Seleccionar una fecha
function selectDate(day) {
  // Verificar si el día está disponible
  if (!availabilityData[day] || !availabilityData[day].available) {
    return;
  }
  
  // Actualizar la fecha seleccionada
  selectedDate = new Date(currentYear, currentMonth, day);
  
  // Actualizar la visualización de la fecha seleccionada
  const dayElements = document.querySelectorAll('.day');
  dayElements.forEach(element => {
    element.classList.remove('selected');
  });
  
  const selectedDayElement = document.querySelector(`.day:nth-child(${day + document.querySelectorAll('.day.empty').length})`);
  if (selectedDayElement) {
    selectedDayElement.classList.add('selected');
  }
  
  // Mostrar las horas disponibles
  showTimeSlots(day);
}

// Mostrar las horas disponibles
function showTimeSlots(day) {
  // Verificar si hay slots disponibles
  if (!availabilityData[day] || availabilityData[day].slots === 0) {
    return;
  }
  
  // Formatear la fecha seleccionada
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const formattedDate = selectedDate.toLocaleDateString('es-ES', options);
  selectedDateDisplay.textContent = `Horarios disponibles para el ${formattedDate}`;
  
  // Mostrar la sección de horarios
  timeSlots.classList.add('active');
  
  // Limpiar los horarios anteriores
  slotsContainer.innerHTML = '';
  
  // Generar horarios disponibles
  // En una implementación real, estos vendrían de Google Calendar
  const startHour = 9; // 9 AM
  const endHour = 18; // 6 PM
  const slotDuration = 30; // 30 minutos
  const slotsPerHour = 60 / slotDuration;
  
  // Ajustar zona horaria según el país seleccionado
  const countryTimezone = countries[selectedCountry].timezone;
  
  for (let hour = startHour; hour < endHour; hour++) {
    for (let slot = 0; slot < slotsPerHour; slot++) {
      const minutes = slot * slotDuration;
      const slotTime = new Date(selectedDate);
      slotTime.setHours(hour, minutes, 0, 0);
      
      // Formatear la hora según la zona horaria del país
      const timeString = slotTime.toLocaleTimeString('es-ES', { 
        hour: '2-digit', 
        minute: '2-digit', 
        timeZone: countryTimezone 
      });
      
      // Crear el elemento de horario
      const timeSlotElement = document.createElement('div');
      timeSlotElement.className = 'time-slot';
      timeSlotElement.textContent = timeString;
      
      // Evento para seleccionar el horario
      timeSlotElement.addEventListener('click', () => {
        selectTimeSlot(timeSlotElement, slotTime, timeString);
      });
      
      slotsContainer.appendChild(timeSlotElement);
    }
  }
  
  // Desplazarse hasta la sección de horarios
  timeSlots.scrollIntoView({ behavior: 'smooth' });
}

// Seleccionar un horario
function selectTimeSlot(element, time, timeString) {
  // Actualizar el horario seleccionado
  selectedTime = time;
  
  // Actualizar la visualización del horario seleccionado
  const timeSlotElements = document.querySelectorAll('.time-slot');
  timeSlotElements.forEach(el => {
    el.classList.remove('selected');
  });
  
  element.classList.add('selected');
  
  // Mostrar el formulario de reserva
  showBookingForm(timeString);
}

// Mostrar el formulario de reserva
function showBookingForm(timeString) {
  // Formatear la fecha seleccionada
  const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const formattedDate = selectedDate.toLocaleDateString('es-ES', dateOptions);
  
  // Actualizar los detalles de la reserva
  bookingDate.textContent = formattedDate;
  bookingTime.textContent = timeString;
  bookingCountry.textContent = countries[selectedCountry].name;
  
  // Mostrar el formulario
  bookingForm.classList.add('active');
}

// Enviar la reserva
function submitBooking() {
  // En una implementación real, aquí se enviaría la reserva a Google Calendar
  
  // Obtener los datos del formulario
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  const company = document.getElementById('company').value;
  const message = document.getElementById('message').value;
  
  // Crear el evento en Google Calendar (simulado)
  const eventData = {
    summary: `Demostración WAI Agents - ${name}`,
    description: `
      Nombre: ${name}
      Email: ${email}
      Teléfono: ${phone}
      Empresa: ${company}
      Mensaje: ${message}
    `,
    start: {
      dateTime: selectedTime.toISOString(),
      timeZone: countries[selectedCountry].timezone
    },
    end: {
      dateTime: new Date(selectedTime.getTime() + 30 * 60000).toISOString(),
      timeZone: countries[selectedCountry].timezone
    }
  };
  
  console.log('Evento creado:', eventData);
  
  // Ocultar el formulario de reserva
  bookingForm.classList.remove('active');
  
  // Mostrar la confirmación
  bookingConfirmation.classList.add('active');
  
  // Actualizar la disponibilidad
  if (availabilityData[selectedDate.getDate()]) {
    availabilityData[selectedDate.getDate()].slots--;
    updateAvailabilityDisplay();
  }
  
  // Limpiar el formulario
  demoBookingForm.reset();
}

// Integración con Google Calendar API
function initGoogleCalendarAPI() {
  // Esta función se implementaría en producción para conectar con la API de Google Calendar
  // Requiere configuración de OAuth2 y credenciales de Google Cloud Platform
  
  // Ejemplo de código para inicializar la API de Google Calendar:
  /*
  gapi.load('client:auth2', () => {
    gapi.client.init({
      apiKey: 'TU_API_KEY',
      clientId: 'TU_CLIENT_ID',
      discoveryDocs: ['https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest'],
      scope: 'https://www.googleapis.com/auth/calendar'
    }).then(() => {
      // API inicializada
      loadRealAvailabilityData();
    });
  });
  */
}

// Cargar datos reales de disponibilidad desde Google Calendar
function loadRealAvailabilityData() {
  // Esta función se implementaría en producción para obtener datos reales de disponibilidad
  
  // Ejemplo de código para obtener eventos de Google Calendar:
  /*
  const calendarId = 'primary';
  const timeMin = new Date(currentYear, currentMonth, 1).toISOString();
  const timeMax = new Date(currentYear, currentMonth + 1, 0).toISOString();
  
  gapi.client.calendar.events.list({
    'calendarId': calendarId,
    'timeMin': timeMin,
    'timeMax': timeMax,
    'showDeleted': false,
    'singleEvents': true,
    'orderBy': 'startTime'
  }).then(response => {
    const events = response.result.items;
    
    // Procesar los eventos para determinar la disponibilidad
    processAvailabilityFromEvents(events);
  });
  */
}

// Procesar eventos para determinar disponibilidad
function processAvailabilityFromEvents(events) {
  // Esta función se implementaría en producción para procesar eventos reales
  
  // Ejemplo de código para procesar eventos:
  /*
  // Inicializar disponibilidad con 15 cupos por día
  const totalDays = new Date(currentYear, currentMonth + 1, 0).getDate();
  for (let day = 1; day <= totalDays; day++) {
    availabilityData[day] = {
      available: true,
      slots: 15
    };
  }
  
  // Reducir slots según eventos existentes
  events.forEach(event => {
    const eventDate = new Date(event.start.dateTime || event.start.date);
    const day = eventDate.getDate();
    
    if (availabilityData[day]) {
      availabilityData[day].slots--;
      
      if (availabilityData[day].slots <= 0) {
        availabilityData[day].available = false;
      }
    }
  });
  
  // Actualizar la visualización
  updateAvailabilityDisplay();
  */
}

// Crear un evento en Google Calendar
function createGoogleCalendarEvent(eventData) {
  // Esta función se implementaría en producción para crear eventos reales
  
  // Ejemplo de código para crear un evento:
  /*
  return gapi.client.calendar.events.insert({
    'calendarId': 'primary',
    'resource': eventData
  }).then(response => {
    console.log('Evento creado:', response.result);
    return response.result;
  });
  */
}
