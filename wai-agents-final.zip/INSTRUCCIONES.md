# Instrucciones de Implementación - WAI Agents en Framer

## Descripción General

Este documento contiene las instrucciones para implementar el sitio web de WAI Agents desarrollado en Framer. El sitio web incluye todas las secciones solicitadas, con especial énfasis en el calendario de disponibilidad, videos de YouTube y elementos interactivos.

## Estructura de Archivos

El proyecto está organizado de manera modular para facilitar su mantenimiento y actualización:

```
wai-agents-framer/
├── index.js                 # Archivo principal que integra todos los componentes
├── header.js                # Componente de navegación
├── hero.js                  # Sección principal (hero)
├── about-section.js         # Sección "Sobre Nosotros"
├── services-section.js      # Sección de Servicios con videos de YouTube
├── availability-calendar.js # Calendario de disponibilidad
├── testimonials-section.js  # Sección de Casos de Éxito/Testimonios
├── process-section.js       # Sección de Proceso de Trabajo
├── blog-section.js          # Sección de Blog/Recursos
├── contact-section.js       # Formulario de contacto con Formspree
├── footer.js                # Footer del sitio
├── animations.js            # Componentes de animaciones reutilizables
├── interactions.js          # Componentes interactivos (videos, botones, etc.)
├── optimizations.js         # Optimizaciones de rendimiento y SEO
├── service-worker.js        # Service Worker para soporte offline
└── icons/                   # Directorio para iconos SVG
```

## Requisitos Previos

Para implementar este sitio web en Framer, necesitarás:

1. Una cuenta en Framer (https://framer.com)
2. Conocimientos básicos de Framer y React
3. Las imágenes e iconos de tu marca (logo, favicon, etc.)
4. IDs de videos de YouTube para los reproductores
5. Una cuenta en Formspree para el formulario de contacto

## Pasos de Implementación

### 1. Configuración Inicial en Framer

1. Inicia sesión en tu cuenta de Framer
2. Crea un nuevo proyecto
3. Elimina los componentes predeterminados del proyecto

### 2. Importación de Archivos

1. Sube todos los archivos JS proporcionados a tu proyecto de Framer
2. Crea una carpeta "icons" y sube todos los iconos SVG necesarios
3. Sube tu logo en dos versiones: "logo.png" (versión normal) y "logo-white.png" (versión para fondos oscuros)

### 3. Configuración del Archivo Principal

1. Abre el archivo `index.js` en el editor de Framer
2. Asegúrate de que todas las importaciones de componentes estén correctamente configuradas
3. Verifica que el orden de los componentes sea el correcto para el flujo del sitio

### 4. Personalización del Calendario de Disponibilidad

El calendario de disponibilidad es un componente clave que muestra claramente los días, fechas y horarios disponibles:

1. Abre el archivo `availability-calendar.js`
2. Personaliza los horarios disponibles según tus necesidades
3. Ajusta los colores de disponibilidad si es necesario (verde: disponible, amarillo: limitado, rojo: no disponible)
4. Configura el número de cupos diarios (actualmente establecido en 15)

### 5. Configuración de Videos de YouTube

Para los videos demostrativos en la sección de Servicios:

1. Abre el archivo `services-section.js`
2. Localiza el array `demoVideos`
3. Reemplaza los IDs de placeholder con tus IDs reales de YouTube:
   ```javascript
   const demoVideos = [
     {
       id: "tu-id-de-youtube-1",
       title: "Automatización para Clínicas",
       description: "Gestión automatizada de citas, recordatorios y seguimiento de pacientes."
     },
     // ... otros videos
   ]
   ```

### 6. Configuración del Formulario de Contacto

El formulario de contacto utiliza Formspree para procesar los envíos:

1. Crea una cuenta en Formspree (https://formspree.io) si aún no tienes una
2. Crea un nuevo formulario en Formspree y obtén tu ID único
3. Abre el archivo `contact-section.js`
4. Reemplaza el placeholder de Formspree con tu ID real:
   ```javascript
   <form
     action="https://formspree.io/f/tu-id-de-formspree"
     method="POST"
     // ...
   >
   ```

### 7. Personalización de Contenido

Personaliza el contenido según tus necesidades:

1. Textos: Revisa y actualiza todos los textos en cada componente
2. Imágenes: Reemplaza las referencias a imágenes con tus propias imágenes
3. Colores: Los colores de marca están definidos en cada componente, puedes ajustarlos según tu paleta:
   ```javascript
   const colors = {
     background: "#F2F5F9",
     primaryButton: "#7C52ED",
     secondaryButton: "#48C2F0",
     primaryText: "#000000",
     secondaryText: "#1A6DB0",
     gradientStart: "#3D157E",
     gradientEnd: "#06185F"
   }
   ```

### 8. Optimización para SEO

Para mejorar el SEO de tu sitio:

1. Abre el archivo `optimizations.js`
2. Localiza el componente `SEOHead`
3. Personaliza los metadatos según tu sitio:
   ```javascript
   <SEOHead
     title="WAI Agents - Automatizamos TODO con Inteligencia Artificial"
     description="WAI Agents automatiza la atención al cliente y procesos empresariales con inteligencia artificial para 12 sectores diferentes."
     keywords="automatización, inteligencia artificial, atención al cliente, IA, agentes virtuales"
     ogImage="/og-image.jpg"
     ogUrl="https://tudominio.com"
     twitterCard="summary_large_image"
   />
   ```

### 9. Configuración del Service Worker

El Service Worker proporciona soporte offline y mejora el rendimiento:

1. Asegúrate de que el archivo `service-worker.js` esté en la raíz de tu proyecto
2. Verifica que la lista de archivos a cachear (`urlsToCache`) incluya todos tus recursos
3. Si añades nuevos recursos, actualiza esta lista

### 10. Publicación del Sitio

Para publicar tu sitio en Framer:

1. Haz clic en el botón "Publish" en la interfaz de Framer
2. Selecciona un dominio personalizado o usa el proporcionado por Framer
3. Configura las opciones de SEO y redes sociales
4. Publica tu sitio

## Integración con Herramientas de Análisis

Para integrar herramientas de análisis como Google Analytics:

1. Obtén tu ID de seguimiento de Google Analytics
2. Abre el archivo `index.js`
3. Añade el siguiente código antes del cierre del componente principal:
   ```javascript
   useEffect(() => {
     // Google Analytics
     const script = document.createElement('script');
     script.src = `https://www.googletagmanager.com/gtag/js?id=TU-ID-DE-ANALYTICS`;
     script.async = true;
     document.head.appendChild(script);
     
     window.dataLayer = window.dataLayer || [];
     function gtag(){dataLayer.push(arguments);}
     gtag('js', new Date());
     gtag('config', 'TU-ID-DE-ANALYTICS');
   }, []);
   ```

## Pruebas y Compatibilidad

Antes de lanzar el sitio, realiza las siguientes pruebas:

1. **Pruebas de Responsive**: Verifica que el sitio se vea bien en diferentes tamaños de pantalla
2. **Pruebas de Navegador**: Comprueba la compatibilidad con Chrome, Firefox, Safari y Edge
3. **Pruebas de Rendimiento**: Utiliza herramientas como Lighthouse para evaluar el rendimiento
4. **Pruebas de Formulario**: Verifica que el formulario de contacto funcione correctamente
5. **Pruebas de Calendario**: Asegúrate de que el calendario de disponibilidad muestre correctamente los horarios

## Mantenimiento y Actualizaciones

Para mantener y actualizar el sitio:

1. **Actualización de Contenido**: Modifica los archivos JS correspondientes a cada sección
2. **Nuevas Funcionalidades**: Añade nuevos componentes siguiendo la estructura modular existente
3. **Optimización Continua**: Monitorea el rendimiento y realiza ajustes según sea necesario

## Soporte Técnico

Si encuentras problemas durante la implementación, puedes:

1. Revisar la documentación oficial de Framer: https://www.framer.com/docs/
2. Consultar la documentación de React: https://reactjs.org/docs/
3. Contactar con el equipo de WAI Agents para soporte específico del proyecto

---

© 2025 WAI Agents - Todos los derechos reservados
