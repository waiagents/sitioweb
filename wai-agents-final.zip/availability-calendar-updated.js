// availability-calendar-updated.js - Componente de calendario de disponibilidad mejorado para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F",
  available: "#4CAF50",     // Verde para disponible
  limited: "#FFC107",       // Amarillo para limitado
  unavailable: "#F44336",   // Rojo para no disponible
  selectedDay: "#E3F2FD"    // Azul claro para día seleccionado
}

// Países soportados con sus zonas horarias
const supportedCountries = [
  { name: "Colombia", code: "CO", timezone: "America/Bogota", flag: "🇨🇴" },
  { name: "Perú", code: "PE", timezone: "America/Lima", flag: "🇵🇪" },
  { name: "República Dominicana", code: "DO", timezone: "America/Santo_Domingo", flag: "🇩🇴" },
  { name: "Chile", code: "CL", timezone: "America/Santiago", flag: "🇨🇱" },
  { name: "Argentina", code: "AR", timezone: "America/Argentina/Buenos_Aires", flag: "🇦🇷" },
  { name: "España", code: "ES", timezone: "Europe/Madrid", flag: "🇪🇸" },
  { name: "Ecuador", code: "EC", timezone: "America/Guayaquil", flag: "🇪🇨" },
  { name: "Estados Unidos", code: "US", timezone: "America/New_York", flag: "🇺🇸" },
  { name: "El Salvador", code: "SV", timezone: "America/El_Salvador", flag: "🇸🇻" }
];

// Componente principal del Calendario
export function AvailabilityCalendar() {
  // Estado para el mes actual
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  // Estado para el día seleccionado
  const [selectedDate, setSelectedDate] = useState(null);
  
  // Estado para la hora seleccionada
  const [selectedTime, setSelectedTime] = useState(null);
  
  // Estado para el país seleccionado
  const [selectedCountry, setSelectedCountry] = useState(supportedCountries[2]); // República Dominicana por defecto
  
  // Estado para mostrar el formulario de reserva
  const [showBookingForm, setShowBookingForm] = useState(false);
  
  // Estado para los datos del formulario
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    message: ""
  });
  
  // Estado para el paso actual del proceso de reserva
  const [bookingStep, setBookingStep] = useState(1);
  
  // Estado para la disponibilidad de cupos
  const [availability, setAvailability] = useState({});
  
  // Animaciones
  const controls = useAnimation();
  
  // Efecto para generar disponibilidad aleatoria para demostración
  useEffect(() => {
    generateAvailability();
  }, [currentMonth, selectedCountry]);
  
  // Función para generar disponibilidad aleatoria
  const generateAvailability = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    const newAvailability = {};
    
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      
      // No mostrar disponibilidad para días pasados
      if (date < new Date().setHours(0, 0, 0, 0)) {
        newAvailability[day] = {
          available: 0,
          total: 15
        };
        continue;
      }
      
      // No mostrar disponibilidad para fines de semana
      if (date.getDay() === 0 || date.getDay() === 6) {
        newAvailability[day] = {
          available: 0,
          total: 15
        };
        continue;
      }
      
      // Generar disponibilidad aleatoria para los demás días
      const available = Math.floor(Math.random() * 16); // 0-15 cupos disponibles
      newAvailability[day] = {
        available: available,
        total: 15
      };
    }
    
    setAvailability(newAvailability);
  };
  
  // Función para obtener los días del mes actual
  const getDaysInMonth = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    const days = [];
    
    // Obtener el día de la semana del primer día del mes (0 = Domingo, 1 = Lunes, etc.)
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    
    // Añadir días vacíos para alinear el calendario
    for (let i = 0; i < (firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1); i++) {
      days.push(null);
    }
    
    // Añadir los días del mes
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day);
    }
    
    return days;
  };
  
  // Función para obtener el nombre del mes
  const getMonthName = (date) => {
    const monthNames = [
      "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
      "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    ];
    
    return monthNames[date.getMonth()];
  };
  
  // Función para ir al mes anterior
  const goToPreviousMonth = () => {
    const newMonth = new Date(currentMonth);
    newMonth.setMonth(newMonth.getMonth() - 1);
    
    // No permitir navegar a meses pasados
    if (newMonth < new Date().setDate(1)) {
      return;
    }
    
    setCurrentMonth(newMonth);
    setSelectedDate(null);
    setSelectedTime(null);
  };
  
  // Función para ir al mes siguiente
  const goToNextMonth = () => {
    const newMonth = new Date(currentMonth);
    newMonth.setMonth(newMonth.getMonth() + 1);
    setCurrentMonth(newMonth);
    setSelectedDate(null);
    setSelectedTime(null);
  };
  
  // Función para seleccionar un día
  const selectDay = (day) => {
    if (!day) return;
    
    const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    
    // No permitir seleccionar días pasados
    if (date < new Date().setHours(0, 0, 0, 0)) {
      return;
    }
    
    // No permitir seleccionar días sin disponibilidad
    if (availability[day]?.available === 0) {
      return;
    }
    
    setSelectedDate(date);
    setSelectedTime(null);
    setBookingStep(1);
  };
  
  // Función para seleccionar una hora
  const selectTime = (time) => {
    setSelectedTime(time);
    setBookingStep(2);
  };
  
  // Función para obtener las horas disponibles
  const getAvailableHours = () => {
    if (!selectedDate) return [];
    
    // Horario de trabajo: 9 AM - 6 PM
    const workHours = [];
    
    // Ajustar horario según la zona horaria del país seleccionado
    const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const countryTimezone = selectedCountry.timezone;
    
    // Calcular diferencia horaria (simplificado para demostración)
    const now = new Date();
    const userOffset = new Date(now.toLocaleString('en-US', { timeZone: userTimezone })).getHours() - now.getUTCHours();
    const countryOffset = new Date(now.toLocaleString('en-US', { timeZone: countryTimezone })).getHours() - now.getUTCHours();
    const hourDifference = countryOffset - userOffset;
    
    for (let hour = 9; hour <= 18; hour++) {
      // Ajustar hora según diferencia horaria
      const adjustedHour = (hour + hourDifference + 24) % 24;
      
      // Formato de 12 horas
      const hour12 = adjustedHour % 12 === 0 ? 12 : adjustedHour % 12;
      const ampm = adjustedHour < 12 ? "AM" : "PM";
      const timeString = `${hour12}:00 ${ampm}`;
      
      // Generar disponibilidad aleatoria para cada hora
      const isAvailable = Math.random() > 0.3; // 70% de probabilidad de estar disponible
      
      if (isAvailable) {
        workHours.push({
          hour: adjustedHour,
          display: timeString,
          available: true
        });
      }
    }
    
    return workHours;
  };
  
  // Función para manejar cambios en el formulario
  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  // Función para enviar el formulario
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Aquí iría la lógica para enviar los datos a un servidor
    console.log("Formulario enviado:", {
      ...formData,
      date: selectedDate,
      time: selectedTime,
      country: selectedCountry.name
    });
    
    // Mostrar confirmación
    setBookingStep(3);
    
    // Resetear formulario después de 5 segundos
    setTimeout(() => {
      setSelectedDate(null);
      setSelectedTime(null);
      setFormData({
        name: "",
        email: "",
        phone: "",
        company: "",
        message: ""
      });
      setBookingStep(1);
      setShowBookingForm(false);
    }, 5000);
  };
  
  // Función para obtener el color de disponibilidad
  const getAvailabilityColor = (day) => {
    if (!day || !availability[day]) return "transparent";
    
    const { available, total } = availability[day];
    
    if (available === 0) return colors.unavailable;
    if (available < total / 3) return colors.limited;
    return colors.available;
  };
  
  // Función para obtener el texto de disponibilidad
  const getAvailabilityText = (day) => {
    if (!day || !availability[day]) return "";
    
    const { available, total } = availability[day];
    
    if (available === 0) return "No disponible";
    if (available < total / 3) return `${available} cupos`;
    return `${available} cupos`;
  };
  
  // Función para cambiar el país seleccionado
  const handleCountryChange = (e) => {
    const countryCode = e.target.value;
    const country = supportedCountries.find(c => c.code === countryCode);
    setSelectedCountry(country);
    setSelectedDate(null);
    setSelectedTime(null);
  };
  
  return (
    <Frame
      name="AvailabilityCalendar"
      background={colors.background}
      width="100%"
      height="auto"
      style={{
        padding: "60px 0",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        position: "relative"
      }}
      id="availability"
    >
      {/* Título de la sección */}
      <Frame
        name="CalendarTitle"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          textAlign: "center",
          marginBottom: "40px"
        }}
      >
        <Frame
          name="SectionTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "36px",
            fontWeight: 700,
            color: colors.primaryText,
            marginBottom: "15px",
            textAlign: "center"
          }}
        >
          Agenda una Demostración
        </Frame>
        
        <Frame
          name="SectionDescription"
          background="transparent"
          width="80%"
          height="auto"
          style={{
            fontSize: "18px",
            lineHeight: 1.6,
            color: colors.secondaryText,
            margin: "0 auto",
            textAlign: "center",
            maxWidth: "800px"
          }}
        >
          Selecciona tu país, fecha y hora preferida para agendar una demostración personalizada de nuestros servicios de automatización con IA.
        </Frame>
      </Frame>
      
      {/* Contenedor principal */}
      <Frame
        name="CalendarContainer"
        background="white"
        width="90%"
        height="auto"
        style={{
          maxWidth: "1200px",
          borderRadius: "20px",
          boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)",
          padding: "30px",
          display: "flex",
          flexDirection: "column",
          "@media (min-width: 768px)": {
            flexDirection: "row"
          }
        }}
      >
        {/* Selector de país */}
        <Frame
          name="CountrySelector"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            marginBottom: "20px",
            "@media (min-width: 768px)": {
              marginBottom: "0",
              marginRight: "20px",
              width: "30%"
            }
          }}
        >
          <Frame
            name="CountrySelectorTitle"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              fontWeight: 600,
              color: colors.primaryText,
              marginBottom: "15px"
            }}
          >
            Selecciona tu país
          </Frame>
          
          <Frame
            name="CountrySelectorContainer"
            background="transparent"
            width="100%"
            height="auto"
            style={{
              marginBottom: "30px"
            }}
          >
            <select
              style={{
                width: "100%",
                padding: "12px 15px",
                borderRadius: "10px",
                border: "1px solid #e0e0e0",
                fontSize: "16px",
                color: colors.primaryText,
                backgroundColor: "white",
                appearance: "none",
                backgroundImage: "url('data:image/svg+xml;utf8,<svg fill=\"black\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M7 10l5 5 5-5z\"/><path d=\"M0 0h24v24H0z\" fill=\"none\"/></svg>')",
                backgroundRepeat: "no-repeat",
                backgroundPosition: "right 10px center",
                cursor: "pointer"
              }}
              value={selectedCountry.code}
              onChange={handleCountryChange}
            >
              {supportedCountries.map(country => (
                <option key={country.code} value={country.code}>
                  {country.flag} {country.name}
                </option>
              ))}
            </select>
          </Frame>
          
          <Frame
            name="CountryInfo"
            background={`linear-gradient(135deg, ${colors.gradientStart}, ${colors.gradientEnd})`}
            width="100%"
            height="auto"
            style={{
              borderRadius: "15px",
              padding: "20px",
              color: "white",
              marginBottom: "20px"
            }}
          >
            <Frame
              name="CountryInfoTitle"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "18px",
                fontWeight: 600,
                marginBottom: "10px",
                display: "flex",
                alignItems: "center",
                gap: "10px"
              }}
            >
              <span style={{ fontSize: "24px" }}>{selectedCountry.flag}</span>
              {selectedCountry.name}
            </Frame>
            
            <Frame
              name="CountryInfoDetails"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "14px",
                lineHeight: 1.6,
                opacity: 0.9
              }}
            >
              <p>Zona horaria: {selectedCountry.timezone.replace("_", " ")}</p>
              <p>Horario de atención: 9:00 AM - 6:00 PM</p>
              <p>Cupos disponibles: 15 por día</p>
            </Frame>
          </Frame>
          
          <Frame
            name="AvailabilityLegend"
            background="transparent"
            width="100%"
            height="auto"
            style={{
              marginTop: "20px"
            }}
          >
            <Frame
              name="LegendTitle"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "16px",
                fontWeight: 600,
                color: colors.primaryText,
                marginBottom: "10px"
              }}
            >
              Disponibilidad
            </Frame>
            
            <Frame
              name="LegendItems"
              background="transparent"
              width="100%"
              height="auto"
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "10px"
              }}
            >
              <Frame
                name="LegendItem1"
                background="transparent"
                width="auto"
                height="auto"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px"
                }}
              >
                <Frame
                  name="ColorIndicator"
                  background={colors.available}
                  width={15}
                  height={15}
                  radius="50%"
                />
                <span style={{ fontSize: "14px", color: colors.secondaryText }}>Disponible (5-15 cupos)</span>
              </Frame>
              
              <Frame
                name="LegendItem2"
                background="transparent"
                width="auto"
                height="auto"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px"
                }}
              >
                <Frame
                  name="ColorIndicator"
                  background={colors.limited}
                  width={15}
                  height={15}
                  radius="50%"
                />
                <span style={{ fontSize: "14px", color: colors.secondaryText }}>Limitado (1-4 cupos)</span>
              </Frame>
              
              <Frame
                name="LegendItem3"
                background="transparent"
                width="auto"
                height="auto"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px"
                }}
              >
                <Frame
                  name="ColorIndicator"
                  background={colors.unavailable}
                  width={15}
                  height={15}
                  radius="50%"
                />
                <span style={{ fontSize: "14px", color: colors.secondaryText }}>No disponible</span>
              </Frame>
            </Frame>
          </Frame>
        </Frame>
        
        {/* Calendario */}
        <Frame
          name="Calendar"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            "@media (min-width: 768px)": {
              width: "70%"
            }
          }}
        >
          {/* Navegación del mes */}
          <Frame
            name="MonthNavigation"
            background="transparent"
            width="100%"
            height="auto"
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "20px"
            }}
          >
            <Frame
              name="PreviousMonth"
              background="transparent"
              width={40}
              height={40}
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                cursor: "pointer",
                borderRadius: "50%",
                border: "1px solid #e0e0e0"
              }}
              whileHover={{
                background: "#f5f5f5"
              }}
              onClick={goToPreviousMonth}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 18L9 12L15 6" stroke={colors.primaryText} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </Frame>
            
            <Frame
              name="CurrentMonthDisplay"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "20px",
                fontWeight: 600,
                color: colors.primaryText
              }}
            >
              {getMonthName(currentMonth)} {currentMonth.getFullYear()}
            </Frame>
            
            <Frame
              name="NextMonth"
              background="transparent"
              width={40}
              height={40}
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                cursor: "pointer",
                borderRadius: "50%",
                border: "1px solid #e0e0e0"
              }}
              whileHover={{
                background: "#f5f5f5"
              }}
              onClick={goToNextMonth}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 6L15 12L9 18" stroke={colors.primaryText} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </Frame>
          </Frame>
          
          {/* Días de la semana */}
          <Frame
            name="WeekDays"
            background="transparent"
            width="100%"
            height="auto"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7, 1fr)",
              gap: "5px",
              marginBottom: "10px"
            }}
          >
            {["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map((day, index) => (
              <Frame
                key={index}
                name={`WeekDay-${day}`}
                background="transparent"
                width="auto"
                height="auto"
                style={{
                  textAlign: "center",
                  padding: "10px 0",
                  fontSize: "14px",
                  fontWeight: 600,
                  color: index >= 5 ? "#bdbdbd" : colors.primaryText
                }}
              >
                {day}
              </Frame>
            ))}
          </Frame>
          
          {/* Días del mes */}
          <Frame
            name="MonthDays"
            background="transparent"
            width="100%"
            height="auto"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7, 1fr)",
              gap: "5px",
              marginBottom: "30px"
            }}
          >
            {getDaysInMonth().map((day, index) => (
              <Frame
                key={index}
                name={`Day-${day || `empty-${index}`}`}
                background={selectedDate && day === selectedDate.getDate() ? colors.selectedDay : "transparent"}
                width="auto"
                height="auto"
                style={{
                  borderRadius: "10px",
                  overflow: "hidden",
                  cursor: day && availability[day]?.available > 0 ? "pointer" : "default",
                  opacity: !day || availability[day]?.available === 0 ? 0.5 : 1
                }}
                whileHover={day && availability[day]?.available > 0 ? {
                  scale: 1.05,
                  boxShadow: "0 5px 15px rgba(0, 0, 0, 0.1)"
                } : {}}
                onClick={() => selectDay(day)}
              >
                <Frame
                  name={`DayContent-${day || `empty-${index}`}`}
                  background="transparent"
                  width="100%"
                  height="auto"
                  style={{
                    padding: "10px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    minHeight: "70px"
                  }}
                >
                  {day && (
                    <>
                      <Frame
                        name={`DayNumber-${day}`}
                        background="transparent"
                        width="auto"
                        height="auto"
                        style={{
                          fontSize: "16px",
                          fontWeight: 500,
                          marginBottom: "5px"
                        }}
                      >
                        {day}
                      </Frame>
                      
                      <Frame
                        name={`DayAvailability-${day}`}
                        background={getAvailabilityColor(day)}
                        width="auto"
                        height="auto"
                        style={{
                          fontSize: "12px",
                          padding: "2px 8px",
                          borderRadius: "10px",
                          color: "white",
                          fontWeight: 500
                        }}
                      >
                        {getAvailabilityText(day)}
                      </Frame>
                    </>
                  )}
                </Frame>
              </Frame>
            ))}
          </Frame>
          
          {/* Selección de hora */}
          {selectedDate && (
            <Frame
              name="TimeSelection"
              background="transparent"
              width="100%"
              height="auto"
              style={{
                marginTop: "20px"
              }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Frame
                name="TimeSelectionTitle"
                background="transparent"
                width="auto"
                height="auto"
                style={{
                  fontSize: "18px",
                  fontWeight: 600,
                  color: colors.primaryText,
                  marginBottom: "15px"
                }}
              >
                Horarios disponibles para el {selectedDate.getDate()} de {getMonthName(selectedDate)} de {selectedDate.getFullYear()}
              </Frame>
              
              <Frame
                name="TimeSlots"
                background="transparent"
                width="100%"
                height="auto"
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))",
                  gap: "10px",
                  marginBottom: "20px"
                }}
              >
                {getAvailableHours().map((timeSlot, index) => (
                  <Frame
                    key={index}
                    name={`TimeSlot-${timeSlot.hour}`}
                    background={selectedTime === timeSlot.display ? colors.primaryButton : "white"}
                    width="auto"
                    height="auto"
                    style={{
                      padding: "10px 15px",
                      borderRadius: "10px",
                      border: `1px solid ${selectedTime === timeSlot.display ? colors.primaryButton : "#e0e0e0"}`,
                      textAlign: "center",
                      cursor: "pointer",
                      color: selectedTime === timeSlot.display ? "white" : colors.primaryText
                    }}
                    whileHover={{
                      scale: 1.05,
                      boxShadow: "0 5px 15px rgba(0, 0, 0, 0.1)"
                    }}
                    onClick={() => selectTime(timeSlot.display)}
                  >
                    {timeSlot.display}
                  </Frame>
                ))}
              </Frame>
              
              {selectedTime && (
                <Frame
                  name="BookingButton"
                  background={colors.primaryButton}
                  width="100%"
                  height="auto"
                  style={{
                    padding: "15px",
                    borderRadius: "10px",
                    textAlign: "center",
                    cursor: "pointer",
                    color: "white",
                    fontWeight: 600,
                    marginTop: "20px"
                  }}
                  whileHover={{
                    scale: 1.02,
                    boxShadow: "0 5px 15px rgba(124, 82, 237, 0.3)"
                  }}
                  onClick={() => setShowBookingForm(true)}
                >
                  Reservar Demostración
                </Frame>
              )}
            </Frame>
          )}
        </Frame>
      </Frame>
      
      {/* Formulario de reserva (modal) */}
      {showBookingForm && (
        <Frame
          name="BookingFormModal"
          background="rgba(0, 0, 0, 0.5)"
          width="100%"
          height="100%"
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            zIndex: 1000,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            padding: "20px"
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Frame
            name="BookingFormContainer"
            background="white"
            width="100%"
            height="auto"
            style={{
              maxWidth: "500px",
              borderRadius: "20px",
              padding: "30px",
              maxHeight: "90vh",
              overflow: "auto"
            }}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Frame
              name="CloseButton"
              background="transparent"
              width={30}
              height={30}
              style={{
                position: "absolute",
                top: "20px",
                right: "20px",
                cursor: "pointer"
              }}
              onClick={() => setShowBookingForm(false)}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18" stroke={colors.primaryText} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M6 6L18 18" stroke={colors.primaryText} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </Frame>
            
            {bookingStep === 1 && (
              <Frame
                name="BookingStep1"
                background="transparent"
                width="100%"
                height="auto"
              >
                <Frame
                  name="BookingFormTitle"
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    fontSize: "24px",
                    fontWeight: 600,
                    color: colors.primaryText,
                    marginBottom: "20px",
                    textAlign: "center"
                  }}
                >
                  Reserva tu Demostración
                </Frame>
                
                <Frame
                  name="BookingDetails"
                  background={`linear-gradient(135deg, ${colors.gradientStart}, ${colors.gradientEnd})`}
                  width="100%"
                  height="auto"
                  style={{
                    borderRadius: "15px",
                    padding: "20px",
                    color: "white",
                    marginBottom: "30px"
                  }}
                >
                  <Frame
                    name="BookingDetailsTitle"
                    background="transparent"
                    width="auto"
                    height="auto"
                    style={{
                      fontSize: "18px",
                      fontWeight: 600,
                      marginBottom: "15px"
                    }}
                  >
                    Detalles de tu reserva
                  </Frame>
                  
                  <Frame
                    name="BookingDetailsContent"
                    background="transparent"
                    width="auto"
                    height="auto"
                    style={{
                      fontSize: "16px",
                      lineHeight: 1.6
                    }}
                  >
                    <p><strong>Fecha:</strong> {selectedDate.getDate()} de {getMonthName(selectedDate)} de {selectedDate.getFullYear()}</p>
                    <p><strong>Hora:</strong> {selectedTime}</p>
                    <p><strong>País:</strong> {selectedCountry.name}</p>
                    <p><strong>Duración:</strong> 30 minutos</p>
                  </Frame>
                </Frame>
                
                <Frame
                  name="BookingForm"
                  background="transparent"
                  width="100%"
                  height="auto"
                  as="form"
                  onSubmit={handleSubmit}
                >
                  <Frame
                    name="FormFields"
                    background="transparent"
                    width="100%"
                    height="auto"
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "15px"
                    }}
                  >
                    <Frame
                      name="NameField"
                      background="transparent"
                      width="100%"
                      height="auto"
                    >
                      <label
                        style={{
                          display: "block",
                          marginBottom: "5px",
                          fontSize: "14px",
                          fontWeight: 500,
                          color: colors.primaryText
                        }}
                      >
                        Nombre completo *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleFormChange}
                        required
                        style={{
                          width: "100%",
                          padding: "12px 15px",
                          borderRadius: "10px",
                          border: "1px solid #e0e0e0",
                          fontSize: "16px"
                        }}
                      />
                    </Frame>
                    
                    <Frame
                      name="EmailField"
                      background="transparent"
                      width="100%"
                      height="auto"
                    >
                      <label
                        style={{
                          display: "block",
                          marginBottom: "5px",
                          fontSize: "14px",
                          fontWeight: 500,
                          color: colors.primaryText
                        }}
                      >
                        Correo electrónico *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleFormChange}
                        required
                        style={{
                          width: "100%",
                          padding: "12px 15px",
                          borderRadius: "10px",
                          border: "1px solid #e0e0e0",
                          fontSize: "16px"
                        }}
                      />
                    </Frame>
                    
                    <Frame
                      name="PhoneField"
                      background="transparent"
                      width="100%"
                      height="auto"
                    >
                      <label
                        style={{
                          display: "block",
                          marginBottom: "5px",
                          fontSize: "14px",
                          fontWeight: 500,
                          color: colors.primaryText
                        }}
                      >
                        Teléfono *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleFormChange}
                        required
                        style={{
                          width: "100%",
                          padding: "12px 15px",
                          borderRadius: "10px",
                          border: "1px solid #e0e0e0",
                          fontSize: "16px"
                        }}
                      />
                    </Frame>
                    
                    <Frame
                      name="CompanyField"
                      background="transparent"
                      width="100%"
                      height="auto"
                    >
                      <label
                        style={{
                          display: "block",
                          marginBottom: "5px",
                          fontSize: "14px",
                          fontWeight: 500,
                          color: colors.primaryText
                        }}
                      >
                        Empresa
                      </label>
                      <input
                        type="text"
                        name="company"
                        value={formData.company}
                        onChange={handleFormChange}
                        style={{
                          width: "100%",
                          padding: "12px 15px",
                          borderRadius: "10px",
                          border: "1px solid #e0e0e0",
                          fontSize: "16px"
                        }}
                      />
                    </Frame>
                    
                    <Frame
                      name="MessageField"
                      background="transparent"
                      width="100%"
                      height="auto"
                    >
                      <label
                        style={{
                          display: "block",
                          marginBottom: "5px",
                          fontSize: "14px",
                          fontWeight: 500,
                          color: colors.primaryText
                        }}
                      >
                        Mensaje
                      </label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleFormChange}
                        style={{
                          width: "100%",
                          padding: "12px 15px",
                          borderRadius: "10px",
                          border: "1px solid #e0e0e0",
                          fontSize: "16px",
                          minHeight: "100px",
                          resize: "vertical"
                        }}
                      />
                    </Frame>
                  </Frame>
                  
                  <Frame
                    name="SubmitButton"
                    background={colors.primaryButton}
                    width="100%"
                    height="auto"
                    style={{
                      padding: "15px",
                      borderRadius: "10px",
                      textAlign: "center",
                      cursor: "pointer",
                      color: "white",
                      fontWeight: 600,
                      marginTop: "30px",
                      border: "none"
                    }}
                    as="button"
                    type="submit"
                    whileHover={{
                      scale: 1.02,
                      boxShadow: "0 5px 15px rgba(124, 82, 237, 0.3)"
                    }}
                  >
                    Confirmar Reserva
                  </Frame>
                </Frame>
              </Frame>
            )}
            
            {bookingStep === 3 && (
              <Frame
                name="BookingConfirmation"
                background="transparent"
                width="100%"
                height="auto"
                style={{
                  textAlign: "center",
                  padding: "20px 0"
                }}
              >
                <Frame
                  name="ConfirmationIcon"
                  background={colors.available}
                  width={80}
                  height={80}
                  radius="50%"
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    margin: "0 auto 20px"
                  }}
                >
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </Frame>
                
                <Frame
                  name="ConfirmationTitle"
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    fontSize: "24px",
                    fontWeight: 600,
                    color: colors.primaryText,
                    marginBottom: "15px"
                  }}
                >
                  ¡Reserva Confirmada!
                </Frame>
                
                <Frame
                  name="ConfirmationMessage"
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    fontSize: "16px",
                    lineHeight: 1.6,
                    color: colors.secondaryText,
                    marginBottom: "30px"
                  }}
                >
                  <p>Hemos recibido tu solicitud de demostración.</p>
                  <p>Te enviaremos un correo electrónico con los detalles de la reserva y un enlace para unirte a la llamada.</p>
                  <p>¡Gracias por tu interés en WAI Agents!</p>
                </Frame>
                
                <Frame
                  name="CloseConfirmationButton"
                  background={colors.secondaryButton}
                  width="auto"
                  height="auto"
                  style={{
                    padding: "12px 25px",
                    borderRadius: "10px",
                    display: "inline-block",
                    cursor: "pointer",
                    color: "white",
                    fontWeight: 500
                  }}
                  whileHover={{
                    scale: 1.05,
                    boxShadow: "0 5px 15px rgba(72, 194, 240, 0.3)"
                  }}
                  onClick={() => setShowBookingForm(false)}
                >
                  Cerrar
                </Frame>
              </Frame>
            )}
          </Frame>
        </Frame>
      )}
    </Frame>
  )
}

export default AvailabilityCalendar
