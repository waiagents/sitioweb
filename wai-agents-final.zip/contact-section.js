// contact-section.js - Componente de sección de Contacto para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal de la sección de Contacto
export function ContactSection() {
  // Animaciones para los elementos
  const controls = useAnimation()
  
  // Estado para el formulario
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    industry: "",
    message: ""
  })
  
  // Estado para la validación del formulario
  const [formErrors, setFormErrors] = useState({})
  
  // Estado para el envío del formulario
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)
  
  // Opciones de industria
  const industryOptions = [
    "Sector Salud",
    "Sector Belleza",
    "Sector Automotriz",
    "Sector Inmobiliario",
    "Sector Legal",
    "Sector Gastronómico",
    "Sector Educativo",
    "Sector Turismo",
    "Sector Deportivo",
    "Sector Veterinario",
    "Sector Espacios de Trabajo",
    "Otro"
  ]
  
  // Función para manejar cambios en los campos del formulario
  const handleInputChange = (field, value) => {
    setFormState({
      ...formState,
      [field]: value
    })
    
    // Limpiar error si el campo tiene valor
    if (value.trim() !== "") {
      setFormErrors({
        ...formErrors,
        [field]: null
      })
    }
  }
  
  // Función para validar el formulario
  const validateForm = () => {
    const errors = {}
    
    if (!formState.name.trim()) {
      errors.name = "El nombre es requerido"
    }
    
    if (!formState.email.trim()) {
      errors.email = "El correo electrónico es requerido"
    } else if (!/\S+@\S+\.\S+/.test(formState.email)) {
      errors.email = "El correo electrónico no es válido"
    }
    
    if (!formState.company.trim()) {
      errors.company = "La empresa es requerida"
    }
    
    if (!formState.industry) {
      errors.industry = "Selecciona un sector"
    }
    
    if (!formState.message.trim()) {
      errors.message = "El mensaje es requerido"
    }
    
    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }
  
  // Función para manejar el envío del formulario
  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (validateForm()) {
      setIsSubmitting(true)
      
      // Simulación de envío a Formspree (en un caso real, esto sería un fetch)
      setTimeout(() => {
        setIsSubmitting(false)
        setSubmitSuccess(true)
        
        // Resetear el formulario después de 3 segundos
        setTimeout(() => {
          setFormState({
            name: "",
            email: "",
            phone: "",
            company: "",
            industry: "",
            message: ""
          })
          setSubmitSuccess(false)
        }, 3000)
      }, 1500)
    }
  }
  
  // Efecto para detectar cuando la sección es visible
  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('contact')
      if (element) {
        const rect = element.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom >= 0
        
        if (isVisible) {
          controls.start({
            opacity: 1,
            y: 0,
            transition: { duration: 0.8, staggerChildren: 0.2 }
          })
        }
      }
    }
    
    window.addEventListener('scroll', handleScroll)
    // Trigger once on mount
    handleScroll()
    
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  return (
    <Frame
      name="ContactSection"
      id="contact"
      background={colors.background}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Contáctanos
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        ¿Listo para automatizar tu negocio? Estamos aquí para ayudarte
      </Frame>

      <Frame
        name="ContactContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: "50px",
          maxWidth: "1200px",
          opacity: 0,
          y: 20,
          "@media (max-width: 992px)": {
            flexDirection: "column"
          }
        }}
        animate={controls}
      >
        {/* Información de contacto */}
        <Frame
          name="ContactInfo"
          background="transparent"
          width="40%"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "30px",
            "@media (max-width: 992px)": {
              width: "100%"
            }
          }}
        >
          <Frame
            name="ContactIntro"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              lineHeight: 1.6,
              color: colors.primaryText
            }}
          >
            Estamos disponibles para responder a todas tus preguntas sobre nuestros servicios de automatización. Contáctanos a través del formulario o utiliza cualquiera de nuestros canales de comunicación.
          </Frame>

          <Frame
            name="ContactMethods"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "20px"
            }}
          >
            <ContactMethod 
              icon="email" 
              title="Email" 
              detail="waiagents@gmail.com"
            />
            <ContactMethod 
              icon="phone" 
              title="WhatsApp" 
              detail="(809) 790-4481"
            />
            <ContactMethod 
              icon="location" 
              title="Ubicación" 
              detail="República Dominicana"
            />
          </Frame>

          {/* Redes sociales */}
          <Frame
            name="SocialMedia"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              display: "flex",
              gap: "15px",
              marginTop: "10px"
            }}
          >
            <SocialIcon icon="facebook" url="https://www.facebook.com/share/19Pj4HMf1d/?mibextid=wwXIfr" />
            <SocialIcon icon="instagram" url="https://www.instagram.com/waiagents?igsh=MWQ5ZHYwa2djeXVmMA%3D%3D&utm_source=qr" />
            <SocialIcon icon="twitter" />
            <SocialIcon icon="linkedin" />
          </Frame>
          
          {/* Mapa o imagen de ubicación */}
          <Frame
            name="LocationMap"
            background="#E0E5EC"
            width="100%"
            height={200}
            radius={15}
            style={{
              marginTop: "20px",
              overflow: "hidden",
              boxShadow: "0 10px 30px rgba(0, 0, 0, 0.05)"
            }}
          >
            {/* Aquí iría un iframe de Google Maps o una imagen */}
            <Frame
              name="MapPlaceholder"
              background={{
                type: "gradient",
                gradient: {
                  angle: 135,
                  stops: [
                    { position: 0, color: colors.gradientStart },
                    { position: 100, color: colors.gradientEnd }
                  ]
                }
              }}
              width="100%"
              height="100%"
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                color: "white",
                fontSize: "14px",
                fontWeight: 500
              }}
            >
              Mapa de ubicación
            </Frame>
          </Frame>
        </Frame>

        {/* Formulario de contacto */}
        <Frame
          name="ContactForm"
          background="white"
          width="55%"
          height="auto"
          radius={20}
          style={{
            padding: "40px",
            boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)",
            "@media (max-width: 992px)": {
              width: "100%"
            }
          }}
        >
          <form
            action="https://formspree.io/f/waiagents@gmail.com"
            method="POST"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "20px"
            }}
            onSubmit={handleSubmit}
          >
            <Frame
              name="FormFields"
              background="transparent"
              width="100%"
              height="auto"
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "20px"
              }}
            >
              <FormField 
                type="text" 
                name="name" 
                placeholder="Nombre completo" 
                required={true}
                value={formState.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                error={formErrors.name}
              />
              <FormField 
                type="email" 
                name="email" 
                placeholder="Correo electrónico" 
                required={true}
                value={formState.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                error={formErrors.email}
              />
              <FormField 
                type="tel" 
                name="phone" 
                placeholder="Teléfono (opcional)" 
                required={false}
                value={formState.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
              />
              <FormField 
                type="text" 
                name="company" 
                placeholder="Empresa" 
                required={true}
                value={formState.company}
                onChange={(e) => handleInputChange("company", e.target.value)}
                error={formErrors.company}
              />
              <FormField 
                type="select" 
                name="industry" 
                placeholder="Selecciona tu sector" 
                required={true}
                value={formState.industry}
                onChange={(e) => handleInputChange("industry", e.target.value)}
                options={industryOptions}
                error={formErrors.industry}
              />
              <FormField 
                type="textarea" 
                name="message" 
                placeholder="¿Cómo podemos ayudarte?" 
                required={true}
                value={formState.message}
                onChange={(e) => handleInputChange("message", e.target.value)}
                error={formErrors.message}
              />
            </Frame>

            <Frame
              name="SubmitButton"
              background={isSubmitting ? "#A0A0A0" : submitSuccess ? "#4CAF50" : colors.primaryButton}
              width="100%"
              height="auto"
              style={{
                padding: "15px",
                borderRadius: "10px",
                fontSize: "16px",
                fontWeight: 600,
                color: "white",
                textAlign: "center",
                marginTop: "10px",
                cursor: isSubmitting ? "default" : "pointer",
                border: "none",
                boxShadow: "0 10px 20px rgba(124, 82, 237, 0.3)",
                transition: "all 0.3s ease",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px"
              }}
              whileHover={!isSubmitting && !submitSuccess ? {
                scale: 1.02,
                boxShadow: "0 15px 30px rgba(124, 82, 237, 0.4)"
              } : {}}
              as="button"
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Frame
                    name="LoadingSpinner"
                    background="transparent"
                    width={20}
                    height={20}
                    style={{
                      border: "2px solid rgba(255, 255, 255, 0.3)",
                      borderTop: "2px solid white",
                      borderRadius: "50%"
                    }}
                    animate={{
                      rotate: 360
                    }}
                    transition={{
                      duration: 1,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                  />
                  Enviando...
                </>
              ) : submitSuccess ? (
                <>
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 12.5L5 9.5L4 10.5L8 14.5L16 6.5L15 5.5L8 12.5Z" fill="white"/>
                  </svg>
                  ¡Mensaje Enviado!
                </>
              ) : (
                "Enviar Mensaje"
              )}
            </Frame>
          </form>
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Método de Contacto
function ContactMethod({ icon, title, detail }) {
  return (
    <Frame
      name={`ContactMethod-${title}`}
      background="transparent"
      width="auto"
      height="auto"
      style={{
        display: "flex",
        alignItems: "center",
        gap: "15px"
      }}
    >
      <Frame
        name="MethodIcon"
        background={{
          type: "gradient",
          gradient: {
            angle: 135,
            stops: [
              { position: 0, color: colors.primaryButton },
              { position: 100, color: colors.secondaryButton }
            ]
          }
        }}
        width={50}
        height={50}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
        <Frame
          name="Icon"
          background="transparent"
          width={25}
          height={25}
          style={{
            backgroundImage: `url('/icons/${icon}.svg')`,
            backgroundSize: "contain",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat"
          }}
        />
      </Frame>
      <Frame
        name="MethodInfo"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column"
        }}
      >
        <Frame
          name="MethodTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            fontWeight: 600,
            color: colors.primaryText
          }}
        >
          {title}
        </Frame>
        <Frame
          name="MethodDetail"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            color: colors.secondaryText
          }}
        >
          {detail}
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Icono Social
function SocialIcon({ icon }) {
  return (
    <Frame
      name={`SocialIcon-${icon}`}
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: colors.primaryButton },
            { position: 100, color: colors.secondaryButton }
          ]
        }
      }}
      width={40}
      height={40}
      radius="50%"
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        cursor: "pointer",
        transition: "transform 0.3s ease"
      }}
      whileHover={{
        scale: 1.1
      }}
    >
      <Frame
        name="Icon"
        background="transparent"
        width={20}
        height={20}
        style={{
          backgroundImage: `url('/icons/${icon}.svg')`,
          backgroundSize: "contain",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat"
        }}
      />
    </Frame>
  )
}

// Componente de Campo de Formulario
function FormField({ type, name, placeholder, required, value, onChange, options = [], error }) {
  if (type === "textarea") {
    return (
      <Frame
        name={`FormField-${name}`}
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column"
        }}
      >
        <textarea
          name={name}
          placeholder={placeholder}
          required={required}
          value={value}
          onChange={onChange}
          style={{
            width: "100%",
            height: "120px",
            padding: "15px",
            borderRadius: "10px",
            border: error ? "1px solid #FF5A5A" : "1px solid #ddd",
            fontSize: "16px",
            fontFamily: "Inter, sans-serif",
            resize: "vertical"
          }}
        />
        {error && (
          <Frame
            name={`Error-${name}`}
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "12px",
              color: "#FF5A5A",
              marginTop: "5px"
            }}
          >
            {error}
          </Frame>
        )}
      </Frame>
    )
  } else if (type === "select") {
    return (
      <Frame
        name={`FormField-${name}`}
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column"
        }}
      >
        <select
          name={name}
          required={required}
          value={value}
          onChange={onChange}
          style={{
            width: "100%",
            padding: "15px",
            borderRadius: "10px",
            border: error ? "1px solid #FF5A5A" : "1px solid #ddd",
            fontSize: "16px",
            fontFamily: "Inter, sans-serif",
            appearance: "none",
            backgroundImage: "url('/icons/arrow-down.svg')",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "right 15px center",
            backgroundSize: "15px"
          }}
        >
          <option value="" disabled selected>
            {placeholder}
          </option>
          {options.map((option, index) => (
            <option key={index} value={option}>
              {option}
            </option>
          ))}
        </select>
        {error && (
          <Frame
            name={`Error-${name}`}
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "12px",
              color: "#FF5A5A",
              marginTop: "5px"
            }}
          >
            {error}
          </Frame>
        )}
      </Frame>
    )
  } else {
    return (
      <Frame
        name={`FormField-${name}`}
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column"
        }}
      >
        <input
          type={type}
          name={name}
          placeholder={placeholder}
          required={required}
          value={value}
          onChange={onChange}
          style={{
            width: "100%",
            padding: "15px",
            borderRadius: "10px",
            border: error ? "1px solid #FF5A5A" : "1px solid #ddd",
            fontSize: "16px",
            fontFamily: "Inter, sans-serif"
          }}
        />
        {error && (
          <Frame
            name={`Error-${name}`}
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "12px",
              color: "#FF5A5A",
              marginTop: "5px"
            }}
          >
            {error}
          </Frame>
        )}
      </Frame>
    )
  }
}

export default ContactSection
