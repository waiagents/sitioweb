// footer.js - Componente de footer para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal del Footer
export function Footer() {
  // Animaciones para los elementos
  const controls = useAnimation()
  
  // Año actual para el copyright
  const currentYear = new Date().getFullYear()
  
  // Datos de enlaces del footer
  const footerLinks = {
    company: [
      { label: "Sobre Nosotros", href: "#about" },
      { label: "Servicios", href: "#services" },
      { label: "Casos de Éxito", href: "#testimonials" },
      { label: "Proceso", href: "#process" },
      { label: "Blog", href: "#blog" }
    ],
    services: [
      { label: "Sector Salud", href: "#services" },
      { label: "Sector Inmobiliario", href: "#services" },
      { label: "Sector Gastronómico", href: "#services" },
      { label: "Sector Educativo", href: "#services" },
      { label: "Ver todos los sectores", href: "#services" }
    ],
    resources: [
      { label: "Calendario de Disponibilidad", href: "#availability" },
      { label: "Preguntas Frecuentes", href: "#faq" },
      { label: "Documentación", href: "#docs" },
      { label: "Tutoriales", href: "#tutorials" },
      { label: "Soporte", href: "#support" }
    ],
    legal: [
      { label: "Términos y Condiciones", href: "#terms" },
      { label: "Política de Privacidad", href: "#privacy" },
      { label: "Política de Cookies", href: "#cookies" }
    ]
  }
  
  // Efecto para detectar cuando el footer es visible
  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('footer')
      if (element) {
        const rect = element.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom >= 0
        
        if (isVisible) {
          controls.start({
            opacity: 1,
            y: 0,
            transition: { duration: 0.8, staggerChildren: 0.1 }
          })
        }
      }
    }
    
    window.addEventListener('scroll', handleScroll)
    // Trigger once on mount
    handleScroll()
    
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  return (
    <Frame
      name="Footer"
      id="footer"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: colors.gradientStart },
            { position: 100, color: colors.gradientEnd }
          ]
        }
      }}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        padding: "80px 5% 40px",
        color: "white",
        position: "relative"
      }}
    >
      {/* Elementos decorativos */}
      <Frame
        name="FooterDecoration"
        background="transparent"
        width="100%"
        height="100%"
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          overflow: "hidden",
          pointerEvents: "none"
        }}
      >
        <Frame
          name="GlowCircle1"
          background="radial-gradient(circle, rgba(124, 82, 237, 0.3) 0%, rgba(124, 82, 237, 0) 70%)"
          width={400}
          height={400}
          radius="50%"
          style={{
            position: "absolute",
            top: "-200px",
            right: "-100px"
          }}
        />
        <Frame
          name="GlowCircle2"
          background="radial-gradient(circle, rgba(72, 194, 240, 0.2) 0%, rgba(72, 194, 240, 0) 70%)"
          width={500}
          height={500}
          radius="50%"
          style={{
            position: "absolute",
            bottom: "-250px",
            left: "-150px"
          }}
        />
      </Frame>
      
      {/* Contenido principal del footer */}
      <Frame
        name="FooterContent"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          maxWidth: "1200px",
          margin: "0 auto",
          position: "relative",
          zIndex: 1
        }}
      >
        {/* Sección superior */}
        <Frame
          name="FooterTop"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginBottom: "60px",
            opacity: 0,
            y: 20,
            "@media (max-width: 768px)": {
              flexDirection: "column",
              gap: "40px"
            }
          }}
          animate={controls}
        >
          {/* Logo y descripción */}
          <Frame
            name="FooterBrand"
            background="transparent"
            width="30%"
            height="auto"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              "@media (max-width: 768px)": {
                width: "100%"
              }
            }}
          >
            <Frame
              name="FooterLogo"
              background="transparent"
              width={150}
              height={50}
              style={{
                display: "flex",
                alignItems: "center"
              }}
            >
              <img src="/logo-white.png" alt="WAI Agents Logo" style={{ height: "100%" }} />
            </Frame>
            <Frame
              name="FooterDescription"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "16px",
                lineHeight: 1.6,
                opacity: 0.9
              }}
            >
              Automatizamos TODO con inteligencia artificial. Transformamos la atención al cliente en una experiencia de alto nivel.
            </Frame>
            
            {/* Redes sociales */}
            <Frame
              name="FooterSocial"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                display: "flex",
                gap: "15px",
                marginTop: "10px"
              }}
            >
              <SocialIcon icon="facebook" />
              <SocialIcon icon="twitter" />
              <SocialIcon icon="instagram" />
              <SocialIcon icon="linkedin" />
            </Frame>
          </Frame>
          
          {/* Enlaces */}
          <Frame
            name="FooterLinks"
            background="transparent"
            width="65%"
            height="auto"
            style={{
              display: "flex",
              justifyContent: "space-between",
              "@media (max-width: 768px)": {
                width: "100%",
                flexWrap: "wrap",
                gap: "30px"
              },
              "@media (max-width: 576px)": {
                flexDirection: "column"
              }
            }}
          >
            <FooterLinkColumn title="Empresa" links={footerLinks.company} />
            <FooterLinkColumn title="Servicios" links={footerLinks.services} />
            <FooterLinkColumn title="Recursos" links={footerLinks.resources} />
            <FooterLinkColumn title="Legal" links={footerLinks.legal} />
          </Frame>
        </Frame>
        
        {/* Separador */}
        <Frame
          name="FooterDivider"
          background="rgba(255, 255, 255, 0.2)"
          width="100%"
          height={1}
          style={{
            marginBottom: "30px",
            opacity: 0
          }}
          animate={controls}
        />
        
        {/* Sección inferior */}
        <Frame
          name="FooterBottom"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            opacity: 0,
            "@media (max-width: 576px)": {
              flexDirection: "column",
              gap: "15px",
              alignItems: "flex-start"
            }
          }}
          animate={controls}
        >
          <Frame
            name="Copyright"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "14px",
              opacity: 0.8
            }}
          >
            © {currentYear} WAI Agents. Todos los derechos reservados.
          </Frame>
          
          <Frame
            name="FooterBottomLinks"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              display: "flex",
              gap: "20px"
            }}
          >
            <Frame
              name="LanguageSelector"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "14px",
                opacity: 0.8,
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "5px"
              }}
              whileHover={{
                opacity: 1
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2 12H22" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M12 2C14.5013 4.73835 15.9228 8.29203 16 12C15.9228 15.708 14.5013 19.2616 12 22C9.49872 19.2616 8.07725 15.708 8 12C8.07725 8.29203 9.49872 4.73835 12 2Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Español
            </Frame>
            
            <Frame
              name="BackToTop"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "14px",
                opacity: 0.8,
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "5px"
              }}
              whileHover={{
                opacity: 1
              }}
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            >
              Volver arriba
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 19V5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M5 12L12 5L19 12" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </Frame>
          </Frame>
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Columna de Enlaces
function FooterLinkColumn({ title, links }) {
  return (
    <Frame
      name={`FooterColumn-${title}`}
      background="transparent"
      width="auto"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "15px",
        "@media (max-width: 768px)": {
          width: "calc(50% - 15px)"
        },
        "@media (max-width: 576px)": {
          width: "100%"
        }
      }}
    >
      <Frame
        name="ColumnTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "18px",
          fontWeight: 600,
          marginBottom: "5px"
        }}
      >
        {title}
      </Frame>
      
      <Frame
        name="ColumnLinks"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "10px"
        }}
      >
        {links.map((link, index) => (
          <Frame
            key={index}
            name={`Link-${link.label}`}
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "14px",
              opacity: 0.8,
              cursor: "pointer",
              transition: "all 0.3s ease"
            }}
            whileHover={{
              opacity: 1,
              x: 5
            }}
            onClick={() => window.location.href = link.href}
          >
            {link.label}
          </Frame>
        ))}
      </Frame>
    </Frame>
  )
}

// Componente de Icono Social
function SocialIcon({ icon }) {
  return (
    <Frame
      name={`SocialIcon-${icon}`}
      background="rgba(255, 255, 255, 0.1)"
      width={36}
      height={36}
      radius="50%"
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        cursor: "pointer",
        transition: "all 0.3s ease"
      }}
      whileHover={{
        scale: 1.1,
        background: "rgba(255, 255, 255, 0.2)"
      }}
    >
      <Frame
        name="Icon"
        background="transparent"
        width={18}
        height={18}
        style={{
          backgroundImage: `url('/icons/${icon}-white.svg')`,
          backgroundSize: "contain",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat"
        }}
      />
    </Frame>
  )
}

export default Footer
