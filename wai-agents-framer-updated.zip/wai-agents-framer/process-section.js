// process-section.js - Componente de sección de Proceso de Trabajo para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal de la sección de Proceso de Trabajo
export function ProcessSection() {
  // Animaciones para los elementos
  const controls = useAnimation()
  
  // Datos de los pasos del proceso
  const processSteps = [
    {
      number: "01",
      title: "Demostración Inicial",
      description: "Prueba nuestro servicio durante 4 días por solo $35. Experimenta cómo la automatización puede transformar tu negocio sin compromiso a largo plazo."
    },
    {
      number: "02",
      title: "Análisis de Necesidades",
      description: "Nuestro equipo analiza los procesos específicos de tu negocio para identificar las áreas con mayor potencial de automatización y retorno de inversión."
    },
    {
      number: "03",
      title: "Implementación Personalizada",
      description: "Desarrollamos e implementamos soluciones de automatización adaptadas específicamente a tu sector y necesidades particulares."
    },
    {
      number: "04",
      title: "Soporte Continuo",
      description: "Proporcionamos soporte técnico, actualizaciones y optimizaciones continuas para asegurar que tu sistema de automatización evolucione con tu negocio."
    }
  ]
  
  // Efecto para detectar cuando la sección es visible
  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('process')
      if (element) {
        const rect = element.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom >= 0
        
        if (isVisible) {
          controls.start({
            opacity: 1,
            y: 0,
            transition: { duration: 0.8, staggerChildren: 0.2 }
          })
        }
      }
    }
    
    window.addEventListener('scroll', handleScroll)
    // Trigger once on mount
    handleScroll()
    
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  return (
    <Frame
      name="ProcessSection"
      id="process"
      background={colors.background}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Nuestro Proceso
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "70px",
          textAlign: "center",
          maxWidth: "800px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Implementamos soluciones de automatización en 4 simples pasos
      </Frame>

      {/* Línea de tiempo del proceso */}
      <Frame
        name="ProcessTimeline"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          position: "relative",
          maxWidth: "1000px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        {/* Línea conectora */}
        <Frame
          name="ConnectingLine"
          background={colors.primaryButton}
          width={4}
          height="100%"
          style={{
            position: "absolute",
            left: "50%",
            transform: "translateX(-50%)",
            top: 0,
            zIndex: 1,
            opacity: 0.3,
            "@media (max-width: 768px)": {
              left: "40px",
              transform: "none"
            }
          }}
        />
        
        {/* Pasos del proceso */}
        {processSteps.map((step, index) => (
          <ProcessStep 
            key={index}
            number={step.number} 
            title={step.title} 
            description={step.description}
            isLeft={index % 2 === 0}
            delay={index * 0.2}
          />
        ))}
      </Frame>

      {/* CTA */}
      <Frame
        name="ProcessCTA"
        background={colors.primaryButton}
        width="auto"
        height="auto"
        style={{
          padding: "15px 40px",
          borderRadius: "30px",
          fontSize: "18px",
          fontWeight: 600,
          color: "white",
          marginTop: "50px",
          cursor: "pointer",
          boxShadow: "0 10px 20px rgba(124, 82, 237, 0.3)",
          transition: "transform 0.3s ease, box-shadow 0.3s ease",
          opacity: 0,
          y: 20
        }}
        animate={controls}
        whileHover={{ 
          scale: 1.05,
          boxShadow: "0 15px 30px rgba(124, 82, 237, 0.4)"
        }}
        onClick={() => window.location.href = "#availability"}
      >
        Comienza con tu Demo
      </Frame>
    </Frame>
  )
}

// Componente de Paso del Proceso
function ProcessStep({ number, title, description, isLeft, delay = 0 }) {
  const controls = useAnimation()
  
  useEffect(() => {
    const timeout = setTimeout(() => {
      controls.start({
        opacity: 1,
        x: 0,
        transition: { duration: 0.5, type: "spring" }
      })
    }, delay * 1000)
    
    return () => clearTimeout(timeout)
  }, [])
  
  return (
    <Frame
      name={`ProcessStep-${number}`}
      background="transparent"
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: isLeft ? "row" : "row-reverse",
        alignItems: "center",
        marginBottom: "50px",
        position: "relative",
        zIndex: 2,
        "@media (max-width: 768px)": {
          flexDirection: "row"
        }
      }}
    >
      {/* Número del paso */}
      <Frame
        name="StepNumber"
        background={{
          type: "gradient",
          gradient: {
            angle: 135,
            stops: [
              { position: 0, color: colors.primaryButton },
              { position: 100, color: colors.secondaryButton }
            ]
          }
        }}
        width={80}
        height={80}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          fontSize: "24px",
          fontWeight: 700,
          color: "white",
          flexShrink: 0,
          zIndex: 3,
          boxShadow: "0 10px 20px rgba(0, 0, 0, 0.1)"
        }}
      >
        {number}
      </Frame>
      
      {/* Contenido del paso */}
      <Frame
        name="StepContent"
        background="white"
        width={isLeft ? "calc(50% - 40px)" : "calc(50% - 40px)"}
        height="auto"
        radius={15}
        style={{
          padding: "30px",
          boxShadow: "0 10px 30px rgba(0, 0, 0, 0.05)",
          marginLeft: isLeft ? "20px" : "auto",
          marginRight: isLeft ? "auto" : "20px",
          opacity: 0,
          x: isLeft ? -30 : 30,
          "@media (max-width: 768px)": {
            width: "calc(100% - 100px)",
            marginLeft: "20px",
            marginRight: "0"
          }
        }}
        animate={controls}
        whileHover={{
          scale: 1.02,
          boxShadow: "0 15px 40px rgba(0, 0, 0, 0.1)"
        }}
      >
        <Frame
          name="StepTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "20px",
            fontWeight: 600,
            color: colors.primaryText,
            marginBottom: "10px"
          }}
        >
          {title}
        </Frame>
        <Frame
          name="StepDescription"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            lineHeight: 1.6,
            color: colors.secondaryText
          }}
        >
          {description}
        </Frame>
      </Frame>
    </Frame>
  )
}

export default ProcessSection
