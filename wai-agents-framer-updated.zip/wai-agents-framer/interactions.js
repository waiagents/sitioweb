// interactions.js - Componente de interacciones adicionales para WAI Agents

import { 
  Frame, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente de reproductor de YouTube
export function YouTubePlayer({ videoId, title = "Video de WAI Agents" }) {
  const [isLoaded, setIsLoaded] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  
  // Función para manejar el clic en el reproductor
  const handlePlayerClick = () => {
    if (!isPlaying) {
      setIsPlaying(true)
    }
  }
  
  return (
    <Frame
      name={`YouTubePlayer-${videoId}`}
      background="#000"
      width="100%"
      height="auto"
      style={{
        borderRadius: "15px",
        overflow: "hidden",
        boxShadow: "0 20px 40px rgba(0, 0, 0, 0.15)",
        aspectRatio: "16/9",
        position: "relative"
      }}
    >
      {!isPlaying ? (
        <Frame
          name="VideoThumbnail"
          background="#000"
          width="100%"
          height="100%"
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            cursor: "pointer"
          }}
          onClick={handlePlayerClick}
        >
          <img 
            src={`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`} 
            alt={title}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              opacity: 0.7
            }}
            onLoad={() => setIsLoaded(true)}
          />
          
          <Frame
            name="PlayButton"
            background="rgba(124, 82, 237, 0.9)"
            width={80}
            height={80}
            radius="50%"
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              boxShadow: "0 10px 30px rgba(124, 82, 237, 0.5)"
            }}
            whileHover={{
              scale: 1.1,
              background: "rgba(124, 82, 237, 1)"
            }}
          >
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M8 5V19L19 12L8 5Z" fill="white"/>
            </svg>
          </Frame>
          
          <Frame
            name="VideoTitle"
            background="rgba(0, 0, 0, 0.7)"
            width="100%"
            height="auto"
            style={{
              position: "absolute",
              bottom: 0,
              left: 0,
              padding: "15px",
              color: "white",
              fontSize: "16px",
              fontWeight: 500
            }}
          >
            {title}
          </Frame>
        </Frame>
      ) : (
        <iframe
          width="100%"
          height="100%"
          src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`}
          title={title}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%"
          }}
        />
      )}
      
      {!isLoaded && !isPlaying && (
        <Frame
          name="LoadingIndicator"
          background="rgba(0, 0, 0, 0.5)"
          width="100%"
          height="100%"
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
          }}
        >
          <Frame
            name="Spinner"
            background="transparent"
            width={40}
            height={40}
            style={{
              border: "3px solid rgba(255, 255, 255, 0.3)",
              borderTop: "3px solid white",
              borderRadius: "50%"
            }}
            animate={{
              rotate: 360
            }}
            transition={{
              duration: 1,
              repeat: Infinity,
              ease: "linear"
            }}
          />
        </Frame>
      )}
    </Frame>
  )
}

// Componente de microinteracción de botón
export function InteractiveButton({ text, onClick, color = colors.primaryButton, ...props }) {
  const [isPressed, setIsPressed] = useState(false)
  
  return (
    <Frame
      name={`InteractiveButton-${text}`}
      background={color}
      width="auto"
      height="auto"
      style={{
        padding: "15px 30px",
        borderRadius: "30px",
        fontSize: "16px",
        fontWeight: 600,
        color: "white",
        cursor: "pointer",
        boxShadow: `0 10px 20px rgba(${parseInt(color.slice(1, 3), 16)}, ${parseInt(color.slice(3, 5), 16)}, ${parseInt(color.slice(5, 7), 16)}, 0.3)`,
        transition: "all 0.3s ease",
        ...props.style
      }}
      whileHover={{ 
        scale: 1.05,
        boxShadow: `0 15px 30px rgba(${parseInt(color.slice(1, 3), 16)}, ${parseInt(color.slice(3, 5), 16)}, ${parseInt(color.slice(5, 7), 16)}, 0.4)`
      }}
      whileTap={{ 
        scale: 0.95
      }}
      onTapStart={() => setIsPressed(true)}
      onTapCancel={() => setIsPressed(false)}
      onTap={() => {
        setIsPressed(false)
        if (onClick) onClick()
      }}
      {...props}
    >
      <Frame
        name="ButtonText"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: "10px"
        }}
      >
        {text}
        {props.icon && (
          <Frame
            name="ButtonIcon"
            background="transparent"
            width={20}
            height={20}
            style={{
              backgroundImage: `url('/icons/${props.icon}.svg')`,
              backgroundSize: "contain",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat"
            }}
          />
        )}
      </Frame>
      
      <Frame
        name="ButtonRipple"
        background="rgba(255, 255, 255, 0.3)"
        width={isPressed ? "100%" : "0%"}
        height={isPressed ? "100%" : "0%"}
        radius="50%"
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          opacity: isPressed ? 1 : 0,
          transition: "all 0.5s ease"
        }}
      />
    </Frame>
  )
}

// Componente de tarjeta interactiva
export function InteractiveCard({ title, description, icon, ...props }) {
  const [isHovered, setIsHovered] = useState(false)
  
  return (
    <Frame
      name={`InteractiveCard-${title}`}
      background="white"
      width="100%"
      height="auto"
      radius={15}
      style={{
        padding: "30px",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.05)",
        transition: "all 0.3s ease",
        cursor: "pointer",
        ...props.style
      }}
      whileHover={{
        scale: 1.03,
        boxShadow: "0 15px 40px rgba(0, 0, 0, 0.1)",
        y: -5
      }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      {...props}
    >
      <Frame
        name="CardIcon"
        background={isHovered ? colors.primaryButton : "rgba(124, 82, 237, 0.1)"}
        width={60}
        height={60}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginBottom: "20px",
          transition: "all 0.3s ease"
        }}
      >
        <Frame
          name="Icon"
          background="transparent"
          width={30}
          height={30}
          style={{
            backgroundImage: `url('/icons/${icon}.svg')`,
            backgroundSize: "contain",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            filter: isHovered ? "brightness(0) invert(1)" : "none",
            transition: "all 0.3s ease"
          }}
        />
      </Frame>
      
      <Frame
        name="CardTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          fontWeight: 600,
          color: colors.primaryText,
          marginBottom: "10px",
          transition: "all 0.3s ease",
          color: isHovered ? colors.primaryButton : colors.primaryText
        }}
      >
        {title}
      </Frame>
      
      <Frame
        name="CardDescription"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "16px",
          lineHeight: 1.6,
          color: colors.secondaryText
        }}
      >
        {description}
      </Frame>
      
      <Frame
        name="CardArrow"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          fontWeight: 600,
          color: colors.primaryButton,
          marginTop: "15px",
          opacity: isHovered ? 1 : 0,
          x: isHovered ? 0 : -10,
          transition: "all 0.3s ease",
          display: "flex",
          alignItems: "center",
          gap: "5px"
        }}
      >
        Saber más
        <span>→</span>
      </Frame>
    </Frame>
  )
}

// Componente de cursor personalizado
export function CustomCursor() {
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isVisible, setIsVisible] = useState(false)
  const [isClicking, setIsClicking] = useState(false)
  const [isOverLink, setIsOverLink] = useState(false)
  
  useEffect(() => {
    const handleMouseMove = (e) => {
      setPosition({ x: e.clientX, y: e.clientY })
      setIsVisible(true)
    }
    
    const handleMouseDown = () => {
      setIsClicking(true)
    }
    
    const handleMouseUp = () => {
      setIsClicking(false)
    }
    
    const handleMouseLeave = () => {
      setIsVisible(false)
    }
    
    const handleLinkHover = (e) => {
      if (e.target.tagName === 'A' || e.target.closest('a') || 
          e.target.tagName === 'BUTTON' || e.target.closest('button') ||
          e.target.style.cursor === 'pointer' || e.target.closest('[style*="cursor: pointer"]')) {
        setIsOverLink(true)
      } else {
        setIsOverLink(false)
      }
    }
    
    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mousedown', handleMouseDown)
    document.addEventListener('mouseup', handleMouseUp)
    document.addEventListener('mouseleave', handleMouseLeave)
    document.addEventListener('mouseover', handleLinkHover)
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mousedown', handleMouseDown)
      document.removeEventListener('mouseup', handleMouseUp)
      document.removeEventListener('mouseleave', handleMouseLeave)
      document.removeEventListener('mouseover', handleLinkHover)
    }
  }, [])
  
  return (
    <>
      <Frame
        name="CursorDot"
        background={colors.primaryButton}
        width={isClicking ? 12 : 8}
        height={isClicking ? 12 : 8}
        radius="50%"
        style={{
          position: "fixed",
          top: position.y,
          left: position.x,
          transform: "translate(-50%, -50%)",
          zIndex: 9999,
          pointerEvents: "none",
          opacity: isVisible ? 1 : 0,
          transition: "width 0.2s, height 0.2s, opacity 0.2s",
          mixBlendMode: "difference"
        }}
      />
      
      <Frame
        name="CursorRing"
        background="transparent"
        width={isOverLink ? 50 : 30}
        height={isOverLink ? 50 : 30}
        radius="50%"
        style={{
          position: "fixed",
          top: position.y,
          left: position.x,
          transform: "translate(-50%, -50%)",
          zIndex: 9998,
          pointerEvents: "none",
          opacity: isVisible ? 0.5 : 0,
          border: `1px solid ${colors.primaryButton}`,
          transition: "width 0.3s, height 0.3s, opacity 0.3s",
          mixBlendMode: "difference"
        }}
      />
    </>
  )
}

// Componente de notificación toast
export function ToastNotification({ message, type = "success", duration = 3000, onClose }) {
  const [isVisible, setIsVisible] = useState(true)
  
  const colors = {
    success: "#4CAF50",
    error: "#F44336",
    warning: "#FF9800",
    info: "#2196F3"
  }
  
  const icons = {
    success: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M9 16.2L4.8 12L3.4 13.4L9 19L21 7L19.6 5.6L9 16.2Z" fill="white"/>
      </svg>
    ),
    error: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="white"/>
      </svg>
    ),
    warning: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M1 21H23L12 2L1 21ZM13 18H11V16H13V18ZM13 14H11V10H13V14Z" fill="white"/>
      </svg>
    ),
    info: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM13 17H11V11H13V17ZM13 9H11V7H13V9Z" fill="white"/>
      </svg>
    )
  }
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false)
      if (onClose) {
        setTimeout(onClose, 300) // Esperar a que termine la animación de salida
      }
    }, duration)
    
    return () => clearTimeout(timer)
  }, [duration, onClose])
  
  return (
    <Frame
      name="ToastNotification"
      background={colors[type]}
      width="auto"
      height="auto"
      style={{
        padding: "15px 20px",
        borderRadius: "10px",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.2)",
        position: "fixed",
        bottom: "30px",
        right: "30px",
        zIndex: 9999,
        display: "flex",
        alignItems: "center",
        gap: "10px",
        color: "white",
        fontSize: "14px",
        fontWeight: 500,
        opacity: isVisible ? 1 : 0,
        y: isVisible ? 0 : 20,
        transition: "opacity 0.3s, transform 0.3s"
      }}
    >
      <Frame
        name="ToastIcon"
        background="transparent"
        width={20}
        height={20}
      >
        {icons[type]}
      </Frame>
      
      <Frame
        name="ToastMessage"
        background="transparent"
        width="auto"
        height="auto"
      >
        {message}
      </Frame>
      
      <Frame
        name="CloseButton"
        background="transparent"
        width={20}
        height={20}
        style={{
          marginLeft: "10px",
          cursor: "pointer",
          opacity: 0.7
        }}
        whileHover={{
          opacity: 1
        }}
        onClick={() => {
          setIsVisible(false)
          if (onClose) {
            setTimeout(onClose, 300)
          }
        }}
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="white"/>
        </svg>
      </Frame>
    </Frame>
  )
}

export default {
  YouTubePlayer,
  InteractiveButton,
  InteractiveCard,
  CustomCursor,
  ToastNotification
}
