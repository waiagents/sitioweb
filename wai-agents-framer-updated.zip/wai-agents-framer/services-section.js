// services-section.js - Componente de sección de Servicios para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal de la sección de Servicios
export function ServicesSection() {
  // Animaciones para los elementos
  const controls = useAnimation()
  
  // Estado para el video activo
  const [activeVideo, setActiveVideo] = useState(0)
  
  // Datos de videos de demostración
  const demoVideos = [
    {
      id: "placeholder1",
      title: "Automatización para Clínicas",
      description: "Gestión automatizada de citas, recordatorios y seguimiento de pacientes."
    },
    {
      id: "placeholder2",
      title: "Automatización para Negocios",
      description: "Atención al cliente 24/7 y gestión de consultas frecuentes."
    },
    {
      id: "placeholder3",
      title: "Automatización para Ventas",
      description: "Seguimiento de leads y proceso de ventas automatizado."
    }
  ]
  
  // Datos de sectores
  const sectors = [
    { title: "Sector Salud", description: "Automatización para clínicas médicas con gestión de citas y seguimiento de pacientes.", icon: "medical" },
    { title: "Sector Belleza", description: "Automatización para peluquerías, spas y centros de belleza.", icon: "beauty" },
    { title: "Sector Automotriz", description: "Automatización para rent car y talleres de mecánica.", icon: "automotive" },
    { title: "Sector Inmobiliario", description: "Automatización para bienes raíces y gestión de propiedades.", icon: "realestate" },
    { title: "Sector Legal", description: "Automatización para asesoría legal y fiscal.", icon: "legal" },
    { title: "Sector Gastronómico", description: "Automatización para restaurantes y salones de eventos.", icon: "restaurant" },
    { title: "Sector Educativo", description: "Automatización para centros educativos y academias.", icon: "education" },
    { title: "Sector Turismo", description: "Automatización para agencias de viajes y excursiones.", icon: "travel" },
    { title: "Sector Deportivo", description: "Automatización para gimnasios y clubes deportivos.", icon: "sports" },
    { title: "Sector Veterinario", description: "Automatización para clínicas veterinarias y pet shops.", icon: "veterinary" },
    { title: "Sector Espacios de Trabajo", description: "Automatización para coworkings y oficinas compartidas.", icon: "workspace" },
    { title: "¿Tu sector?", description: "Contáctanos para una solución personalizada para tu industria.", icon: "custom", isHighlighted: true }
  ]
  
  // Efecto para detectar cuando la sección es visible
  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('services')
      if (element) {
        const rect = element.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom >= 0
        
        if (isVisible) {
          controls.start({
            opacity: 1,
            y: 0,
            transition: { duration: 0.8, staggerChildren: 0.1 }
          })
        }
      }
    }
    
    window.addEventListener('scroll', handleScroll)
    // Trigger once on mount
    handleScroll()
    
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  return (
    <Frame
      name="ServicesSection"
      id="services"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: `${colors.background}` },
            { position: 100, color: "#E8EEF5" }
          ]
        }
      }}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Nuestros Servicios
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Soluciones de automatización personalizadas para 12 sectores empresariales
      </Frame>

      {/* Videos demostrativos */}
      <Frame
        name="VideosContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "30px",
          marginBottom: "70px",
          maxWidth: "1200px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        {/* Selector de videos */}
        <Frame
          name="VideoSelector"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "15px",
            marginBottom: "20px",
            flexWrap: "wrap"
          }}
        >
          {demoVideos.map((video, index) => (
            <Frame
              key={index}
              name={`VideoTab-${index}`}
              background={activeVideo === index ? colors.primaryButton : "rgba(124, 82, 237, 0.1)"}
              width="auto"
              height="auto"
              style={{
                padding: "10px 20px",
                borderRadius: "30px",
                fontSize: "16px",
                fontWeight: 500,
                color: activeVideo === index ? "white" : colors.primaryText,
                cursor: "pointer",
                transition: "all 0.3s ease"
              }}
              whileHover={{
                scale: 1.05,
                background: activeVideo === index ? colors.primaryButton : "rgba(124, 82, 237, 0.2)"
              }}
              onClick={() => setActiveVideo(index)}
            >
              {video.title}
            </Frame>
          ))}
        </Frame>
        
        {/* Reproductor de video */}
        <Frame
          name="VideoPlayer"
          background="#000"
          width="100%"
          height="auto"
          style={{
            borderRadius: "15px",
            overflow: "hidden",
            boxShadow: "0 20px 40px rgba(0, 0, 0, 0.15)",
            aspectRatio: "16/9",
            position: "relative"
          }}
        >
          <iframe
            width="100%"
            height="100%"
            src={`https://www.youtube.com/embed/${demoVideos[activeVideo].id}?autoplay=0&rel=0`}
            title={demoVideos[activeVideo].title}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%"
            }}
          />
        </Frame>
        
        {/* Descripción del video */}
        <Frame
          name="VideoDescription"
          background="white"
          width="100%"
          height="auto"
          radius={15}
          style={{
            padding: "20px 30px",
            boxShadow: "0 10px 30px rgba(0, 0, 0, 0.05)"
          }}
        >
          <Frame
            name="VideoTitle"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "20px",
              fontWeight: 600,
              color: colors.primaryText,
              marginBottom: "10px"
            }}
          >
            {demoVideos[activeVideo].title}
          </Frame>
          <Frame
            name="VideoDescriptionText"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "16px",
              lineHeight: 1.6,
              color: colors.secondaryText
            }}
          >
            {demoVideos[activeVideo].description}
          </Frame>
        </Frame>
      </Frame>

      {/* Servicios por sector */}
      <Frame
        name="SectorsTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "24px",
          fontWeight: 600,
          color: colors.primaryText,
          marginBottom: "30px",
          textAlign: "center",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Sectores que automatizamos
      </Frame>
      
      <Frame
        name="SectorsGrid"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: "30px",
          maxWidth: "1200px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        {sectors.map((sector, index) => (
          <SectorCard 
            key={index}
            title={sector.title} 
            description={sector.description}
            icon={sector.icon}
            isHighlighted={sector.isHighlighted}
            delay={index * 0.1}
          />
        ))}
      </Frame>
    </Frame>
  )
}

// Componente de Tarjeta de Sector
function SectorCard({ title, description, icon, isHighlighted = false, delay = 0 }) {
  const controls = useAnimation()
  
  useEffect(() => {
    const timeout = setTimeout(() => {
      controls.start({
        opacity: 1,
        y: 0,
        transition: { duration: 0.5 }
      })
    }, delay * 1000)
    
    return () => clearTimeout(timeout)
  }, [])
  
  return (
    <Frame
      name={`SectorCard-${title}`}
      background={isHighlighted ? colors.primaryButton : "white"}
      width="100%"
      height="auto"
      radius={15}
      style={{
        display: "flex",
        flexDirection: "column",
        padding: "30px",
        gap: "15px",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)",
        transition: "transform 0.3s ease, box-shadow 0.3s ease",
        opacity: 0,
        y: 30
      }}
      animate={controls}
      whileHover={{
        scale: 1.03,
        boxShadow: "0 15px 40px rgba(0, 0, 0, 0.15)"
      }}
    >
      <Frame
        name="IconContainer"
        background={isHighlighted ? "rgba(255, 255, 255, 0.2)" : `rgba(${parseInt(colors.primaryButton.slice(1, 3), 16)}, ${parseInt(colors.primaryButton.slice(3, 5), 16)}, ${parseInt(colors.primaryButton.slice(5, 7), 16)}, 0.1)`}
        width={60}
        height={60}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
        <Frame
          name="Icon"
          background="transparent"
          width={30}
          height={30}
          style={{
            backgroundImage: `url('/icons/${icon}.svg')`,
            backgroundSize: "contain",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat"
          }}
        />
      </Frame>
      <Frame
        name="CardTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "18px",
          fontWeight: 600,
          color: isHighlighted ? "white" : colors.primaryText
        }}
      >
        {title}
      </Frame>
      <Frame
        name="CardDescription"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "14px",
          lineHeight: 1.5,
          color: isHighlighted ? "rgba(255, 255, 255, 0.9)" : colors.secondaryText
        }}
      >
        {description}
      </Frame>
    </Frame>
  )
}

export default ServicesSection
