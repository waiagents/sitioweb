// service-worker.js - Service Worker para WAI Agents

// Nombre de la caché
const CACHE_NAME = 'wai-agents-cache-v1';

// Archivos a cachear inicialmente
const urlsToCache = [
  '/',
  '/index.html',
  '/index.js',
  '/header.js',
  '/hero.js',
  '/about-section.js',
  '/services-section.js',
  '/availability-calendar.js',
  '/testimonials-section.js',
  '/process-section.js',
  '/blog-section.js',
  '/contact-section.js',
  '/footer.js',
  '/animations.js',
  '/interactions.js',
  '/optimizations.js',
  '/logo.png',
  '/logo-white.png',
  '/favicon.ico',
  '/og-image.jpg',
  '/icons/email.svg',
  '/icons/phone.svg',
  '/icons/location.svg',
  '/icons/facebook.svg',
  '/icons/twitter.svg',
  '/icons/instagram.svg',
  '/icons/linkedin.svg',
  '/icons/facebook-white.svg',
  '/icons/twitter-white.svg',
  '/icons/instagram-white.svg',
  '/icons/linkedin-white.svg',
  '/icons/customer-service.svg',
  '/icons/integration.svg',
  '/icons/customize.svg',
  '/icons/speed.svg',
  '/icons/clock.svg',
  '/icons/calendar.svg',
  '/icons/star.svg',
  '/icons/dollar.svg',
  '/icons/quote.svg',
  '/icons/arrow-down.svg',
  '/icons/medical.svg',
  '/icons/beauty.svg',
  '/icons/automotive.svg',
  '/icons/realestate.svg',
  '/icons/legal.svg',
  '/icons/restaurant.svg',
  '/icons/education.svg',
  '/icons/travel.svg',
  '/icons/sports.svg',
  '/icons/veterinary.svg',
  '/icons/workspace.svg',
  '/icons/custom.svg',
  'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap'
];

// Instalación del Service Worker
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

// Estrategia de caché: Cache First, luego Network
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Devuelve la respuesta cacheada si existe
        if (response) {
          return response;
        }
        
        // Si no está en caché, hacemos la solicitud a la red
        return fetch(event.request)
          .then(response => {
            // Verificamos que la respuesta sea válida
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Clonamos la respuesta para poder usarla y cachearla
            const responseToCache = response.clone();
            
            // Agregamos la respuesta a la caché
            caches.open(CACHE_NAME)
              .then(cache => {
                // No cacheamos solicitudes de análisis o seguimiento
                if (!event.request.url.includes('analytics') && 
                    !event.request.url.includes('tracking')) {
                  cache.put(event.request, responseToCache);
                }
              });
            
            return response;
          });
      })
  );
});

// Activación y limpieza de cachés antiguas
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            // Elimina las cachés que no están en la lista blanca
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Estrategia de sincronización en segundo plano para formularios
self.addEventListener('sync', event => {
  if (event.tag === 'form-submit') {
    event.waitUntil(submitFormData());
  }
});

// Función para enviar datos de formulario almacenados localmente
function submitFormData() {
  return self.clients.matchAll().then(clients => {
    clients.forEach(client => {
      client.postMessage({
        msg: 'form-sync-complete'
      });
    });
  });
}

// Notificaciones push
self.addEventListener('push', event => {
  const data = event.data.json();
  
  const options = {
    body: data.body,
    icon: '/icons/notification-icon.png',
    badge: '/icons/badge-icon.png',
    vibrate: [100, 50, 100],
    data: {
      url: data.url
    }
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Acción al hacer clic en una notificación
self.addEventListener('notificationclick', event => {
  event.notification.close();
  
  event.waitUntil(
    clients.openWindow(event.notification.data.url)
  );
});
