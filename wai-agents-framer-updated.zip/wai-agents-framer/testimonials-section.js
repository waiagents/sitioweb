// testimonials-section.js - Componente de sección de Testimonios para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal de la sección de Testimonios
export function TestimonialsSection() {
  // Animaciones para los elementos
  const controls = useAnimation()
  
  // Estado para el testimonio activo
  const [activeTestimonial, setActiveTestimonial] = useState(0)
  
  // Datos de métricas
  const metrics = [
    { value: "85%", label: "Reducción en tiempo de respuesta", icon: "clock" },
    { value: "24/7", label: "Disponibilidad para clientes", icon: "calendar" },
    { value: "95%", label: "Satisfacción de clientes", icon: "star" },
    { value: "70%", label: "Reducción de costos operativos", icon: "dollar" }
  ]
  
  // Datos de testimonios
  const testimonials = [
    {
      quote: "WAI Agents transformó completamente la gestión de citas en nuestra clínica. Ahora nuestros pacientes pueden agendar 24/7 y reciben recordatorios automáticos, reduciendo las inasistencias en un 80%.",
      author: "Dr. Carlos Méndez",
      company: "Clínica Médica Integral",
      sector: "Sector Salud"
    },
    {
      quote: "Desde que implementamos WAI Agents en nuestra agencia inmobiliaria, hemos podido atender el triple de consultas sin aumentar nuestro personal. El seguimiento automático de leads ha mejorado nuestras conversiones en un 45%.",
      author: "Laura Gutiérrez",
      company: "Bienes Raíces Horizonte",
      sector: "Sector Inmobiliario"
    },
    {
      quote: "Como dueño de un restaurante, la automatización de reservas y pedidos ha sido un cambio radical. WAI Agents nos permite ofrecer una experiencia personalizada a cada cliente, recordando sus preferencias y ocasiones especiales.",
      author: "Miguel Ángel Torres",
      company: "Restaurante La Terraza",
      sector: "Sector Gastronómico"
    }
  ]
  
  // Efecto para detectar cuando la sección es visible
  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('testimonials')
      if (element) {
        const rect = element.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom >= 0
        
        if (isVisible) {
          controls.start({
            opacity: 1,
            y: 0,
            transition: { duration: 0.8, staggerChildren: 0.2 }
          })
        }
      }
    }
    
    window.addEventListener('scroll', handleScroll)
    // Trigger once on mount
    handleScroll()
    
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  // Efecto para rotar automáticamente los testimonios
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 8000)
    
    return () => clearInterval(interval)
  }, [])
  
  return (
    <Frame
      name="TestimonialsSection"
      id="testimonials"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: colors.gradientStart },
            { position: 100, color: colors.gradientEnd }
          ]
        }
      }}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative",
        color: "white"
      }}
    >
      {/* Elementos decorativos */}
      <Frame
        name="DecorativeElements"
        background="transparent"
        width="100%"
        height="100%"
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          overflow: "hidden"
        }}
      >
        <Frame
          name="GlowCircle1"
          background="radial-gradient(circle, rgba(124, 82, 237, 0.3) 0%, rgba(124, 82, 237, 0) 70%)"
          width={500}
          height={500}
          radius="50%"
          style={{
            position: "absolute",
            top: "-250px",
            right: "-100px"
          }}
        />
        <Frame
          name="GlowCircle2"
          background="radial-gradient(circle, rgba(72, 194, 240, 0.3) 0%, rgba(72, 194, 240, 0) 70%)"
          width={600}
          height={600}
          radius="50%"
          style={{
            position: "absolute",
            bottom: "-300px",
            left: "-200px"
          }}
        />
      </Frame>
      
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          marginBottom: "20px",
          textAlign: "center",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Casos de Éxito
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px",
          opacity: 0.9,
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Descubre cómo WAI Agents ha transformado la atención al cliente de empresas en diferentes sectores
      </Frame>

      {/* Métricas de resultados */}
      <Frame
        name="MetricsContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          gap: "30px",
          marginBottom: "70px",
          maxWidth: "1200px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        {metrics.map((metric, index) => (
          <MetricCard 
            key={index}
            value={metric.value} 
            label={metric.label} 
            icon={metric.icon}
            delay={index * 0.1}
          />
        ))}
      </Frame>

      {/* Testimonios */}
      <Frame
        name="TestimonialsContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "30px",
          maxWidth: "1000px",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        {/* Carrusel de testimonios */}
        <Frame
          name="TestimonialsCarousel"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            position: "relative",
            minHeight: "250px"
          }}
        >
          {testimonials.map((testimonial, index) => (
            <Frame
              key={index}
              name={`Testimonial-${index}`}
              background="rgba(255, 255, 255, 0.1)"
              width="100%"
              height="auto"
              radius={15}
              style={{
                display: "flex",
                flexDirection: "column",
                padding: "30px",
                backdropFilter: "blur(10px)",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                position: "absolute",
                top: 0,
                left: 0,
                opacity: activeTestimonial === index ? 1 : 0,
                transform: `translateX(${(index - activeTestimonial) * 50}px)`,
                pointerEvents: activeTestimonial === index ? "auto" : "none",
                transition: "opacity 0.5s ease, transform 0.5s ease"
              }}
            >
              <Frame
                name="QuoteIcon"
                background="transparent"
                width={40}
                height={40}
                style={{
                  backgroundImage: "url('/icons/quote.svg')",
                  backgroundSize: "contain",
                  backgroundPosition: "center",
                  backgroundRepeat: "no-repeat",
                  marginBottom: "15px",
                  opacity: 0.7
                }}
              />
              <Frame
                name="QuoteText"
                background="transparent"
                width="auto"
                height="auto"
                style={{
                  fontSize: "18px",
                  lineHeight: 1.6,
                  marginBottom: "20px",
                  fontStyle: "italic"
                }}
              >
                "{testimonial.quote}"
              </Frame>
              <Frame
                name="AuthorInfo"
                background="transparent"
                width="100%"
                height="auto"
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center"
                }}
              >
                <Frame
                  name="AuthorDetails"
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    display: "flex",
                    flexDirection: "column"
                  }}
                >
                  <Frame
                    name="AuthorName"
                    background="transparent"
                    width="auto"
                    height="auto"
                    style={{
                      fontSize: "16px",
                      fontWeight: 600
                    }}
                  >
                    {testimonial.author}
                  </Frame>
                  <Frame
                    name="AuthorCompany"
                    background="transparent"
                    width="auto"
                    height="auto"
                    style={{
                      fontSize: "14px",
                      opacity: 0.9
                    }}
                  >
                    {testimonial.company}
                  </Frame>
                </Frame>
                <Frame
                  name="SectorTag"
                  background="rgba(255, 255, 255, 0.2)"
                  width="auto"
                  height="auto"
                  style={{
                    padding: "5px 15px",
                    borderRadius: "20px",
                    fontSize: "12px",
                    fontWeight: 500
                  }}
                >
                  {testimonial.sector}
                </Frame>
              </Frame>
            </Frame>
          ))}
        </Frame>
        
        {/* Indicadores de testimonios */}
        <Frame
          name="TestimonialIndicators"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "10px",
            marginTop: "20px"
          }}
        >
          {testimonials.map((_, index) => (
            <Frame
              key={index}
              name={`Indicator-${index}`}
              background={activeTestimonial === index ? "white" : "rgba(255, 255, 255, 0.3)"}
              width={activeTestimonial === index ? "30px" : "10px"}
              height="10px"
              radius="5px"
              style={{
                cursor: "pointer",
                transition: "all 0.3s ease"
              }}
              onClick={() => setActiveTestimonial(index)}
            />
          ))}
        </Frame>
      </Frame>
      
      {/* CTA */}
      <Frame
        name="TestimonialsCTA"
        background={colors.secondaryButton}
        width="auto"
        height="auto"
        style={{
          padding: "15px 40px",
          borderRadius: "30px",
          fontSize: "18px",
          fontWeight: 600,
          color: "white",
          marginTop: "50px",
          cursor: "pointer",
          boxShadow: "0 10px 20px rgba(72, 194, 240, 0.3)",
          transition: "transform 0.3s ease, box-shadow 0.3s ease",
          opacity: 0,
          y: 20
        }}
        animate={controls}
        whileHover={{ 
          scale: 1.05,
          boxShadow: "0 15px 30px rgba(72, 194, 240, 0.4)"
        }}
        onClick={() => window.location.href = "#availability"}
      >
        Únete a nuestros casos de éxito
      </Frame>
    </Frame>
  )
}

// Componente de Tarjeta de Métrica
function MetricCard({ value, label, icon, delay = 0 }) {
  const controls = useAnimation()
  
  useEffect(() => {
    const timeout = setTimeout(() => {
      controls.start({
        opacity: 1,
        y: 0,
        scale: 1,
        transition: { duration: 0.5, type: "spring" }
      })
    }, delay * 1000)
    
    return () => clearTimeout(timeout)
  }, [])
  
  return (
    <Frame
      name={`MetricCard-${label}`}
      background="rgba(255, 255, 255, 0.1)"
      width="250px"
      height="auto"
      radius={15}
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "30px 20px",
        backdropFilter: "blur(10px)",
        border: "1px solid rgba(255, 255, 255, 0.2)",
        transition: "transform 0.3s ease",
        opacity: 0,
        y: 30,
        scale: 0.9
      }}
      animate={controls}
      whileHover={{
        scale: 1.05
      }}
    >
      <Frame
        name="IconContainer"
        background="rgba(255, 255, 255, 0.2)"
        width={60}
        height={60}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginBottom: "15px"
        }}
      >
        <Frame
          name="Icon"
          background="transparent"
          width={30}
          height={30}
          style={{
            backgroundImage: `url('/icons/${icon}.svg')`,
            backgroundSize: "contain",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat"
          }}
        />
      </Frame>
      <Frame
        name="Value"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "36px",
          fontWeight: 700,
          marginBottom: "5px"
        }}
      >
        {value}
      </Frame>
      <Frame
        name="Label"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "16px",
          textAlign: "center",
          opacity: 0.9
        }}
      >
        {label}
      </Frame>
    </Frame>
  )
}

export default TestimonialsSection
