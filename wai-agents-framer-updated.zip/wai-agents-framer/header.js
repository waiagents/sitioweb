// header.js - Componente de header para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca (importados del archivo principal)
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal del Header
export function Header() {
  // Estado para controlar si el menú móvil está abierto
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  // Estado para controlar si el header es transparente o sólido (basado en scroll)
  const [isTransparent, setIsTransparent] = useState(true)
  
  // Efecto para detectar el scroll y cambiar la apariencia del header
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY
      if (scrollPosition > 50) {
        setIsTransparent(false)
      } else {
        setIsTransparent(true)
      }
    }
    
    // Agregar event listener
    window.addEventListener('scroll', handleScroll)
    
    // Cleanup
    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])
  
  // Función para alternar el menú móvil
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen)
  }
  
  // Función para cerrar el menú móvil
  const closeMobileMenu = () => {
    setMobileMenuOpen(false)
  }
  
  return (
    <Frame
      name="Header"
      background={isTransparent ? "transparent" : "rgba(242, 245, 249, 0.95)"}
      width="100%"
      height={80}
      position="fixed"
      top={0}
      left={0}
      right={0}
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "0 5%",
        zIndex: 100,
        backdropFilter: isTransparent ? "none" : "blur(10px)",
        boxShadow: isTransparent ? "none" : "0 4px 20px rgba(0, 0, 0, 0.05)",
        transition: "all 0.3s ease"
      }}
    >
      {/* Logo */}
      <Frame
        name="Logo"
        background="transparent"
        width={150}
        height={50}
        style={{
          display: "flex",
          alignItems: "center"
        }}
      >
        <img src="/logo.png" alt="WAI Agents Logo" style={{ height: "100%" }} />
      </Frame>

      {/* Menú de navegación para desktop */}
      <Frame
        name="Navigation"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          display: "flex",
          gap: "30px",
          "@media (max-width: 768px)": {
            display: "none"
          }
        }}
      >
        <NavItem text="Inicio" href="#hero" isTransparent={isTransparent} />
        <NavItem text="Nosotros" href="#about" isTransparent={isTransparent} />
        <NavItem text="Servicios" href="#services" isTransparent={isTransparent} />
        <NavItem text="Disponibilidad" href="#availability" isTransparent={isTransparent} />
        <NavItem text="Testimonios" href="#testimonials" isTransparent={isTransparent} />
        <NavItem text="Proceso" href="#process" isTransparent={isTransparent} />
        <NavItem text="Blog" href="#blog" isTransparent={isTransparent} />
        <NavItem text="Contacto" href="#contact" isTransparent={isTransparent} />
      </Frame>

      {/* Botón de contacto para desktop */}
      <Frame
        name="ContactButton"
        background={colors.primaryButton}
        width="auto"
        height="auto"
        style={{
          padding: "10px 20px",
          borderRadius: "30px",
          fontSize: "14px",
          fontWeight: 600,
          color: "white",
          cursor: "pointer",
          boxShadow: "0 5px 15px rgba(124, 82, 237, 0.3)",
          transition: "transform 0.3s ease, box-shadow 0.3s ease",
          "@media (max-width: 768px)": {
            display: "none"
          }
        }}
        whileHover={{ 
          scale: 1.05,
          boxShadow: "0 8px 20px rgba(124, 82, 237, 0.4)"
        }}
        onClick={() => window.location.href = "#contact"}
      >
        Contáctanos
      </Frame>

      {/* Botón de menú móvil */}
      <Frame
        name="MobileMenuButton"
        background="transparent"
        width={40}
        height={40}
        style={{
          display: "none",
          flexDirection: "column",
          justifyContent: "space-around",
          cursor: "pointer",
          zIndex: 101,
          "@media (max-width: 768px)": {
            display: "flex"
          }
        }}
        onClick={toggleMobileMenu}
      >
        <Frame 
          background={isTransparent ? "white" : colors.primaryText} 
          width={40} 
          height={2}
          animate={{
            rotate: mobileMenuOpen ? 45 : 0,
            y: mobileMenuOpen ? 8 : 0
          }}
          transition={{ duration: 0.3 }}
        />
        <Frame 
          background={isTransparent ? "white" : colors.primaryText} 
          width={40} 
          height={2}
          animate={{
            opacity: mobileMenuOpen ? 0 : 1
          }}
          transition={{ duration: 0.3 }}
        />
        <Frame 
          background={isTransparent ? "white" : colors.primaryText} 
          width={40} 
          height={2}
          animate={{
            rotate: mobileMenuOpen ? -45 : 0,
            y: mobileMenuOpen ? -8 : 0
          }}
          transition={{ duration: 0.3 }}
        />
      </Frame>
      
      {/* Menú móvil */}
      <Frame
        name="MobileMenu"
        background="white"
        width="100%"
        height="100vh"
        position="fixed"
        top={0}
        left={0}
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "20px",
          zIndex: 100,
          opacity: mobileMenuOpen ? 1 : 0,
          pointerEvents: mobileMenuOpen ? "auto" : "none",
          transition: "opacity 0.3s ease"
        }}
      >
        <Frame
          name="MobileNavItems"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "20px"
          }}
        >
          <MobileNavItem text="Inicio" href="#hero" onClick={closeMobileMenu} />
          <MobileNavItem text="Nosotros" href="#about" onClick={closeMobileMenu} />
          <MobileNavItem text="Servicios" href="#services" onClick={closeMobileMenu} />
          <MobileNavItem text="Disponibilidad" href="#availability" onClick={closeMobileMenu} />
          <MobileNavItem text="Testimonios" href="#testimonials" onClick={closeMobileMenu} />
          <MobileNavItem text="Proceso" href="#process" onClick={closeMobileMenu} />
          <MobileNavItem text="Blog" href="#blog" onClick={closeMobileMenu} />
          <MobileNavItem text="Contacto" href="#contact" onClick={closeMobileMenu} />
          
          <Frame
            name="MobileContactButton"
            background={colors.primaryButton}
            width="80%"
            height="auto"
            style={{
              padding: "15px 20px",
              borderRadius: "30px",
              fontSize: "16px",
              fontWeight: 600,
              color: "white",
              cursor: "pointer",
              textAlign: "center",
              marginTop: "20px",
              boxShadow: "0 5px 15px rgba(124, 82, 237, 0.3)"
            }}
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              window.location.href = "#contact"
              closeMobileMenu()
            }}
          >
            Contáctanos
          </Frame>
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de ítem de navegación para desktop
function NavItem({ text, href, isTransparent }) {
  return (
    <Frame
      name={`NavItem-${text}`}
      background="transparent"
      width="auto"
      height="auto"
      style={{
        fontSize: "16px",
        fontWeight: 500,
        color: isTransparent ? "white" : colors.primaryText,
        cursor: "pointer",
        transition: "color 0.3s ease",
        ":hover": {
          color: isTransparent ? "rgba(255, 255, 255, 0.8)" : colors.primaryButton
        }
      }}
      whileHover={{ scale: 1.05 }}
      onClick={() => window.location.href = href}
    >
      {text}
    </Frame>
  )
}

// Componente de ítem de navegación para móvil
function MobileNavItem({ text, href, onClick }) {
  return (
    <Frame
      name={`MobileNavItem-${text}`}
      background="transparent"
      width="80%"
      height="auto"
      style={{
        fontSize: "20px",
        fontWeight: 600,
        color: colors.primaryText,
        cursor: "pointer",
        textAlign: "center",
        padding: "10px 0",
        borderBottom: "1px solid #eee"
      }}
      whileTap={{ scale: 0.95 }}
      onClick={() => {
        window.location.href = href
        onClick()
      }}
    >
      {text}
    </Frame>
  )
}

export default Header
